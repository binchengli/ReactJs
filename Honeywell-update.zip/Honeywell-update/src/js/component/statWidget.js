import React, { Component, PropTypes } from 'react';
import {
    Panel, Row, Col,
} from 'react-bootstrap';
import FontAwesome from 'react-fontawesome';
import classNames from 'classnames';

/* component */
import Lang from '../common/languages.js';

class StatWidget extends Component {
    static propTypes = {
        icon: PropTypes.string.isRequired,
        descText: PropTypes.string.isRequired,
        value: PropTypes.oneOfType([
                    PropTypes.string,
                    PropTypes.number
                ]).isRequired,
        color: PropTypes.string.isRequired,
        isLoading: PropTypes.bool
    };
    constructor (props) {
        super (props);
        this.state = {
        };
    };
    componentWillReceiveProps (nextProps) {
        if (nextProps.isLoading !== this.props.isLoading)
        {
            console.log('widget componentWillReceiveProps');
            this.dataUpdate(nextProps);
        }
    };
    render () {
        const styles = {
            'background-color': this.props.color,
            'border-color': this.props.color
        };
        return (
            <Panel 
                style={styles} 
                className={classNames({'statWidget-ibox': true})}
                header={
                    <div title={this.props.descText}>
                        <Row>
                            <Col xs={12} className='statWidget-content'>
                                {
                                    (()=>{
                                        let content_value = [];
                                        if (this.props.isLoading)
                                        {
                                            content_value.push(<span className="statWidget-accessingTag"><FontAwesome name='spinner' size='lg' pulse />{Lang.showText(48)}</span>);
                                        }
                                        else
                                        {
                                            content_value.push(<div>{this.props.value}</div>);
                                        }
                                        return content_value;
                                    })()
                                }
                            </Col>
                        </Row>
                        <Row>
                            {
                                (()=>{
                                    let content_header = [];
                                    if ('' != this.props.icon)
                                    {
                                        content_header.push(
                                            <Col xs={9} className='statWidget-headerText'>
                                                <div>{this.props.descText}</div>
                                            </Col>
                                        );
                                        content_header.push(
                                            <Col className='statWidget-headerImg'>
                                                <FontAwesome name={this.props.icon} size='3x' rotate={('sitemap' == this.props.icon)? 270:0} fixedWidth/>
                                            </Col>
                                        );
                                    }
                                    else
                                    {
                                        content_header.push(
                                            <Col xs={12} className='statWidget-headerText'>
                                                <div>{this.props.descText}</div>
                                            </Col>
                                        );
                                    }
                                    return content_header;
                                })()
                            }
                        </Row>
                    </div>
                }
            />
        );
    };

    dataUpdate (source) {
        
    };
};

export default StatWidget;