import React, { Component, PropTypes } from "react";
import {
    Grid, Row, Col, Tab, Form, FormGroup, FormControl, InputGroup, ControlLabel, Table, Pagination, DropdownButton, MenuItem, Button
} from 'react-bootstrap';
import FontAwesome from 'react-fontawesome';
import classNames from 'classnames';
import {
    ComposableMap,
    ZoomableGroup,
    Geographies,
    Geography,
} from "react-simple-maps";
import { scaleLinear } from "d3-scale";
import ReactTooltip from "react-tooltip";

const wrapperStyles = {
    position: 'relative',
    width: '100%',
    margin: '0 auto'
};

// const minColor = "#CFD8DC";
// const maxColor = "#37474F";

class ChoroplethMap extends Component {
    static propTypes = {
        data: PropTypes.array.isRequired,
        isLoading: PropTypes.bool
    };
    constructor (props) {
        super (props);
        this.state = {
            zoom: 1
        };
        this.data = [];
        this.scaleConfig = {
            minValue: 0,
            maxValue: 0,
            minColor: '#86CABB', /*'#CFD8DC'*/
            maxColor: '#2D4E47'  /*'#37474F'*/
        };
    };
    componentDidMount () {
        setTimeout(() => {
            ReactTooltip.rebuild();
        }, 100);
    };
    componentWillReceiveProps (nextProps) {
        if (nextProps.isLoading != this.props.isLoading)
        {
            console.log('map componentWillReceiveProps');
            this.dataUpdate(nextProps);
        }
    };
    render () {
        const customScale = scaleLinear()
            .domain([this.scaleConfig.minValue, this.scaleConfig.maxValue])
            .range([this.scaleConfig.minColor, this.scaleConfig.maxColor]);
        return (
            <div style={wrapperStyles}>
                <div className='jqvmap-zoomin' onClick={()=>{this._handleZoom(1)}}>+</div>
                <div className='jqvmap-zoomout' onClick={()=>{this._handleZoom(0)}}>−</div>
                <ComposableMap
                    projectionConfig={{
                        scale: 205,
                        rotation: [-11,0,0]
                    }}
                    width={980}
                    height={550}
                    style={{
                        width: '100%',
                        height: 'auto'
                    }}
                    >
                    <ZoomableGroup center={[0,20]} zoom={this.state.zoom}>
                        <Geographies geography="./file/world-50m-simplified.json" disableOptimization>
                            {(geos, proj) => geos.map((geo, i) => {

                                const country = this.data.find(d => d.ISO_A3 === geo.properties.ISO_A3);
                                let tips = country ? `${country.name}: ${country.val}` : '';

                                return (
                                    <Geography
                                        key={geo.properties.ISO_A3 + i}
                                        cacheId={geo.properties.ISO_A3 + i}
                                        data-tip={tips}
                                        geography={ geo }
                                        projection={ proj }
                                        style={{
                                            default: {
                                                fill: country ? customScale(country.val) : "#ECEFF1",
                                                stroke: "#FFF",
                                                strokeWidth: 0.75,
                                                outline: "none"
                                            },
                                            hover: {
                                                fill: "#263238",
                                                stroke: "#FFF",
                                                strokeWidth: 0.75,
                                                outline: "none"
                                            },
                                            pressed: {
                                                fill: "#263238",
                                                stroke: "#FFF",
                                                strokeWidth: 0.75,
                                                outline: "none"
                                            }
                                        }}
                                    />
                                )
                            })}
                        </Geographies>
                    </ZoomableGroup>
                </ComposableMap>
                <ReactTooltip />
            </div>
        );
    };

    dataUpdate (source) {
        this.data = source['data'];
        if (this.data.length)
        {
            this.scaleConfig.minValue = Math.min.apply(Math, this.data.map((entry) => {return entry.val;}));
            this.scaleConfig.maxValue = Math.max.apply(Math, this.data.map((entry) => {return entry.val;}));
        }
    };

    _handleZoom (zoom) {
        let value = this.state.zoom;
        if (zoom) value += 1;
        else value -= 1;
        if (value > 5) value = 5;
        if (value < 1) value = 1;
        this.setState({zoom: value});
    };
};

export default ChoroplethMap;
