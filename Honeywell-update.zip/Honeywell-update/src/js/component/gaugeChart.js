import React, { Component, PropTypes } from 'react';
import ReactDOM from 'react-dom';

import ReactSpeedometer from "react-d3-speedometer"
 
class GaugeChart extends Component {
    static propTypes = {
        Title: PropTypes.string.isRequired,
        Usage: PropTypes.string.isRequired,
        Size: PropTypes.string.isRequired
    };
    
    constructor(props) {
        super(props);
        this.state = {
            title: '',
            value: '',
            size: '',
            width: 300
        };
    };
    componentDidMount () {
        // var chartarea = document.getElementById('chartarea');
        // chartarea.height = body.offsetWidth;
        this.myUpdate();
        window.addEventListener('resize', this.myUpdate.bind(this));
    };
    componentWillUnmount() {
        window.removeEventListener('resize', this.myUpdate.bind(this));
    }
    componentWillReceiveProps (nextProps) {
        this.dataUpdate(nextProps);
    };
    dataUpdate (source) {
        this.state.title = source['Title'];
        this.state.value = source['Usage'];
        this.state.size = source['Size'];
        console.log(this.state.size);
    };
    myUpdate() {
        var body = document.getElementById('body');
        this.state.width = body.offsetWidth;
        this.setState(this.state);
    }
    render() {
        const cardTitle = {
            'padding': '10',
            'color': '#black',
            'font-size': '16px',
            'border-bottom': 'solid',
            'border-width': '2',
            'border-color': '#eee'
        };
        const cardBody = {
            'margin-top': '10',
            'background-color': 'white',
            'border-style': 'solid',
            'border-width': 'thin',
            'border-color': 'lightgray'
        };
        const chartarea = {
            'width': this.state.width - 20,
            'height': this.state.width * (60/100),
            'padding-left': '10'
        }
        return (
            <div id='body' style={cardBody}>
                <p style={cardTitle}>{this.state.title}</p>
                <div style={chartarea}>
                    <ReactSpeedometer
                        fluidWidth
                        forceRender={true}
                        value={this.state.value}
                        minValue={0}
                        maxValue={100}
                        segments={10}
                        startColor={'#33CC33'}
                        endColor={'#FF0000'}
                        ringWidth={20}
                        needleTransition="easeElastic"
                        currentValueText="CPU Loading ${value}%"
                    />
                </div>
            </div>
        );
    }
}
 
export default GaugeChart;
