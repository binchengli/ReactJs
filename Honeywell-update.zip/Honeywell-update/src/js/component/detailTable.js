import React, { Component, PropTypes } from 'react';
import {
  Grid, Row, Col, Table
} from 'react-bootstrap';
import FontAwesome from 'react-fontawesome';

/* common */
import Lang from '../common/languages.js';

class DetailTable extends Component {
    static propTypes = {
        Title: PropTypes.string.isRequired,
        ColumnLabels: PropTypes.array.isRequired,
        DataUnits: PropTypes.array.isRequired,
        isLoading: PropTypes.bool
    };
    constructor (props) {
        super (props);
        this.columnLabels = [];
        this.datasets = [];
    };
    componentDidMount () {
        this.dataUpdate(this.props);
    };
    componentWillReceiveProps (nextProps) {
        if (nextProps.isLoading != this.props.isLoading)
        {
            this.dataUpdate(nextProps);
        }
    };
    render () {
        return (
            <div>
                <div className='detailTitle'>{this.props.Title}</div>
                {this.showTable()}
            </div>
        );
    };
    dataUpdate (source) {
        this.datasets = source['DataUnits'];
        this.columnLabels = source['ColumnLabels'];
        this.columnLabels['percentage'] = {text: 28};

        let total = 0;
        this.datasets.map((entry) => {
            total = total + parseInt(entry['number'], 10);
        });

        for (let i=0; i<this.datasets.length; i++)
        {
            let percentage = 0;
            if (parseInt(this.datasets[i]['number']))
            {
                percentage = (parseInt(this.datasets[i]['number'], 10)/total)*100;
            }
            this.datasets[i]['percentage'] = percentage.toFixed(1)+'%';
        }
        this.setState(this.state);
    };

    showTable () {
        let content = [];
        if (this.props.isLoading || !this.datasets.length)
        {
            content.push(<span className='accessingTag'><FontAwesome name='spinner' size='lg' pulse />{Lang.showText(48)}</span>);
        }
        else
        {
            content.push(
                <Table striped hover>
                    <thead>
                        <tr>
                        {
                            Object.keys(this.columnLabels).map((item) => {
                                return (
                                    <th>{Lang.showText(this.columnLabels[item].text)}</th>
                                );
                            })
                        }
                        </tr>
                    </thead>
                    <tbody>
                    {
                        this.datasets.map((entry) => {
                            let content_tr = [];
                            content_tr.push(
                                <tr>
                                {
                                    Object.keys(this.columnLabels).map((item) => {
                                        let content_td = [];
                                        content_td.push(<td>{entry[item]}</td>);
                                        return content_td;
                                    })
                                }
                                </tr>
                            );
                            return content_tr;
                        })
                    }
                    </tbody>
                </Table>
            );
        }
        return content;
    };
};
export default DetailTable;