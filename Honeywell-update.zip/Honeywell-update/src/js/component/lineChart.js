import React, { Component, PropTypes } from 'react';
import {
  Grid, Row, Col
} from 'react-bootstrap';
import FontAwesome from 'react-fontawesome';
import {Line} from 'react-chartjs-2';

/* common */
import Lang from '../common/languages.js';

class LineChart extends Component {
    static propTypes = {
        Rowlabels: PropTypes.array.isRequired,
        DataUnits: PropTypes.array.isRequired,
        isLoading: PropTypes.bool
    };
    constructor (props) {
        super (props);
        this.rowlabel = [];
        this.datasets = [];
        this.rgb = [];
        this.options = {
            legend: {
                display: true,
                position: 'top',
                labels: {
                    usePointStyle: true
                }
            },
            responsive: true, maintainAspectRatio: false
        }
    };
    componentWillReceiveProps (nextProps) {
        if (nextProps.isLoading != this.props.isLoading)
        {
            this.dataUpdate(nextProps);
        }
    };
    render () {
        const styles = {
            graphContainer: {
                padding: '15px',
                'text-align': 'center',
                'height':'350px'
            }
        };
        return (
            <div style={styles.graphContainer}>
                {this.showChart()}
            </div>
        );
    };
    dataUpdate (source) {
        this.datasets = [];
        this.rowlabel = source['Rowlabels'];
        for (let i=0; i<source['DataUnits'].length; i++)
        {
            this.rgb = [];
            this.getRandomRgb();
            this.datasets.push({
                'label': source['DataUnits'][i]['name'],
                'backgroundColor': 'rgba(' + this.rgb[0] + ',' + this.rgb[1] + ',' + this.rgb[2] + ',' + '0.2)',
                'pointBackgroundColor': 'rgba(255,255,255,1)',
                'pointBorderColor': 'rgba(' + this.rgb[0] + ',' + this.rgb[1] + ',' + this.rgb[2] + ',' + '1)',
                'borderColor': 'rgba(' + this.rgb[0] + ',' + this.rgb[1] + ',' + this.rgb[2] + ',' + '1)',
                'borderWidth': 1,
                'data': source['DataUnits'][i]['data']
            });
        }
    };
    showChart () {
        let content = [];
        if (this.props.isLoading || !this.rowlabel.length)
        {
            content.push(<span className='accessingTag'><FontAwesome name='spinner' size='lg' pulse />{Lang.showText(48)}</span>);
        }
        else
        {
            const chartData = {
                labels: this.rowlabel.slice(0),
                datasets: this.datasets.slice(0)
            };
            content.push(
                <Line 
                    data={chartData}
                    options={this.options}
                    width={'100%'}
                    height={350}
                />
            );
        }
        return content;
    };
    getRandomRgb () {
        var num = Math.round(0xffffff * Math.random());
        this.rgb.push(num >> 16);
        this.rgb.push(num >> 8 & 255);
        this.rgb.push(num & 255);
    };
};
export default LineChart;