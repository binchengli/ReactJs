import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {
  Grid, Row, Col, DropdownButton, MenuItem, FormControl
} from 'react-bootstrap';
import classNames from 'classnames';

/* server API */
import DeviceAPI from '../../backendAPI/lyric_device.js';

/* component */
import PageTitile from '../../component/pageTitle.js';
import StatWidget from '../../component/statWidget.js';
import StatDoughnut from '../../component/statDoughnut.js';

/* common */
import Lang from '../../common/languages.js';
import StorageData from '../../common/storageData.js';

class Devices extends Component {
    constructor (props) {
        super (props);
        this.state = {
            isWidgetLoading: false,
            isFirstRowLoading: false,
            isSecondRowLoading: false,
            isThirdRowLoading: false,
            refreshTimer: 10
        };
        this.widgetInterval = {
            interval: 5,
            list: [
            {text: '5 Min', value: 5},
            {text: '10 Min', value: 10},
            {text: '15 Min', value: 15},
            {text: '30 Min', value: 30}]
        };
        this.widgetData = {
            online: 0,
            offline: 0,
            clip: 0,
            livestream: 0
        };
        this.firstRowData = {
            activated: [],
            online: [],
            offline: []
        };
        this.secondRowData = {
            privacy_mode: [],
            motion: [],
            audio: []
        };
        this.thirdRowData = {
            night_mode: [],
            storage_plan: [],
            firmware_version: []
        };
        this.countDownInterval;
        this.env = {
            project: ''
        };
    };
    componentDidMount () {
        console.log('devices componentDidMount');
        this.env.project = this.props.params.project;
        this.dataUpdate();
        this.state.refreshTimer = 60 * ReactDOM.findDOMNode(this.refs[`widgetInterval`]).value;
        this.countDownInterval = setInterval(()=>{this.checkCountDownTime()}, 1000)
    };
    componentWillReceiveProps (nextProps) {
        if (nextProps.params.project != this.env.project)
        {
            this.env.project = nextProps.params.project;
            console.log('devices componentWillReceiveProps', this.env.project);
            this.dataUpdate();
        }
    };
    render () {
        console.log('devices render');
        return (
            <Grid fluid>
                <Row>
                    <Col md={12}>
                        <PageTitile text={`${this.env.project}/${Lang.showText(3)}/${Lang.showText(4)}`} />
                    </Col>
                </Row>
                {this.showWidget()}
                {this.showFirstRow()}
                {this.showSecondRow()}
                {this.showThirdRow()}
                {this.showFourthRow()}
            </Grid>
        );
    };
    componentWillUnmount () {
        // stop refresh event
        // remove storage data
        clearInterval(this.countDownInterval);
        console.log('devices componentWillUnmount....');
    };

    dataUpdate () {
        this.doFetch('widget');
        this.doFetch('firstRow');
        this.doFetch('secondRow');
        this.doFetch('thirdRow');
    };
    doFetch (fetchType) {
        let result;
        let res;

        // result = DeviceAPI.onlinecamera();
        // result.then((res) => {
        //     if (ServerAPI.errorCodeCheck(res))
        //     {
        //         console.log(res.data, 'online');
        //     }
        // });


        switch (fetchType)
        {
            case 'widget':
                this.setState({ isWidgetLoading: true });
//                 result = SiteDashboard.getWidget(this.env['siteUuid']);
                   res = {data: {online: 10, offline: 12, clip: 707, livestream: 1600}};
//                 result.then((res) => {
                    setTimeout(() => {
                    this.resolveFetchData(res.data, 'widget');
                    this.setState({ isWidgetLoading: false });
                    }, 2000);
//                 });
            break;
            case 'firstRow':
                this.setState({ isFirstRowLoading: true });
//                 result = SiteDashboard.getFirstRow(this.env['siteUuid']);
                   res = {
                       data: {
                           activated: [{model: 'C1', number: 1200}, {model: 'C2', number: 2000}],
                           online: [{model: 'C1', number: 1600}, {model: 'C2', number: 1400}],
                           offline: [{model: 'C1', number: 2600}, {model: 'C2', number: 800}]
                       }
                   };
//                 result.then((res) => {
                    setTimeout(() => {
                    this.resolveFetchData(res.data, 'firstRow');
                    this.setState({ isFirstRowLoading: false });
                    }, 1000);
//                 });
            break;
            case 'secondRow':
                this.setState({ isSecondRowLoading: true });
                res = {
                    data: {
                        privacy_mode: [{model: 'C1', number: 1200}, {model: 'C2', number: 2000}],
                        motion: [{model: 'C1', number: 1600}, {model: 'C2', number: 1400}],
                        audio: [{model: 'C1', number: 2600}, {model: 'C2', number: 800}]
                    }
                };
                setTimeout(() => {
                    this.resolveFetchData(res.data, 'secondRow');
                    this.setState({ isSecondRowLoading: false });
                }, 1000);
            break;
            case 'thirdRow':
                this.setState({ isThirdRowLoading: true });
                res = {
                    data: {
                        night_mode: [{model: 'C1', number: 1200}, {model: 'C2', number: 2000}],
                        storage_plan: [{model: 'DAY', number: 1600}, {model: 'WEEK', number: 1400}, {model: 'MONTH', number: 1400}, {model: '60 Days', number: 1400}],
                        firmware_version: [{model: '0.97', number: 2600}, {model: '0.98', number: 800}, {model: '0.99', number: 800}, {model: 'Others', number: 800}]
                    }
                };
                setTimeout(() => {
                    this.resolveFetchData(res.data, 'thirdRow');
                    this.setState({ isThirdRowLoading: false });
                }, 1000);
            break;
        }
    };
    resolveFetchData (source, dataType) {
        switch (dataType)
        {
            case 'widget':
                Object.keys(source).map((entry) => {
                    this.widgetData[entry] = source[entry];
                });
            break;
            case 'firstRow':
                Object.keys(source).map((entry) => {
                    this.firstRowData[entry] = source[entry];
                });
            break;
            case 'secondRow':
                Object.keys(source).map((entry) => {
                    this.secondRowData[entry] = source[entry];
                });
            break;
            case 'thirdRow':
                Object.keys(source).map((entry) => {
                    this.thirdRowData[entry] = source[entry];
                });
            break;
        }
    };
    showCountDown () {
        let content = [];
        let minute = this.makeTwoDigit(Math.floor(this.state.refreshTimer / 60).toFixed(0));
        let seconds = this.makeTwoDigit(this.state.refreshTimer % 60);
        content.push(
            <Col md={2} style={{'font-size': '20', 'float': 'right', 'text-align': 'right', 'padding-top': '10px'}}>{minute + ":" + seconds}</Col>
        );
        return content;
    };
    makeTwoDigit(value){
        return value > 9 ? "" + value: "0" + value;
    }
    showWidget () {
        let content = [];
        content.push(
            <Row style={{'background': 'white', 'margin-left': '-4px', 'margin-right': '-4px'}}>
                <Col md={2} className='data-source-selector'>
                    <FormControl 
                        componentClass='select' 
                        onChange={() => {this._setWidgetInterval();}} 
                        ref='widgetInterval'
                    >
                        {
                            this.widgetInterval.list.map((entry) => (
                                <option value={entry['value']}>{entry['text']}</option>
                            ))
                        }
                    </FormControl>
                </Col>
                {this.showCountDown()}
            </Row>
        );
        content.push(
            <Row style={{'background': 'white', 'margin-left': '-4px', 'margin-right': '-4px', 'margin-bottom': '10px'}}>
                <Col md={3} sd={3}>
                    <StatWidget value={this.widgetData['online']} descText={Lang.showText(15)} icon='arrow-up' isLoading={this.state['isWidgetLoading']} color='#19b394' />
                </Col>
                <Col md={3} sd={3}>
                    <StatWidget value={this.widgetData['offline']} descText={Lang.showText(16)} icon='arrow-down' isLoading={this.state['isWidgetLoading']} color='#930000' />
                </Col>
                <Col md={3} sd={3}>
                    <StatWidget value={this.widgetData['clip']} descText={Lang.showText(17)} icon='camera' isLoading={this.state['isWidgetLoading']} color='#5c8fc1' />
                </Col>
                <Col md={3} sd={3}>
                    <StatWidget value={this.widgetData['livestream']} descText={Lang.showText(18)} icon='video-camera' isLoading={this.state['isWidgetLoading']} color='#83aad0' />
                </Col>
            </Row>
        );
        return content;
    };
    showFirstRow () {
        let content = [];
        content.push(
            <Row>
                <Col md={4} sd={4}>
                    <StatDoughnut statData={this.firstRowData['activated']} title='Total Activated Devices' isLoading={this.state['isFirstRowLoading']} />
                </Col>
                <Col md={4} sd={4}>
                    <StatDoughnut statData={this.firstRowData['online']} title='Online Devices' isLoading={this.state['isFirstRowLoading']} />
                </Col>
                <Col md={4} sd={4}>
                    <StatDoughnut statData={this.firstRowData['offline']} title='Offline Devices' isLoading={this.state['isFirstRowLoading']} />
                </Col>
            </Row>
        );
        return content;
    };
    showSecondRow () {
        let content = [];
        content.push(
            <Row>
                <Col md={4} sd={4}>
                    <StatDoughnut statData={this.secondRowData['privacy_mode']} title='Privacy Mode' isLoading={this.state['isSecondRowLoading']} />
                </Col>
                <Col md={4} sd={4}>
                    <StatDoughnut statData={this.secondRowData['motion']} title='Motion ON' isLoading={this.state['isSecondRowLoading']} />
                </Col>
                <Col md={4} sd={4}>
                    <StatDoughnut statData={this.secondRowData['audio']} title='Audio ON' isLoading={this.state['isSecondRowLoading']} />
                </Col>
            </Row>
        );
        return content;
    };
    showThirdRow () {
        let content = [];
        content.push(
            <Row>
                <Col md={4} sd={4}>
                    <StatDoughnut statData={this.thirdRowData['night_mode']} title='Night Mode' isLoading={this.state['isThirdRowLoading']} />
                </Col>
                <Col md={4} sd={4}>
                    <StatDoughnut statData={this.thirdRowData['storage_plan']} title='Storage Plan' isLoading={this.state['isThirdRowLoading']} />
                </Col>
                <Col md={4} sd={4}>
                    <StatDoughnut statData={this.thirdRowData['firmware_version']} title='Firmware Version (C1)' isLoading={this.state['isThirdRowLoading']} />
                </Col>
            </Row>
        );
        return content;
    };
    showFourthRow () {
        let content = [];
        content.push(
            <Row>
                <Col md={4} sd={4}>
                    <StatDoughnut statData={this.thirdRowData['firmware_version']} title='Firmware Version (C2)' isLoading={this.state['isThirdRowLoading']} />
                </Col>
            </Row>
        );
        return content;
    };
    checkCountDownTime() {
        this.state.refreshTimer--;
        if(0 == this.state.refreshTimer)
            this.state.refreshTimer = 60 * ReactDOM.findDOMNode(this.refs[`widgetInterval`]).value;
        this.setState(this.state);
    }
    _setWidgetInterval () {
        this.state.refreshTimer = 60 * ReactDOM.findDOMNode(this.refs[`widgetInterval`]).value;
    };
};

export default Devices;