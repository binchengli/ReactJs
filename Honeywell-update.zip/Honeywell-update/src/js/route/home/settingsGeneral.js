import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {
    Grid, Row, Col, FormGroup, FormControl, ControlLabel, Button, Form
} from 'react-bootstrap';
import { hashHistory } from 'react-router';
import FontAwesome from 'react-fontawesome';

/* component */
import PageTitile from '../../component/pageTitle.js';
/* route */


/* common */
import Lang from '../../common/languages.js';
import StorageData from '../../common/storageData.js';

class SettingsGeneral extends Component {
    constructor (props) {
        super (props);
        this.state = {
            isLoading: false
        };
        this.formData = {
            refreshTime: 5
        };
        this.env = {
            
        };
    };
    componentDidMount () {
        
    };
    componentWillReceiveProps (nextProps) {
        
    };
    render () {
        return (
            <Grid fluid>
                <Row>
                    <Col md={12}>
                        <PageTitile text={`${Lang.showText(54)}/${Lang.showText(40)}`} />
                    </Col>
                </Row>
                <Row>
                    <Col md={12}>
                        <div className='general-panel'>
                            <div className='general-panel-title'>
                                <h3>{Lang.showText(40)}</h3>
                            </div>
                            <div className='general-panel-content'>
                                <Form horizontal>
                                    <FormGroup>
                                        <Col componentClass={ControlLabel} md={3}>{`Change Password`}</Col>
                                        <Col md={3}>
                                            <FontAwesome name='caret-right' size='2x' onClick={() => {this._redirectHandler('/home/settings/password');}} className='settings-icon' />
                                        </Col>
                                    </FormGroup>
                                    <FormGroup>
                                        <Col componentClass={ControlLabel} md={3}>{`Monitor Devices`}</Col>
                                        <Col md={3}>
                                            <FontAwesome name='caret-right' size='2x' onClick={() => {this._redirectHandler('/home/settings/monitor');}} className='settings-icon' />
                                        </Col>
                                    </FormGroup>
                                    <FormGroup>
                                        <Col componentClass={ControlLabel} md={3}>{`Default Refresh Time`}</Col>
                                        <Col md={3}>
                                            <FormControl 
                                                componentClass='select' 
                                                onChange={()=>{this._changeHandler('refreshTime');}} 
                                                ref='refreshTime'
                                            >
                                                <option value='5'>5 Min</option>
                                                <option value='10'>10 Min</option>
                                                <option value='15'>15 Min</option>
                                                <option value='30'>30 Min</option>
                                            </FormControl>
                                        </Col>
                                    </FormGroup>
                                </Form>
                            </div>
                            <div className='general-panel-footer'>
                                <Col md={3}>
                                    {this.showButton()}
                                </Col>
                            </div>
                        </div>
                    </Col>
                </Row>
            </Grid>
        );
    };

    reload () {
        
    };

    showButton () {
        let content = [];
        if (this.state['isLoading'])
        {
            content.push(
                <div>
                    <Button disabled>{Lang.showText(60)}</Button>
                    <Button disabled>{Lang.showText(61)}</Button>
                    <span className="accessingTag"><FontAwesome name='spinner' size='lg' pulse/>{Lang.showText(48)}</span> 
                </div>
            );
        }
        else
        {
            content.push(
                <div>
                    <Button onClick={()=>{this._submitHandler('save');}} bsStyle="success">{Lang.showText(60)}</Button>
                    <Button onClick={()=>{this._redirectHandler('/home/realtime/devices/lyric');}} bsStyle="primary">{Lang.showText(61)}</Button>
                </div>
            );
        };
        return content;
    };

    _redirectHandler (path) {
        let homeThis = StorageData.get('homeThis');
        if (homeThis)
        {
            homeThis.env.nextPath = path;
        }
        hashHistory.push(path);
    };
    _changeHandler () {
        
    };
    _submitHandler (type) {
        switch (type)
        {
            case 'save':
                
            break;
        }
    };
};

export default SettingsGeneral;