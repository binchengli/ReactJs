import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {
  Panel, Grid, Row, Col, FormControl, Table, DropdownButton, MenuItem, Pagination, Button
} from 'react-bootstrap';
import FontAwesome from 'react-fontawesome';

/* component */
import PageTitile from '../../component/pageTitle.js';
// import InfoCard from '../../component/infoCard.js';

/* common */
import Lang from '../../common/languages.js';
// import StorageData from '../../common/storageData.js';

class SystemLog extends Component {
    constructor (props) {
        super (props);
        this.state = {
            isLoading: false,
            placeholder: 'Device ID'
        };
        this.dataSource = {
            type: 1,
            devId: '',
            date: {
                interval: 2,
                startDay: 0,
                endDay: 0
            },
            dateList: [
                {text: '1 Hour', value: 1},
                {text: '2 Hours', value: 2},
                {text: '3 Hours', value: 3},
                {text: '5 Hours', value: 5},
                {text: '12 Hours', value: 12}
            ],
            DeviceIDorMAC: [
                {text: 'Device ID', value: 1},
                {text: 'MAC', value: 2}
            ]
        };
        this.tableParams = {
            headerLength: 0,
            matchAll: false,
            searchedCount: 1,
            searchedTag: [],
            sortedOrder: [],
            dataPerPage: 10,
            lastPage: 1,
            resultData:[]
        };
        this.tableHeader = {
            timestamp: {show: true, text: 32},
            devId: {show: true, text: 24},
            message: {show: true, text: 33}
        };
        this.tableData = [];
        this.env = {
            project: ''
        };
    };
    componentDidMount () {
        console.log('server componentDidMount', 'this.props.params.project =', this.props.params.project);
        this.env.project = this.props.params.project;
        this.dataUpdate();
    };
    componentWillReceiveProps (nextProps) {
        if (nextProps.params.project != this.env.project)
        {
            this.env.project = nextProps.params.project;
            console.log('server componentWillReceiveProps', this.env.project);
            this.dataUpdate();
        }
    };
    render () {
        this.tableRefresh();
        return (
            <Grid fluid>
                <Row>
                    <Col md={12}>
                        <PageTitile text={`${this.env.project}/${Lang.showText(3)}/${Lang.showText(7)}`} />
                    </Col>
                </Row>
                <Row style={{'margin-bottom': '10px'}}>
                    <Col md={2}>
                        <FormControl 
                            componentClass='select' 
                            onChange={() => {this._setDeviceIDorMAC();}} 
                            ref='dataSourceType' 
                            disabled={this.state.isLoading}
                        >
                            {
                                this.dataSource.DeviceIDorMAC.map((entry) => (
                                    <option value={entry['value']} selected={(this.dataSource.type == entry.value)?true:false}>{entry['text']}</option>
                                ))
                            }
                        </FormControl>
                    </Col>
                    <Col md={4}>
                        <FormControl 
                            type='text' 
                            placeholder={this.state.placeholder}
                            onChange={()=>{this._setDataSourceDevId();}} 
                            ref='dataSourceDevId'
                            maxLength='64'
                        />
                    </Col>
                    <Col md={2}>
                        <FormControl 
                            componentClass='select' 
                            onChange={() => {this._setDataSourceInterval();}} 
                            ref='dataSourceInterval' 
                            disabled={this.state.isLoading}
                        >
                            {
                                this.dataSource.dateList.map((entry) => (
                                    <option value={entry['value']} selected={(this.dataSource.date.interval == entry.value)?true:false}>{entry['text']}</option>
                                ))
                            }
                        </FormControl>
                    </Col>
                    <Col md={1}>
                        <Button className='fa fa-refresh'></Button>
                    </Col>
                </Row>
                <Row>
                    <Col md={12}>
                        <div className='general-panel'>
                            <div className='general-panel-title'>
                                <h3>{Lang.showText(7)}</h3>
                            </div>
                            <div className='general-panel-content'>
                                <Row style={{'overflow':'auto'}}>
                                    {this.showTable()}
                                </Row>
                                <Row>
                                    {this.showPaged()}
                                </Row>
                            </div>
                        </div>
                    </Col>
                </Row>
            </Grid>
        );
    };
    genUuid () {
        let d = Date.now();
        if (typeof performance !== 'undefined' && typeof performance.now === 'function')
        {
            d += performance.now();
        }
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
            let r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
    };
    dataUpdate () {
        this.doFetch();
    };
    doFetch () {
        let result;
        let res;
        this.setState({isLoading: true});
//         result = SiteDashboard.getWidget(this.env['siteUuid']);
        res = {
            data: [
                // {timestamp: '2018-12-12 03:11:15', devId: this.genUuid(), message: '123'},
                // {timestamp: '2018-12-12 03:11:15', devId: this.genUuid(), message: '456'},
                // {timestamp: '2018-12-12 03:11:15', devId: this.genUuid(), message: '789'}
                {timestamp: '2018-12-12 03:11:15', devId: '913E6052E3B17F277E92FAC7A8D6F158724A458B869A1D636D871D785D646AE8', message: '{"api":"upload_clip","date":1543284663,"devid":"913E6052E3B17F277E92FAC7A8D6F158724A458B869A1D636D871D785D646AE8","from":"108.53.36.205","request":{"clipid":"d8d2d569-c42a-4da1-9df7-be5ef87e3d57","duration":"30","event_type":"Sound/Others","eventid":"d8d2d569-c42a-4da1-9df7-be5ef87e3d57","resolution":"1920x1080","time":"2018-11-27 00:05:53"},"response":"Unable to obtain user public key.ok. (0sec)","stage":"LyricDev","type":"api"}'},
                {timestamp: '2018-12-12 03:11:15', devId: '913E6052E3B17F277E92FAC7A8D6F158724A458B869A1D636D871D785D646AE8', message: '{"api":"upload_clip","date":1543284663,"devid":"913E6052E3B17F277E92FAC7A8D6F158724A458B869A1D636D871D785D646AE8","from":"108.53.36.205","request":{"clipid":"d8d2d569-c42a-4da1-9df7-be5ef87e3d57","duration":"30","event_type":"Sound/Others","eventid":"d8d2d569-c42a-4da1-9df7-be5ef87e3d57","resolution":"1920x1080","time":"2018-11-27 00:05:53"},"response":"Unable to obtain user public key.ok. (0sec)","stage":"LyricDev","type":"api"}'},
                {timestamp: '2018-12-12 03:11:15', devId: '913E6052E3B17F277E92FAC7A8D6F158724A458B869A1D636D871D785D646AE8', message: '{"api":"upload_clip","date":1543284663,"devid":"913E6052E3B17F277E92FAC7A8D6F158724A458B869A1D636D871D785D646AE8","from":"108.53.36.205","request":{"clipid":"d8d2d569-c42a-4da1-9df7-be5ef87e3d57","duration":"30","event_type":"Sound/Others","eventid":"d8d2d569-c42a-4da1-9df7-be5ef87e3d57","resolution":"1920x1080","time":"2018-11-27 00:05:53"},"response":"Unable to obtain user public key.ok. (0sec)","stage":"LyricDev","type":"api"}'}
            ]
        };
//         result.then((res) => {
        setTimeout(() => {
            this.resolveFetchData(res.data);
            this.setState({ isLoading: false });
        }, 1000);
//         });
    };
    resolveFetchData (source) {
        let data = source.slice(0);
        let dataArray = [];

        data.map((entry, index) => {
            dataArray[index] = entry;
            dataArray[index]['id'] = index+1;
        });

        this.tableData = dataArray.reverse().slice(0);
        this.initTable(dataArray);
    };
    initTable (data) {
        data.map((entry, index) => {
            this.tableParams.searchedTag[index] = 1;
            this.tableParams.sortedOrder[index] = index;
        });
        this.tableParams.searchedCount = 1;
        this.tableParams.matchAll = false;
        this.tableParams.lastPage = Math.ceil(data.length / this.tableParams.dataPerPage);
        this.setState({ activePage: 1 });
    };
    tableRefresh () {
        this.tableParams.resultData = [];
        let countLength = 0;
        let data = this.tableData.slice(0);
        data.map((entry, index) => {
            if (this.tableParams.matchAll)
            {
                if (this.tableParams.searchedCount == this.tableParams.searchedTag[index])
                {
                    this.tableParams.resultData[countLength] = this.tableParams.sortedOrder[index];
                    countLength++;
                }
            }
            else
            {
                if (0 < this.tableParams.searchedTag[index])
                {
                    this.tableParams.resultData[countLength] = this.tableParams.sortedOrder[index];
                    countLength++;
                }
            }
        });
        /* update pagedInfo */
        this.tableParams.lastPage = Math.ceil(countLength / this.tableParams.dataPerPage);
    };

    showSearchBar () {
        let content = [];
        content.push(
            <Col md={4} mdOffset={6}>
                <FormGroup>
                    <InputGroup>
                        <FormControl ref='searchInput' type='text' placeholder={Lang.showText(101)} onChange={()=>this._searchHandler()} />
                        <InputGroup.Addon>
                            <FontAwesome name='search' />
                        </InputGroup.Addon>
                    </InputGroup>
                </FormGroup>
            </Col>
        );
        content.push(
            <Col md={2} className='matchAllToggle'>
                <Checkbox
                    checkboxClass={ConstDef.ICHECK_STYLE}
                    increaseArea="20%"
                    label={Lang.showText(105)}
                    checked={this.tableParams['matchAll']}
                    onChange={()=>this._searchMatchAllHandler()}
                />
            </Col>
        );
        return content;
    };
    showTable () {
        let content = [];
        content.push(
            <Col md={12}>
                <Table striped hover>
                    {this.showTableHeader()}
                    {this.showTableBody()}
                </Table>
            </Col>
        );
        return content;
    };
    showTableHeader () {
        let content = [];
        let count = 0;
        content.push(
            <thead>
                <tr>
                    {
                        Object.keys(this.tableHeader).map((entry) => {
                            let content_th = [];
                            switch (entry)
                            {
                                case 'timestamp':
                                case 'devId':
                                    content_th.push(
                                        <th>{Lang.showText(this.tableHeader[entry].text)}</th>
                                    );
                                    break;
                                default:
                                    content_th.push(
                                        <th>{Lang.showText(this.tableHeader[entry].text)}</th>
                                    );
                                    break;
                            };
                            count++;
                            return content_th;
                        })
                    }
                </tr>
            </thead>
        );
        this.tableParams.headerLength = count;
        return content;
    };
    showTableBody () {
        let data = this.tableData.slice(0);
        let contentIndex = this.tableParams.resultData.slice(0);
        let contentStart = (this.state.activePage-1) * this.tableParams.dataPerPage;
        let contentEnd = Math.min((this.state.activePage * this.tableParams.dataPerPage) , this.tableParams.resultData.length);
        let content = [];
        let index = 0, count = 0, tableInfo = [];
        for (let i=contentStart; i<contentEnd; i++)
        {
            index = contentIndex[i];
            tableInfo[count] = data[index];
            count++;
        }
        content.push(
            <tbody>
                {
                    tableInfo.map((entry) => {
                        let content_tr = [];
                        content_tr.push(
                            <tr>
                                {
                                    Object.keys(this.tableHeader).map((info) => {
                                        let content_td = [];
                                        switch (info)
                                        {
                                            case 'timestamp':
                                                content_td.push(
                                                    <td>{entry[info]}</td>
                                                    //<td className='text-left'>{entry[info]}</td>
                                                );
                                                break;
                                            default:
                                                content_td.push(
                                                    <td>{entry[info]}</td>
                                                );
                                                break;
                                        };
                                        return content_td;
                                    })
                                }
                            </tr>
                        );
                        return content_tr;
                    })
                }
                {
                    (0 == tableInfo.length)? (<tr><td colSpan={this.tableParams['headerLength']} className='text-center'>{Lang.showText(49)}</td></tr>) : []
                }
            </tbody>
        );
        return content;
    };
    showPaged () {
        const pagedOptions = new Array(
            {value: 10},
            {value: 25},
            {value: 50},
            {value: 100},
        );
        let content = [];
        let showStart = 0;
        if (0 < this.tableParams.resultData.length)
        {
            showStart = (this.state.activePage-1) * this.tableParams.dataPerPage + 1;
        }
        let showEnd = Math.min((this.state.activePage * this.tableParams.dataPerPage) , this.tableParams.resultData.length);
        content.push(
            <Col md={12} className='tables-paging'>
                <div className='pageinfo'>
                    <span>{Lang.showText(77, showStart, showEnd, this.tableParams['resultData'].length)}</span>
                    <span>{Lang.showText(78)}: </span>
                    <DropdownButton title={this.tableParams.dataPerPage} onSelect={(eventKey) => this._perPageHandler(eventKey)} dropup>
                        {
                            pagedOptions.map((entry) => (
                                <MenuItem eventKey={entry.value}>{entry.value}</MenuItem>
                            ))
                        }
                    </DropdownButton>
                    <span>{Lang.showText(79)}: </span>
                    <Pagination
                        prev
                        next
                        first
                        last
                        ellipsis={false}
                        items={this.tableParams.lastPage}
                        maxButtons={9}
                        activePage={this.state.activePage}
                        onSelect={(eventKey) => {this._pagedHandler(eventKey);}}
                    />
                </div>
            </Col>
        );
        return content;
    };

    _setDeviceIDorMAC (entry) {
        if(1 == ReactDOM.findDOMNode(this.refs[`dataSourceType`]).value)
            this.state.placeholder = 'Device ID';
        else
            this.state.placeholder = 'MAC';
        this.setState(this.state);
    }
    _setDataSourceType () {
        
    };
    _setDataSourceDevId () {
        
    };
    _setDataSourceInterval () {
        
    };
};
export default SystemLog;