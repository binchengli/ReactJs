import React, { Component } from 'react';
import {
  Panel, Grid, Row, Col
} from 'react-bootstrap';
import FontAwesome from 'react-fontawesome';

/* component */
import PageTitile from '../../component/pageTitle.js';
import GaugeChart from '../../component/gaugeChart.js';
import InfoCard from '../../component/infoCard.js';

/* common */
import Lang from '../../common/languages.js';
import StorageData from '../../common/storageData.js';

class Server extends Component {
    constructor (props) {
        super (props);
        this.state = {
            isLoading: false,
        };
        this.env = {
            project: ''
        };
    };
    componentDidMount () {
        console.log('server componentDidMount', 'this.props.params.project =', this.props.params.project);
        this.env.project = this.props.params.project;
        this.dataUpdate();
    };
    componentWillReceiveProps (nextProps) {
        if (nextProps.params.project != this.env.project)
        {
            this.env.project = nextProps.params.project;
            console.log('server componentWillReceiveProps', this.env.project);
            this.dataUpdate();
        }
    };

    render () {
        let data1 = [
                        { Status: 'OK', SColor: '#008000', Note: 'Server Health' },
                        { Status: '12,358', SColor: '#1E90FF', Note: 'Total Clips'},
                        { Status: '1888 GB', SColor: '#1E90FF', Note: 'Capacity Consumed'}
                   ]
        let data2 = [
                        { Status: '12,358,125', SColor: '#1E90FF', Note: 'Request Count' },
                        { Status: '0.018ms', SColor: '#1E90FF', Note: 'Response Time' },
                        { Status: '99.5%', SColor: '#1E90FF', Note: 'Response Success' }
                   ]
        let data3 = [
                        { Status: 'OK', SColor: '#008000', Note: 'API server access from CHIL server' },
                        { Status: 'OK', SColor: '#008000', Note: 'API server access from device' },
                        { Status: 'OK', SColor: '#008000', Note: 'DDNS server access from CHIL server' }
                   ]
        let data4 = [
                        { Status: 'OK', SColor: '#008000', Note: 'DDNS server access from device' },
                        { Status: 'OK', SColor: '#008000', Note: 'Relay server access from device' },
                        { Status: 'OK', SColor: '#008000', Note: 'clip server access from device' }
                   ]
        let data5 = [
                        { Title: 'CPU Loading of API Server', Usage: '20', Size: '300' },
                        { Title: 'CPU Loading of RDS Server', Usage: '60', Size: '300' }
                   ]
        return (
            <Grid fluid>
                <Row>
                    <Col md={12}>
                        <PageTitile text={`${this.env.project}/${Lang.showText(3)}/${Lang.showText(5)}`} />
                    </Col>
                </Row>
                <Row>
                    {data1.map((entry) => (
                            <Col md={4}>
                                <InfoCard
                                    Status = {entry['Status']}
                                    SColor = {entry['SColor']}
                                    Note = {entry['Note']}
                                />
                            </Col>
                        ))}
                </Row>
                <Row>
                    {data2.map((entry) => (
                        <Col md={4}>
                            <InfoCard
                                Status = {entry['Status']}
                                SColor = {entry['SColor']}
                                Note = {entry['Note']}
                            />
                        </Col>
                    ))}
                </Row>
                <Row>
                    {data3.map((entry) => (
                        <Col md={4}>
                            <InfoCard
                                Status = {entry['Status']}
                                SColor = {entry['SColor']}
                                Note = {entry['Note']}
                            />
                        </Col>
                    ))}
                </Row>
                <Row>
                    {data4.map((entry) => (
                        <Col md={4}>
                            <InfoCard
                                Status = {entry['Status']}
                                SColor = {entry['SColor']}
                                Note = {entry['Note']}
                            />
                        </Col>
                    ))}
                </Row>
                <Row>
                    {data5.map((entry) => (
                        <Col md={4}>
                            <GaugeChart
                                Title = {entry['Title']}
                                Usage = {entry['Usage']}
                                Size = {entry['Size']}
                            />
                        </Col>
                    ))}
                </Row>
            </Grid>
        );
    };
    dataUpdate () {
        this.doFetch();
    };
    doFetch () {
        let result;
        let res;
        this.setState({isLoading: true});
//         result = SiteDashboard.getWidget(this.env['siteUuid']);
        res = {
            data: [
                {
                    version: '0.97',
                    list: [
                        {time:'1', val: Math.floor(Math.random() * 200) + 1},
                        {time:'2', val: Math.floor(Math.random() * 200) + 1},
                        {time:'3', val: Math.floor(Math.random() * 200) + 1},
                        {time:'4', val: Math.floor(Math.random() * 200) + 1},
                        {time:'5', val: Math.floor(Math.random() * 200) + 1},
                        {time:'6', val: Math.floor(Math.random() * 200) + 1},
                        {time:'7', val: Math.floor(Math.random() * 200) + 1},
                        {time:'8', val: Math.floor(Math.random() * 200) + 1},
                        {time:'9', val: Math.floor(Math.random() * 200) + 1},
                        {time:'10', val: Math.floor(Math.random() * 200) + 1}
                    ]
                },
                {
                    version: '0.98',
                    list: [
                        {time:'1', val: Math.floor(Math.random() * 200) + 1},
                        {time:'2', val: Math.floor(Math.random() * 200) + 1},
                        {time:'3', val: Math.floor(Math.random() * 200) + 1},
                        {time:'4', val: Math.floor(Math.random() * 200) + 1},
                        {time:'5', val: Math.floor(Math.random() * 200) + 1},
                        {time:'6', val: Math.floor(Math.random() * 200) + 1},
                        {time:'7', val: Math.floor(Math.random() * 200) + 1},
                        {time:'8', val: Math.floor(Math.random() * 200) + 1},
                        {time:'9', val: Math.floor(Math.random() * 200) + 1},
                        {time:'10', val: Math.floor(Math.random() * 200) + 1}
                    ]
                },
                {
                    version: '0.99',
                    list: [
                        {time:'1', val: Math.floor(Math.random() * 200) + 1},
                        {time:'2', val: Math.floor(Math.random() * 200) + 1},
                        {time:'3', val: Math.floor(Math.random() * 200) + 1},
                        {time:'4', val: Math.floor(Math.random() * 200) + 1},
                        {time:'5', val: Math.floor(Math.random() * 200) + 1},
                        {time:'6', val: Math.floor(Math.random() * 200) + 1},
                        {time:'7', val: Math.floor(Math.random() * 200) + 1},
                        {time:'8', val: Math.floor(Math.random() * 200) + 1},
                        {time:'9', val: Math.floor(Math.random() * 200) + 1},
                        {time:'10', val: Math.floor(Math.random() * 200) + 1}
                    ]
                }
            ]
        };
//         result.then((res) => {
        setTimeout(() => {
            this.resolveFetchData(res.data);
            this.setState({ isLoading: false });
        }, 1000);
//         });
    };
    resolveFetchData (data) {
        
    };
};
export default Server;
