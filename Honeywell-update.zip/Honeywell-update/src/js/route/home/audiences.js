import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {
  Grid, Row, Col, Table
} from 'react-bootstrap';
import classNames from 'classnames';

/* component */
import PageTitile from '../../component/pageTitle.js';
import StatWidget from '../../component/statWidget.js';
import ChoroplethMap from '../../component/choroplethMap.js';

/* common */
import Lang from '../../common/languages.js';
import StorageData from '../../common/storageData.js';

class Devices extends Component {
    constructor (props) {
        super (props);
        this.state = {
            isMapLoading: false
        };
        this.mapData = {
            totalCountry: 0,
            totalNumber: 0,
            list: []
        };
        this.env = {
            project: ''
        };
    };
    componentDidMount () {
        console.log('audiences componentDidMount');
        this.env.project = this.props.params.project;
        this.dataUpdate();
    };
    componentWillReceiveProps (nextProps) {
        if (nextProps.params.project != this.env.project)
        {
            this.env.project = nextProps.params.project;
            console.log('audiences componentWillReceiveProps', this.env.project);
            this.dataUpdate();
        }
    };
    render () {
        return (
            <Grid fluid style={{'padding-left': '10px', 'padding-right': '10px'}}>
                <Row>
                    <Col md={12}>
                        <PageTitile text={`${this.env.project}/${Lang.showText(3)}/${Lang.showText(6)}`} />
                    </Col>
                </Row>
                <Row className='audiences-panel'>
                    <Col md={12} className='audiences-panel-header'>
                        <h3>Camera online location in the world map</h3>
                    </Col>
                    <Col md={8} className='geo-map-wrapper'>
                        <ChoroplethMap data={this.mapData.list} isLoading={this.state.isMapLoading} />
                    </Col>
                </Row>
                {this.showTable()}
            </Grid>
        );
    };
    componentWillUnmount () {
        // stop refresh event
        // remove storage data
        console.log('audiences componentWillUnmount....');
    };

    dataUpdate () {
        this.doFetch('map');
    };
    doFetch (fetchType) {
        let result;
        let res;
        switch (fetchType)
        {
            case 'map':
                this.setState({ isMapLoading: true });
//                 result = SiteDashboard.getWidget(this.env['siteUuid']);
                res = {
                    data: [
                        { ISO_A3: "HUN", name: "Hungary", val: 10 },
                        { ISO_A3: "ISL", name: "Iceland", val: 16 },
                        { ISO_A3: "CHN", name: "China", val: 5 }
                ]};
//                 result.then((res) => {
                    setTimeout(() => {
                    this.resolveFetchData(res.data, 'map');
                    this.setState({ isMapLoading: false });
                    }, 1000);
//                 });
            break;
        }
    };
    resolveFetchData (source, dataType) {
        switch (dataType)
        {
            case 'map':
                this.mapData.list = source;
                this.mapData.totalCountry = source.length;
                this.mapData.totalNumber = 0;
                this.mapData.list.map((entry) => {
                    this.mapData.totalNumber += parseInt(entry['val']);
                });
            break;
        }
    };

    showTable () {
        let totalNumber = this.mapData.totalNumber;
        let data = this.mapData.list.slice(0);
        let content = [];
        content.push(
            <Row className='audiences-panel'>
                <Col md={12} className='audiences-panel-header'>
                    <h3>{`${totalNumber} Views from ${this.mapData.totalCountry} countries`}</h3>
                </Col>
                <Col md={8}>
                    <Table striped hover>
                        <tbody>
                            {
                                data.map((entry) => {
                                    let content_tr = [];
                                    let percentage = (parseInt(entry['val'])/totalNumber)*100;
                                    content_tr.push(
                                        <tr>
                                            <td>
                                                {entry['name']}
                                            </td>
                                            <td>
                                                {percentage.toFixed(1)}%
                                            </td>
                                        </tr>
                                    );
                                    return content_tr;
                                })
                            }
                        </tbody>
                    </Table>
                </Col>
            </Row>
        );
        return content;
    };
};

export default Devices;