import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {
  Panel, Grid, Row, Col, FormControl
} from 'react-bootstrap';
import FontAwesome from 'react-fontawesome';

/* component */
import PageTitile from '../../component/pageTitle.js';
import StatWidget from '../../component/statWidget.js';
import LineChart from '../../component/lineChart.js';
import DetailTable from '../../component/detailTable.js';

/* common */
import Lang from '../../common/languages.js';
import StorageData from '../../common/storageData.js';
import DataObj from '../../common/dataObj.js';

class Clip extends Component {
    constructor (props) {
        super (props);
        this.state = {
            isLoading: false,
            isWidgetLoading: false,
            linechartExpand1: true,
            detailExpand1: false,
            linechartExpand2: true,
            detailExpand2: false
        };
        this.widgetData = {
            upload: 0,
            download: 0,
            clipsize: 0
        };
        this.dataSource = {
            date: {
                interval: 7,
                startDay: 0,
                endDay: 0
            },
            dateList: [
                {text: '1 Day', value: 1},
                {text: '7 Days', value: 7},
                {text: '14 Days', value: 14},
                {text: '30 Days', value: 30},
                {text: '60 Days', value: 60},
                {text: '90 Days', value: 90}
            ]
        };
        this.timeSlot = [];
        this.lineData = {
            rowlabels: [],
            dataUnits: []
        };
        this.columnLabels = {
            name: {text: 29},
            number: {text: 27}
        };
        this.tableData = [];
        this.env = {
            project: ''
        };
    };
    componentDidMount () {
        console.log('stotageplan componentDidMount', 'this.props.params.project =', this.props.params.project);
        this.env.project = this.props.params.project;
        this.dataUpdate();
    };
    componentWillReceiveProps (nextProps) {
        if (nextProps.params.project != this.env.project)
        {
            this.env.project = nextProps.params.project;
            console.log('stotageplan componentWillReceiveProps', this.env.project);
            this.dataUpdate();
        }
    };
    render () {
        return (
            <Grid fluid>
                <Row>
                    <Col md={12}>
                        <PageTitile text={`${this.env.project}/${Lang.showText(9)}/${Lang.showText(10)}`} />
                    </Col>
                </Row>
                <Row>
                    <Col md={2} className='data-source-selector'>
                        <FormControl 
                            componentClass='select' 
                            onChange={() => {this._setDataSourceInterval();}} 
                            ref='dataSourceInterval' 
                            disabled={this.state.isLoading}
                        >
                            {
                                this.dataSource.dateList.map((entry) => (
                                    <option value={entry['value']} selected={(this.dataSource.date.interval == entry.value)?true:false}>{entry['text']}</option>
                                ))
                            }
                        </FormControl>
                    </Col>
                </Row>
                <Row>
                    <Col md={4}>
                        <StatWidget value={this.widgetData['upload']} descText={Lang.showText(37)} icon='cloud-upload' isLoading={this.state['isWidgetLoading']} color='#19b394' />
                    </Col>
                    <Col md={4}>
                        <StatWidget value={this.widgetData['download']} descText={Lang.showText(34)} icon='cloud-download' isLoading={this.state['isWidgetLoading']} color='#f0b719' />
                    </Col>
                    <Col md={4}>
                        <StatWidget value={this.widgetData['clipsize']} descText={Lang.showText(35)} icon='camera' isLoading={this.state['isWidgetLoading']} color='#5c8fc1' />
                    </Col>
                </Row>
                <Row>
                    <Col md={12}>
                        <Panel collapsible expanded={this.state.linechartExpand1} 
                            header={
                                <span className="clickable" onClick={() => {this._expandHandler('linechart1');}}>
                                    {(this.state.linechartExpand1)? <FontAwesome name="minus-square"/> : <FontAwesome name="plus-square"/>}
                                    {Lang.showText(880)}
                                </span>
                            } 
                            className='general-expand-panel'
                        >
                            <div className='linegraphTitle'>Line Graph</div>
                            <LineChart
                                Rowlabels={this.lineData.rowlabels}
                                DataUnits={this.lineData.dataUnits}
                                isLoading={this.state.isLoading}
                            />
                        </Panel>
                    </Col>
                </Row>
                <Row>
                    <Col md={12}>
                        <Panel collapsible expanded={this.state.detailExpand1} 
                            header={
                                <span className="clickable" onClick={() => {this._expandHandler('detail1');}}>
                                    {(this.state.detailExpand1)? <FontAwesome name="minus-square"/> : <FontAwesome name="plus-square"/>}
                                    {Lang.showText(30)}
                                </span>
                            } 
                            className='general-expand-panel'
                        >
                            {this.showTable()}
                        </Panel>
                    </Col>
                </Row>
                <Row>
                    <Col md={12}>
                        <Panel collapsible expanded={this.state.linechartExpand2} 
                            header={
                                <span className="clickable" onClick={() => {this._expandHandler('linechart2');}}>
                                    {(this.state.linechartExpand2)? <FontAwesome name="minus-square"/> : <FontAwesome name="plus-square"/>}
                                    {Lang.showText(881)}
                                </span>
                            } 
                            className='general-expand-panel'
                        >
                            <div className='linegraphTitle'>Line Graph</div>
                            <LineChart
                                Rowlabels={this.lineData.rowlabels}
                                DataUnits={this.lineData.dataUnits}
                                isLoading={this.state.isLoading}
                            />
                        </Panel>
                    </Col>
                </Row>
                <Row>
                    <Col md={12}>
                        <Panel collapsible expanded={this.state.detailExpand2} 
                            header={
                                <span className="clickable" onClick={() => {this._expandHandler('detail2');}}>
                                    {(this.state.detailExpand2)? <FontAwesome name="minus-square"/> : <FontAwesome name="plus-square"/>}
                                    {Lang.showText(30)}
                                </span>
                            } 
                            className='general-expand-panel'
                        >
                            {this.showTable()}
                        </Panel>
                    </Col>
                </Row>
            </Grid>
        )
    };

    dataUpdate () {
        this.setupConfig();
        this.doFetchLineChart();
        this.doFetchWidget();
    };
    setupConfig () {
        // 2018-12-10T01:29:30.201L, toISOString()
        let today = new Date().toISOString().split(".")[0];
        // 2018-12-10T01:29:30-06:00
        let dateOBJ = new DataObj.dateTimeObj(today+'+00:00');
//         console.log(dateOBJ.epochTime);
//         console.log(dateOBJ.epochTime+86400-1);
        let epochTodate = new Date(dateOBJ.epochTime*1000);
//         console.log(epochTodate.toLocaleDateString('ja-JP'));

        let interval = this.dataSource.date.interval;
        this.dataSource.date.startDay = dateOBJ.epochTime - ((interval-1)*86400);
        this.dataSource.date.endDay = dateOBJ.epochTime + 86400 - 1;

        this.timeSlot = [];
        let startTime = this.dataSource.date.startDay;
        let endTime = 0;

        if (interval == 1)
        {
            // hour basis
            endTime = this.dataSource.date.startDay + 3600 - 1;

            for (let i=0; i<24; i++)
            {
                let obj = {};
                obj['label'] = ('0' + i).slice(-2) + ':00';
                obj['startTime'] = startTime + (i*3600);
                obj['endTime'] = endTime + (i*3600);
                this.timeSlot.push(obj);
            }
        }
        else if (interval == 7 || interval == 14 || interval == 30 || interval == 60 || interval == 90)
        {
            // daily basis
            endTime = this.dataSource.date.startDay + 86400 - 1;

            for (let i=0; i<interval; i++)
            {
                let obj = {};
                let dateObj = new Date((startTime + (i*86400))*1000);
                obj['label'] = dateObj.getFullYear() + '/' + ('0' + (dateObj.getMonth()+1)).slice(-2) + '/' + ('0' + dateObj.getDate()).slice(-2);
                obj['startTime'] = startTime + (i*86400);
                obj['endTime'] = endTime + (i*86400);;
                this.timeSlot.push(obj);
            }
        }
        console.log('this.timeSlot =', this.timeSlot);
    };
    doFetchLineChart () {
        let result;
        let res;
        this.setState({isLoading: true});
//         result = SiteDashboard.getWidget(this.env['siteUuid']);
        res = {
            data: [
                {
                    name: 'C0',
                    list: [
                        {timestamp:'00:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'00:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'01:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'02:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'03:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'04:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'05:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'06:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'07:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'08:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'09:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'10:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'11:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'12:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'13:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'14:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'15:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'16:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'17:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'18:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'19:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'20:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'21:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'22:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'23:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/11/29', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/11/30', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/01', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/02', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/03', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/04', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/05', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/05', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/06', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/07', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/08', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/08', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/09', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/10', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/10', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/11', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/12', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/13', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/14', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/15', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/16', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/17', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/18', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/19', val: Math.floor(Math.random() * 200) + 1}
                    ]
                },
                {
                    name: 'C1',
                    list: [
                        {timestamp:'00:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'01:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'02:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'03:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'04:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'05:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'06:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'07:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'08:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'09:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'10:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'11:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'12:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'13:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'14:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'14:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'15:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'16:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'17:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'18:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'19:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'20:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'21:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'22:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'23:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/11/29', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/11/30', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/01', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/02', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/03', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/04', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/05', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/06', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/06', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/07', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/08', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/08', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/09', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/10', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/10', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/11', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/12', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/13', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/14', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/15', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/16', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/17', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/18', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/19', val: Math.floor(Math.random() * 200) + 1}
                    ]
                },
                {
                    name: 'C2',
                    list: [
                        {timestamp:'00:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'01:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'02:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'03:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'04:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'05:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'06:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'07:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'08:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'09:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'10:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'11:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'12:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'13:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'14:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'15:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'16:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'17:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'18:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'18:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'19:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'20:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'21:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'22:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'23:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/11/29', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/11/30', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/01', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/02', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/03', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/04', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/05', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/05', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/06', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/07', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/08', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/08', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/09', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/10', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/10', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/11', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/12', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/13', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/14', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/15', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/16', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/17', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/18', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/19', val: Math.floor(Math.random() * 200) + 1}
                    ]
                }
            ]
        };
//         result.then((res) => {
        setTimeout(() => {
            this.resolveLineData(res.data);
            this.setState({ isLoading: false });
        }, 1000);
//         });
    };
    resolveLineData (source) {
        let tableDataBucket = {};
        this.lineData.rowlabels = [];
        this.timeSlot.map((slot) => {
            this.lineData.rowlabels.push(slot.label);
            tableDataBucket[slot.label] = {};
            source.map((entry) => {
                tableDataBucket[slot.label][entry.name] = 0;
            });
        });
        this.lineData.dataUnits = [];
        source.map((entry) => {
            let lineDataBucket = {};
            this.timeSlot.map((slot) => {
                lineDataBucket[slot.label] = 0;
            });
            let lineObj = {};
            lineObj['name'] = entry.name;
            lineObj['data'] = [];
            entry.list.map((list) => {
                if (!isNaN(list.timestamp))
                {
                    let time = parseInt(list.timestamp);
                    for (let i=0; i<this.timeSlot.length; i++)
                    {
                        if (this.timeSlot[i].startTime && this.timeSlot[i].endTime)
                        {
                            if (this.timeSlot[i].startTime <= time && time <= this.timeSlot[i].endTime)
                            {
                                if (lineDataBucket.hasOwnProperty(this.timeSlot[i].label)) lineDataBucket[this.timeSlot[i].label] += parseInt(list.val);
                                if (tableDataBucket.hasOwnProperty(this.timeSlot[i].label)) tableDataBucket[this.timeSlot[i].label][entry.name] += parseInt(list.val);
                                break;
                            }
                        }
                    }
                }
                else
                {
                    if (lineDataBucket.hasOwnProperty(list.timestamp))
                    {
                        lineDataBucket[list.timestamp] += parseInt(list.val);
                    }
                    if (tableDataBucket.hasOwnProperty(list.timestamp))
                    {
                        tableDataBucket[list.timestamp][entry.name] += parseInt(list.val);
                    }
                }
            });
//             console.log('lineDataBucket =', lineDataBucket);
            Object.keys(lineDataBucket).map((label) => {
                lineObj['data'].push(lineDataBucket[label]);
            });
            this.lineData.dataUnits.push(lineObj);
        });
//         console.log('this.lineData.rowlabels =', this.lineData.rowlabels);
//         console.log('this.lineData.dataUnits =', this.lineData.dataUnits);

//         console.log('tableDataBucket =', tableDataBucket);
        this.tableData = [];
        Object.keys(tableDataBucket).map((time) => {
            let obj = {};
            obj['title'] = time;
            obj['dataUnits'] = [];
            Object.keys(tableDataBucket[time]).map((name) => {
                let tableObj = {};
                tableObj['name'] = name;
                tableObj['number'] = tableDataBucket[time][name];
                obj['dataUnits'].push(tableObj);
            });
            this.tableData.push(obj);
        });
//         console.log('this.tableData =', this.tableData);
    };
    doFetchWidget () {
        let res;
        this.setState({isWidgetLoading: true});
        res = {
            data: {
                upload: '70,000',
                download: '60,000',
                clipsize: '780,000'
            }
        };
        setTimeout(() => {
            this.resolveWidgetData(res.data);
            this.setState({ isWidgetLoading: false });
        }, 1000);
    };
    resolveWidgetData (source) {
        Object.keys(this.widgetData).map((entry) => {
            this.widgetData[entry] = source[entry];
        });
    };

    showTable () {
        let content = [];
        let data = this.tableData.slice(0);
        let rowLabels = JSON.parse(JSON.stringify(this.columnLabels));
        if (data.length)
        {
            data.map((entry) => {
                content.push(
                    <DetailTable 
                        Title={entry['title']} 
                        ColumnLabels={rowLabels} 
                        DataUnits={entry['dataUnits']} 
                        isLoading={this.state.isLoading}
                    />
                );
            });
        }
        return content;
    };

    _expandHandler (panelType) {
        switch (panelType)
        {
            case 'linechart1':
                this.setState({ linechartExpand1: !this.state.linechartExpand1 });
                break;
            case 'detail1':
                this.setState({ detailExpand1: !this.state.detailExpand1});
                break;
            case 'linechart2':
                this.setState({ linechartExpand2: !this.state.linechartExpand2 });
                break;
            case 'detail2':
                this.setState({ detailExpand2: !this.state.detailExpand2});
                break;
        };
    };
    _setDataSourceInterval () {
        let interval = parseInt(ReactDOM.findDOMNode(this.refs['dataSourceInterval']).value);
        this.dataSource.date.interval = interval;
        this.dataUpdate();
    };
};
export default Clip;