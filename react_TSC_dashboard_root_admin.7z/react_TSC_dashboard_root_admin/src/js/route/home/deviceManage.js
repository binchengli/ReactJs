import React, {  useState,Component } from 'react';
import ReactDOM from 'react-dom';
import {
  Panel, Grid, Row, Col, FormControl, Table, DropdownButton, MenuItem, Pagination, Button, Form ,InputGroup,FormGroup,Nav,Navbar,NavItem, ControlLabel
} from 'react-bootstrap';
import Dialog from 'react-bootstrap-dialog';
import FontAwesome from 'react-fontawesome';
import { Link, hashHistory } from 'react-router';
/* component */
import PageTitile from '../../component/pageTitle.js';
import ServerAPI from '../../backendAPI/server.js';
import GetAccounts from '../../backendAPI/getAccount.js';
/* common */
// import Lang from '../../common/languages.js';
import StorageData from '../../common/storageData.js';
import MulitLangFile from '../../common/multiLang.js';
const styleLabel={'font-weight':'bold','text-align':'right','vertical-align': 'middle','line-height':'30px','height':'30px',color:'#555'};
const stylemail={ 'text-align':'left',color: "#555" ,width:'70%','margin-left':'10px','padding-left':'10px','padding-right':'10px' ,'vertical-align': 'middle',display:' table-cell','line-height':'30px','height':'30px'};
const modalOpen ={'position': 'absolute',top:'0px',right:'0px','height':'calc(100vh - 110px)','width': '70%','border-radius':'3px','z-index': 3000,'background-color': '#ffffff',
                'margin-top': '0%','margin-left': '20%',  'max-height':'calc(100vh - 110px)','overflow-y': 'auto','overflow-x':'hidden',
                '-webkit-box-shadow': '10px 10px 10px -8px rgba(0,0,0,0.3)',opacity:'1'
                    //,'-webkit-transition': 'all 350ms cubic-bezier(0.680, -0.550,  0.265,  1.18)' 
                    ,'-moz-transition':'width 1s',
                    '-webkit-transition':'width 1s',
                    '-o-transition':'width 1s',
                    }
const modalClose = {'position': 'absolute',top:'0px',right:'0px','margin-top': '0px','margin-left': '0px','z-index': 3000,opacity:'1',
                        'height':'calc(100vh - 110px)',  'max-height':'calc(100vh - 110px)', width: '0px','background-color': '#ffffff','overflow-y': 'hidden',
                   // '-webkit-transition': 'all 350ms cubic-bezier(0.680, -0.550,  0.265,  1.18)'  
                   '-moz-transition':'width 1s',
                    '-webkit-transition':'width 1s',
                    '-o-transition':'width 1s',
  }


                    var contentFunction = {
                        changePage(page) {
                            if(page==0){
                                var config={
                                    "data": {
                                     "activation_state": true,
                                     "audio_detection": "on",
                                     "audio_sensitivity": 66,
                                     "device_name": "5F GOP Longrun Camera",
                                     "devid": "D76913617ECC28259D166B14E30429338BBE9C505834EA7D2044F9ACFF3D840E",
                                     "dst": "off",
                                     "fwcheck_interval": 3600,
                                     "led_status": "on",
                                     "location": "",
                                     "mic_status": "on",
                                     "motion_area": [
                                      {
                                       "height": 1080,
                                       "sensitivity": 33,
                                       "shape": "rectangle",
                                       "start_x": 0,
                                       "start_y": 0,
                                       "width": 1920
                                      }
                                     ],
                                     "motion_detection": "on",
                                     "motion_zone": "rectangle",
                                     "night_mode": "auto",
                                     "ping_interval": 20,
                                     "privacy_mode": "off",
                                     "recording_ahead": 5,
                                     "speaker_status": "on",
                                     "storage_plan": "day",
                                     "timezone": "+0:00",
                                     "tz": "UTC",
                                     "version": "1.0"
                                    }
                                   };
                                   let content = [];
                                   if(config&&config.data)
                                   {
                                         for (let [key, value] of Object.entries(config.data))
                                        {
                                           
                                            content.push( <FormGroup>  
                                                <Col componentClass={ControlLabel} md={3}  style={styleLabel}>{key}</Col>
                                                <div style={stylemail}>{typeof value=='object'?JSON.stringify(value):value}</div>
                                        
                                                </FormGroup>);
                                           
                                           
                                        }
                                      
                                   }
                                   

                                    return content;
                   
                            }else if(page==1){
                                var info={
                
                                    "data": {
                                     "firmware_version": "v0.65_2019-10-05",
                                     "ip": "36.224.108.4",
                                     "last_update_time": "2019-10-18 05:26:49",
                                     "mac": "409F387EF63D",
                                     "manufacturer": "Edimax",
                                     "max_motion_areas": "4",
                                     "max_res": "1920x1080",
                                     "model_name": "3231GLP",
                                     "project": "Unknown",
                                     "protocol_version": "050060",
                                     "serial_number": "112233445566",
                                     "status": "online",
                                     "vendor": "Unknown",
                                     "wifi_strength": "70"
                                    }
                                   };
                                let content = [];
                                /*data.forEach(function(element) {
                                    content.push( <FormGroup>  
                                        <Col componentClass={ControlLabel} md={2}  style={styleLabel}>{element['timestamp']}</Col>
                                        <div style={stylemail}>{element['message']}</div>
                                
                                        </FormGroup>);
                                });*/
                                if(info&&info.data)
                                {
                                      for (let [key, value] of Object.entries(info.data))
                                     {
                                
                                         content.push( <FormGroup>  
                                             <Col componentClass={ControlLabel} md={3}  style={styleLabel}>{key}</Col>
                                             <div style={stylemail}>{value}</div>
                                     
                                             </FormGroup>);
                                        
                                        
                                     }
                                   
                                }
                            
                                return content;
                        
                            }
                        }
                      };    
                    
                    const Content = React.createClass({
                        mixins: [contentFunction],
                        getInitialState () {
                            return {
                                page:0
                            };
                          },
                      render () {
                        return (
                          <div  
                            className={this.props.open 
                              ? "content-wrapper content-open"
                              : "content-wrapper"}
                          >
                            
                           
                            <Navbar style={{'vertical-align': 'middle'}} >
                        
                            <Nav justify variant="tabs" >
                                <NavItem onClick={()=>{this.setState({page:0})}}>
                                    Configuration
                                </NavItem>
                                <NavItem onClick={()=>{this.setState({page:1})}}>
                                   Info
                                </NavItem>
                                 
                                
                               
                            </Nav>
                            <div  style={{position:"absolute",right:'0px'}}>
                               <FontAwesome style={{'padding-top':'8px','padding-bottom':'8px'}} name='times-circle' size="2x"  fixedWidth 
                                    onClick={this.props.buttonClick}
                                ></FontAwesome> 
                          
                                </div>
                        </Navbar>     
                        
                               {/* <p >
                               {this.props.bodyText}
                            </p>   */}
                           
                            {contentFunction.changePage(this.state.page)}
                         
                           
                          </div>
                        );
                      }
                      
                    });     

class deviceManage extends Component {
    constructor (props) {
        super (props);
        this.logindata=JSON.parse(ServerAPI.getLoginInfo());
        this.state = {
            currentLanguage:props.language,
            isLoading: false,
			placeholder: 'Device ID',
            activePage:1,
            accountuuid:'',
            detailOpen:false
        };
        this.dataSource = '';
        this.tableParams = {
            headerLength: 0,
            matchAll: false,
            searchedCount: 1,
            searchedTag: [],
            sortedOrder: [],
            dataPerPage: 25,
            lastPage: 1,
            resultData:[]
        };
        this.tableHeader = {
            mac: {show: true, text: 'MAC ID'},
            model: {show: true, text: 'Model'},
            status: {show: true, text: 'Status'},
            owner:{show:true,text: 'User Name'},
            email:{show:true,text: 'E-mail'},
            createdate: {show: true, text: 'Registration Date'},
            delete: {show:true ,text: ''}
           
        };
        this.tableData = [];
        this.env = {
            project: ''
        };
        
        this.handleClick = this.handleClick.bind(this);
    };

    componentDidMount () {
        this.env.project = this.props.params.project;
        if(!this.state.accountuuid)
        {
            this.setState({accountuuid:this.props.accountuuid});
            this.doFetch(this.props.accountuuid);
        }
        // this.dataUpdate();
    };
    componentWillReceiveProps (nextProps) {
        if (nextProps.accountuuid != this.state.accountuuid)
        {
            
            this.env.project = nextProps.params.project;
            this.setState({accountuuid:nextProps.accountuuid});
            this.doFetch(nextProps.accountuuid);
        }
    };

    

    render () {
        this.tableRefresh();
        return (
            <Grid fluid >
                {/* <Row>
                    <Col md={12}>
                          <PageTitile text={`${this.logindata.root?`Edimax`:`Edimax/ ${this.logindata.alias}`}`} />
                    </Col>
                </Row> */}
                <Row >
                    <div md={12} style={{position:'inherit',paddingLeft:'10px',paddingRight:'10px'}}>
                        <div className='general-panel' >
                            <div style={{'background-color':'#f5f5f5',padding:'10px','border-top':'1px solid #ddd','border-right':'1px solid #ddd','border-left':'1px solid #ddd'}}>
                                    {`${MulitLangFile.MulitLang.deviceManage[this.state.currentLanguage ]}/ `}
                                    <strong style={{'font-weight':'700','height':'16px', 'font-size': '15px',color:'inherit'}}>
                                    {`${MulitLangFile.MulitLang.manage[this.state.currentLanguage ]}`}
                                    </strong>
                             </div>
                             <div style={this.state.detailOpen?modalOpen:modalClose}
                             className="inner-zindex"
                            >
                            <Content 
                                open={this.state.detailOpen}
                                bodyText= "Hello World"
                                buttonClick={()=>{this.setState({detailOpen:false})}}
                            />
                            </div> 
                            <Panel>
                            <div className='general-panel-content'>
                                <Row>
                                    {this.showSearchBar()}                                                  
                                </Row>
                                <Row style={{'overflow':'auto'}}>
                                    {this.tableData?this.showTable():[]}
                                </Row>
                                <Row>
                                    {this.showPaged()}
                                </Row>
                                <div>
                            <Dialog ref={(el) => { this.dialog = el }} />
                            
                            </div>
                            </div>
                            </Panel>
                        </div>
                    </div>
                </Row>
            </Grid>
        );
    };

    doFetch (accountuuid) {
        let res={

            data: [
                {
                    "mac": "74DA38123456",
                    "model": "IC-3231GLP",
                    "status": "online",
                    "owner": "Peter Tsai",
                    "email": "peter_tsai@edimax.com.tw",
                    "createdate":0
                }, {
                    "mac": "74DA38111111",
                    "model": "IC-3231GLP",
                    "status": "online",
                    "owner": "Peter Tsai",
                    "email": "peter_tsai@edimax.com.tw",
                    "createdate":0
                    
                }, {
                    "mac": "74DA38222222",
                    "model": "IC-3231GLP",
                    "status": "online",
                    "owner": "Peter Tsai",
                    "email": "peter_tsai@edimax.com.tw",
                    "createdate":0
                
                }
            ]
        };
        this.setState({isLoading: true});
        if(res){
            this.resolveFetchData(res.data);
            this.setState({ isLoading: false });
        }else{
            if(accountuuid&&accountuuid!='')
        {
            result = GetAccounts.getAccountList(accountuuid);
            result.then((res) => {
               if(res)
               { 
                    if(ServerAPI.isLog)console.log("account fetch res data="+JSON.stringify(res));
                    if(res.data==null)
                   {
                   }else
                   {
                        //confirm('Get Success ');
                        
                       this.resolveFetchData(res.data);
                   }
                   this.setState({ isLoading: false });
               }
               else
               {
                   //alert('Current password invalid!');
                   if(res&&res.message)alert(res.message);
                   else
                   alert('get Account List Fail.');
                   this.setState({ isLoading: false });
               }
           });
        }
             
        }
         
        
    };

    resolveFetchData (source) {
        this.dataSource=source;
        let dataArray = [];
        if(source)
        {
            let data = source.slice(0);
            data.map((entry, index) => {
                dataArray[index] = entry;
                dataArray[index]['id'] = index+1;
            });

            this.tableData = dataArray//.reverse()
            .slice(0);
        }else
            this.tableData = dataArray;
        
        this.initTable(dataArray);
    };

 

    initTable (data) {
        data.map((entry, index) => {
            this.tableParams.searchedTag[index] = 1;
            this.tableParams.sortedOrder[index] = index;
        });
        this.tableParams.searchedCount = 1;
        this.tableParams.matchAll = false;
        this.tableParams.lastPage = Math.ceil(data.length / this.tableParams.dataPerPage);
       // this.setState({ activePage: 1 });
    };
    tableRefresh () {
        this.tableParams.resultData = [];
        let countLength = 0;
        let data = this.tableData.slice(0);
        data.map((entry, index) => {
            if (this.tableParams.matchAll)
            {
                if (this.tableParams.searchedCount == this.tableParams.searchedTag[index])
                {
                    this.tableParams.resultData[countLength] = this.tableParams.sortedOrder[index];
                    countLength++;
                }
            }
            else
            {
                if (0 < this.tableParams.searchedTag[index])
                {
                    this.tableParams.resultData[countLength] = this.tableParams.sortedOrder[index];
                    countLength++;
                }
            }
        });
        /* update pagedInfo */
        this.tableParams.lastPage = Math.ceil(countLength / this.tableParams.dataPerPage);
    };

    showSearchBar () {
        let content = [];
        content.push(
            <Col md={4} mdOffset={0}>
                <FormGroup>
                    <InputGroup>
                        <FormControl ref='searchInput' type='text' placeholder={'Please enter search criteria'} onChange={()=>this._searchHandler()} />
                        <InputGroup.Addon>
                            <FontAwesome name='search' />
                        </InputGroup.Addon>
                    </InputGroup>
                </FormGroup>
            </Col>
        );
        // content.push(
        //     <Col md={2} className='matchAllToggle'>
        //         <Checkbox
        //             checkboxClass={ConstDef.ICHECK_STYLE}
        //             increaseArea="20%"
        //             label={'105'}
        //             checked={this.tableParams['matchAll']}
        //             onChange={()=>this._searchMatchAllHandler()}
        //         />
        //     </Col>
        // );
        return content;
    };

    _searchHandler(){
        let searchinput = ReactDOM.findDOMNode(this.refs.searchInput).value.split(' ').filter((entry) => ('' != entry));
        let data = this.tableData.slice(0);
        let dataTag = this.tableParams['searchedTag'].slice(0);
        if (0 == searchinput.length) { searchinput[0] = ''; }
        data.map((entry,entryIndex) => {
            let count = 0;
            searchinput.map((input) => {
                let inputLowCase = new RegExp(input, 'i');
                for (let obj in entry)
                {
                    let objContent = '';
                    objContent = entry[obj];

                    if (inputLowCase.test(objContent)) 
                    {
                        count+=1;
                        break;
                    }
                }
            });
            dataTag[entryIndex] = count;
        });
        this.tableParams['searchedCount'] = searchinput.length;
        this.tableParams['searchedTag'] = dataTag.slice(0);
        this.setState({ lastPage: 1 });
    };

    showTable () {
        let content = [];
        content.push(
            <Col md={12}> 
                <Table striped bordered hover >
                    {this.showTableHeader()}
                    {this.showTableBody()}
                </Table>
            </Col>
        );
        return content;
    };

    handleClick(entry)
    {
        
        
    }

    showTableHeader () {
        let content = [];
        let count = 0;
        content.push(
            <thead>
                <tr style={{'background-color':'#2a3f54',color:'white'}} >
                    {
                        Object.keys(this.tableHeader).map((entry) => {
                            let content_th = [];
                            switch (entry)
                            {
                                case 'alias':
                                case 'userid':
								if(this.tableHeader[entry].show)content_th.push(
                                        <th style={{'text-align':"left"}}>{this.tableHeader[entry].text}</th>
                                    );
                                    break;
                                default:
									if(this.tableHeader[entry].show)content_th.push(
                                        <th style={{'text-align':"left"}}>{this.tableHeader[entry].text}</th>
                                    );
                                    break;
                            };
                            count++;
                            return content_th;
                        })
                    }
                </tr>
            </thead>
        );
        this.tableParams.headerLength = count;
        return content;
    };
    showTableBody () {
        let data = this.tableData.slice(0);
        let contentIndex = this.tableParams.resultData.slice(0);
        let contentStart = (this.state.activePage-1) * this.tableParams.dataPerPage;
        let contentEnd = Math.min((this.state.activePage * this.tableParams.dataPerPage) , this.tableParams.resultData.length);
        let content = [];
        let index = 0, count = 0, tableInfo = [];
        for (let i=contentStart; i<contentEnd; i++)
        {
            index = contentIndex[i];
            tableInfo[count] = data[index];
            count++;
        }
        let roottr={'background-color':'#f0f0f0'}//??f9f9f9
        let styleRoot={'text-align':"left"};
        let styleIcon={'text-align':"center"};
         let styleRole={'text-align':"left",'text-transform':'capitalize'};
        // let styleother={'text-align':"left",'padding-left': '50px'};
        //onClick={this.handleClick.bind(this,entry)} style={entry.role!='Operator'?{'cursor': 'pointer'}:{}}
        content.push(
            <tbody>
                {
                   
                    tableInfo.map((entry) => {
                        let content_tr = [];
                        content_tr.push(
                            <tr >
                                {
                                    Object.keys(this.tableHeader).map((info) => {
                                        let content_td = [];
                                        switch (info)
                                        {
                                            case 'alias':
                                                if(this.tableHeader[info].show)content_td.push(
                                                    <td style={styleRoot}>{entry[info]}</td>
                                                    //<td className='text-left'>{entry[info]}</td>
                                                );
                                                break;
                                                case 'userid':
                                                if(this.tableHeader[info].show)
                                                    content_td.push(
                                                        (entry[info].indexOf('@') != -1)?<td style={styleRoot}>{entry[info]}</td>
                                                            :<td style={styleRoot}>{entry[info]+'@gmail.com'}</td>
                                                  
                                                    //<td className='text-left'>{entry[info]}</td>
                                                );
                                                break;
                                                case 'createTime':
                                                if(this.tableHeader[info].show)content_td.push(
                                                    <td style={styleRoot}>{this.getDate(entry[info])}</td>
                                                    //<td className='text-left'>{entry[info]}</td>
                                                );
                                                break;
                                                case 'role':
                                                if(this.tableHeader[info].show)
                                                    content_td.push( <td style={styleRole}>{entry[info]==''?"Admin":entry[info]}</td>)
                                                {/* (entry.role=='Root Admin')?
                                                    content_td.push( <td style={styleRoot}>{entry[info]}</td>)
                                                :content_td.push(
                                                    <td style={styleRoot}>{entry[info].split('/').length==3?'Operator':<Link to={{pathname:'/home/account/info',state:{alias:entry.alias,mail:entry.mail,role:'Admin'}}} >Admin</Link>}</td>
                                                ); */}
                                                break;
                                                case 'delete':
                                                    if(this.tableHeader[info].show)content_td.push(
                                                    <td style={{align:'center'}}> 
                                                    <div style={styleIcon}>
                                                    <FontAwesome name='trash' size="2x"  fixedWidth 
                                                        onClick={
                                                            ()=>{
                                                                this.dialog.show({
                                                                title: 'Delete',
                                                                body: 'Are you sure to delete this device?',
                                                                actions: [
                                                                Dialog.CancelAction(),
                                                                Dialog.OKAction()
                                                                ],
                                                                bsSize: 'small',
                                                                onHide: (dialog) => {
                                                                dialog.hide()
                                                                //console.log('closed by clicking background.')
                                                                }
                                                                });
                                                            }
                                                        }
                                                        />
                                                        <FontAwesome  style={{'&:hover':{'animation': 'pulse .3s 2'}}} name='info-circle' size="2x"  fixedWidth onClick={()=>this.buttonDetailClick(entry)}> </FontAwesome>

                                                        {/* <ModalDialog 
                                                            open={false}
                                                             buttonClick={ (e)=>{
                                                                 //this.setState({detailOpen:false})
                                                                    e.target.open=!e.target.open
                                                                 }
                                                            }/> */}
                                                    </div>

                                                    </td>
                                                    //<td className='text-left'>{entry[info]}</td>
                                                );
                                                    break;
                                            default:
											if(this.tableHeader[info].show)content_td.push(
                                                    <td style={styleRoot}>{entry[info]}</td>
                                                );
                                                break;
                                        };
                                        return content_td;
                                    })
                                }
                            </tr>
                        );
                        return content_tr;
                    })
                }
                {
                    
                    ( this.state.isLoading)? (<tr><td colSpan={this.tableParams['headerLength']} className='text-center'>Loading ...</td></tr>) :
                    (0 == tableInfo.length)? (<tr><td colSpan={this.tableParams['headerLength']} className='text-center'>No Data Available.</td></tr>) :[]
                }
            </tbody>
        );
        return content;
    };

    buttonDetailClick (entry) {
        console.log("buttonDetailClick");
        this.setState({detailOpen: !this.state.detailOpen}); 
    
      }

    showloading()
    {
        let content = [];
        content.push(<tr><td colSpan={this.tableParams['headerLength']} className='text-center'>Loading ...</td></tr>);
        return content;
    }

    showPaged () {
        const pagedOptions = new Array(
            {value: 10},
            {value: 25},
            {value: 50},
            {value: 100},
        );
        let content = [];
        let showStart = 0;
        if (0 < this.tableParams.resultData.length)
        {
			showStart = (this.state.activePage-1) * this.tableParams.dataPerPage + 1;
        }
        let showEnd = Math.min((this.state.activePage * this.tableParams.dataPerPage) , this.tableParams.resultData.length);
        content.push(
            <Col md={12} className='tables-paging'>
                <div className='pageinfo'>
                    <span>{MulitLangFile.showText("Showing %0-%1 of %2 records.", showStart, showEnd, this.tableParams['resultData'].length)}</span>
                    <span>Items per page: </span>
                    <DropdownButton title={this.tableParams.dataPerPage} onSelect={(eventKey) => this._perPageHandler(eventKey)} dropup>
                        {
                            pagedOptions.map((entry) => (
                                <MenuItem eventKey={entry.value}>{entry.value}</MenuItem>
                            ))
                        }
                    </DropdownButton>
                    <span>Page(s): </span>
                    <Pagination
                        // prev
                        // next
                        first
                        last
                        ellipsis={false}
                        items={this.tableParams.lastPage}
                        maxButtons={9}
                        activePage={this.state.activePage}
                        onSelect={(eventKey) => {this._pagedHandler(eventKey);}}
                    />
                </div>
            </Col>
        );
        return content;
	};
	
	_pagedHandler (eventKey) {
        this.tableParams['lastPage'] = eventKey;
        this.setState({ activePage: eventKey });
        this.resolveFetchData(this.dataSource);
       
	};
	
	_perPageHandler (eventKey) {
        this.tableParams['lastPage'] = 1;
        this.tableParams['dataPerPage'] = eventKey;
        this.setState({ activePage: 1 });
        this.resolveFetchData(this.dataSource);
    };

    _setDeviceIDorMAC (entry) {
        if(1 == ReactDOM.findDOMNode(this.refs[`dataSourceType`]).value)
            this.state.placeholder = 'Device ID';
        else
            this.state.placeholder = 'MAC';
        this.setState(this.state);
    }
    _setDataSourceType () {
        
    };
    _setDataSourceDevId () {
        
    };
    _setDataSourceInterval () {
        
    };

        getDate(timestamp)
        {
            if(timestamp==0||timestamp=='')
            {
                    return timestamp;
            }
            if(timestamp<1552718400)
            {
                    return timestamp;
            }else if(timestamp.toString().length==10)
            {
                timestamp=timestamp*1000;
            }else if(timestamp<1552718400000)
            {
                return timestamp;
            }
            var zone=parseInt(this.logindata.timezone); 
            
            var date = new Date(timestamp+(zone*60*60*1000) );

            var year = date.getUTCFullYear();
            var month = date.getUTCMonth() + 1; // getMonth() is zero-indexed, so we'll increment to get the correct month number
            var day = date.getUTCDate();
            var hours = date.getUTCHours();
            var minutes = date.getUTCMinutes();
            var seconds = date.getUTCSeconds();

            month = (month < 10) ? '0' + month : month;
            day = (day < 10) ? '0' + day : day;
            hours = (hours < 10) ? '0' + hours : hours;
            minutes = (minutes < 10) ? '0' + minutes : minutes;
            seconds = (seconds < 10) ? '0' + seconds: seconds;
            if(this.logindata.timeformat==1){
                return month + '/' + day+ '/' +  year + ' ' + hours + ':' + minutes+ ':' + seconds;
            }else
                return year + '/' + month + '/' + day + ' ' + hours + ':' + minutes+ ':' + seconds;
        }
};
export default deviceManage;