import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {
  Panel, Grid, Row, Col, FormControl, Table, DropdownButton, MenuItem, Pagination, Button ,Form ,InputGroup,FormGroup,Image
} from 'react-bootstrap';
import { hashHistory } from 'react-router';
import FontAwesome from 'react-fontawesome';

/* component */
import PageTitile from '../../component/pageTitle.js';
import ServerAPI from '../../backendAPI/server.js';
import DeviceAPI from '../../backendAPI/DeviceAPI.js';

/* common */
import StorageData from '../../common/storageData.js';
import MulitLangFile from '../../common/multiLang.js';

class Device extends Component {
    constructor (props) {
        super (props);
        this.logindata=JSON.parse(ServerAPI.getLoginInfo());
        this.state = {
            isLoading: false,
            placeholder: 'Device ID',
            sortDeviceName:'sort',
            sortStatus:'sort',
            sortModel:'sort',
            sortMAC:'sort',
            sortDeviceID:'sort',
            sortOwner:'sort',
            deviceActivePage:1,
            allDeviceList:0
        };

        this.dataSource = {
            type: 1,
            devId: '',
        };

        this.deviceTableParams = {
            headerLength: 0,
            matchAll: false,
            searchedCount: 1,
            searchedTag: [],
            sortedOrder: [],
            dataPerPage: 25,
            lastPage: 1,
            resultData:[]
        };
        this.deviceTableHeader = {
            devname: {show: true, text: 'Device Name'},
            status: {show: true, text: 'Status'},
            model: {show: true, text: 'Model'},
            mac: {show: true, text: 'MAC'},
            devid: {show:true ,text: 'Device ID'},
            owner:{show:true,text: 'Owner'}
        };
        this.deviceTableData = [];
        this.env = {
            project: ''
        };
    };

    componentDidMount () {
        this.env.project = this.props.params.project;
        this.doFetch();
    };

    componentWillReceiveProps (nextProps) {
        this.setState({ isLoading: true });
    };

    render () {
        this.tableRefresh();
        return (
            <Grid fluid>
                {/* <Row>
                    <Col md={12}>
                    <PageTitile text={`${this.logindata.root?`Edimax`:`Edimax/${this.logindata.alias}`}`} />
                    </Col>
                </Row> */}
                <Row>                    
                    <Col md={12}>
                        <div className='general-panel'>
                            <div style={{'background-color':'#f5f5f5',padding:'10px','border-top':'1px solid #ddd','border-right':'1px solid #ddd','border-left':'1px solid #ddd'}}>
                                {`${MulitLangFile.MulitLang.deviceManage[MulitLangFile.getLanguage ]}/`}
                                <strong style={{'font-weight':'700','height':'16px', 'font-size': '15px',color:'inherit'}}>
                                    {` ${MulitLangFile.MulitLang.manage[MulitLangFile.getLanguage]}`}
                                </strong>
                            </div>
                            <Panel>
                            <div>
                                <Row>
                                    {this.showSearchBar()}                                                    
                                </Row>
                                <Row style={{'overflow':'auto'}}>
                                    {this.showDeviceTable()}
                                </Row>
                                <Row>
                                    {this.showDevicePaged()}
                                </Row>
                            </div>
                            </Panel>
                        </div>
                    </Col>
                </Row>
            </Grid>
        );
    };

    doFetch () {
        let result;
        let res;
        this.setState({isLoading: true});
        result = DeviceAPI.all_device_list();
        result.then((res) => 
        {
            if (res)
            { 
                if (res.data==null)
                    this.resolveFetchData_AllDeviceList(res.data);
                else
                    this.resolveFetchData_AllDeviceList(res.data);
                
                this.setState({ isLoading: false });
            }
            else
            {
                if (res && res.message)
                    alert(res.message);
                else
                    alert('get Device List Fail.');

                this.setState({ isLoading: false });
            }
        });   
    };
    resolveFetchData_AllDeviceList (source) {
        let dataArray = [];
        if(source)
        {
            let data = source.slice(0);
            data.map((entry, index) => {
                dataArray[index] = entry;
            });

            this.deviceTableData = dataArray//.reverse()
            .slice(0);
        }else
            this.deviceTableData = dataArray;
        
        // this.initAccountTable(dataArray);
        this.initDeviceTable(dataArray);
    };

    initDeviceTable (data) {
        data.map((entry, index) => {
            this.deviceTableParams.searchedTag[index] = 1;
            this.deviceTableParams.sortedOrder[index] = index;
        });
        this.deviceTableParams.searchedCount = 1;
        this.deviceTableParams.matchAll = false;
        this.deviceTableParams.lastPage = Math.ceil(data.length / this.deviceTableParams.dataPerPage);
       
    };
    tableRefresh () {
        this.deviceTableParams.resultData = [];
        let deviceCountLength = 0;
        let deviceData  = this.deviceTableData.slice(0);

        deviceData.map((entry, index) => {
            if (this.deviceTableParams.matchAll)
            {
                if (this.deviceTableParams.searchedCount == this.deviceTableParams.searchedTag[index])
                {
                    this.deviceTableParams.resultData[deviceCountLength] = this.deviceTableParams.sortedOrder[index];
                    deviceCountLength++;
                }
            }
            else
            {
                if (0 < this.deviceTableParams.searchedTag[index])
                {
                    this.deviceTableParams.resultData[deviceCountLength] = this.deviceTableParams.sortedOrder[index];
                    deviceCountLength++;
                }
            }
        });

        /* update pagedInfo */
        this.deviceTableParams.lastPage = Math.ceil(deviceCountLength / this.deviceTableParams.dataPerPage);
    };

    showSearchBar () {
        let content = [];
        content.push(
    
            <Col md={4}  mdOffset={0} >
                <FormGroup>
                    <InputGroup>
                        <FormControl ref='searchInput' type='text' placeholder={'Search'} onChange={()=>this._searchHandler()} />
                        <InputGroup.Addon className="searchBtn" onClick={()=>{this._searchHandler()}}>
                            <FontAwesome name='search'/>
                        </InputGroup.Addon>
                    </InputGroup>
                </FormGroup>
            </Col>
        );
        return content;
    };

    _searchHandler(){
        let searchinput = ReactDOM.findDOMNode(this.refs.searchInput).value.split(' ').filter((entry) => ('' != entry));
        let data = this.deviceTableData.slice(0);
        let dataTag = this.deviceTableParams['searchedTag'].slice(0);
        if (0 == searchinput.length) { searchinput[0] = ''; }
        data.map((entry,entryIndex) => {
            let count = 0;
            searchinput.map((input) => {
                let inputLowCase = new RegExp(input, 'i');
                for (let obj in entry)
                {
                    let objContent = '';
                    objContent = entry[obj];

                    if (inputLowCase.test(objContent)) 
                    {
                        count+=1;
                        break;
                    }
                }
            });
            dataTag[entryIndex] = count;
        });
        this.deviceTableParams['searchedCount'] = searchinput.length;
        this.deviceTableParams['searchedTag'] = dataTag.slice(0);
        this.setState({ deviceActivePage: 1 });
    };
    
    showDeviceTable () {
        let content = [];
        content.push(
            <Col md={12}>
                <Table striped bordered hover>
                    {this.showDeviceTableHeader()}
                    {this.showDeviceTableBody()}
                </Table>
            </Col>
        );
        return content;
    };

    showDeviceTableHeader () {
        let content = [];
        let count = 0;
        content.push(
            <thead>
                <tr style={{'background-color':'#2a3f54',color:'white'}}>
                    {
                        Object.keys(this.deviceTableHeader).map((entry) => {
                            let content_th = [];
                            switch (entry)
                            {
                                case 'devname':
                                content_th.push(
                                    <th style={{'text-align':"left",'cursor': 'pointer'}} onClick={() => {this._sortDeviceName()}}>
                                        {(this.deviceTableHeader[entry].text)}
                                        <FontAwesome name ={this.state.sortDeviceName} size='1x' style={{'padding-left':'10px'}}/>
                                    </th>                                    
                                );
                                break;
                                case 'status':
                                content_th.push(
                                    <th style={{'text-align':"left",'cursor': 'pointer'}} onClick={() => {this._sortStatus()}}>
                                        {(this.deviceTableHeader[entry].text)}
                                        <FontAwesome name ={this.state.sortStatus} size='1x' style={{'padding-left':'10px'}}/>
                                    </th>                                    
                                );
                                break
                                case 'model':
                                content_th.push(
                                    <th style={{'text-align':"left",'cursor': 'pointer'}} onClick={() => {this._sortModel()}}>
                                        {(this.deviceTableHeader[entry].text)}
                                        <FontAwesome name ={this.state.sortModel} size='1x' style={{'padding-left':'10px'}}/>
                                    </th>                                    
                                );
                                break;
                                case 'mac':
                                content_th.push(
                                    <th style={{'text-align':"left",'cursor': 'pointer'}} onClick={() => {this._sortMAC()}}>
                                        {(this.deviceTableHeader[entry].text)}
                                        <FontAwesome name ={this.state.sortMAC} size='1x' style={{'padding-left':'10px'}}/>
                                    </th>                                    
                                );
                                break;
                                
                                case 'devid':
                                    content_th.push(
                                        <th style={{'text-align':"left"}}>{(this.deviceTableHeader[entry].text)}
                                        </th>
                                    );
                                break;
                                case 'owner':
                                content_th.push(
                                    <th style={{'text-align':"left",'cursor': 'pointer'}} onClick={() => {this._sortOwner()}}>
                                        {(this.deviceTableHeader[entry].text)}
                                        <FontAwesome name ={this.state.sortOwner} size='1x' style={{'padding-left':'10px'}}/>
                                    </th>                                    
                                );
                                break;
                            };
                            count++;
                            return content_th;
                        })
                    }
                </tr>
            </thead>
        );
        this.deviceTableParams.headerLength = count;
        return content;
    };

    showDeviceTableBody () {
        let data = this.deviceTableData.slice(0);
        let contentIndex = this.deviceTableParams.resultData.slice(0);
        let contentStart = (this.state.deviceActivePage-1) * this.deviceTableParams.dataPerPage;
        let contentEnd = Math.min((this.state.deviceActivePage * this.deviceTableParams.dataPerPage) , this.deviceTableParams.resultData.length);
        let content = [];
        let index = 0, count = 0, tableInfo = [];
        for (let i=contentStart; i<contentEnd; i++)
        {
            index = contentIndex[i];
            tableInfo[count] = data[index];
            count++;
        }
        content.push(
            <tbody>
                {
                    tableInfo.map((entry) => {
                        let content_tr = [];
                        content_tr.push(
                            <tr onClick={() => {this._redirectHandler('/home/device/deviceInfo'); this._setThisDeviceID(entry.devid);}}  style = {{'cursor': 'pointer'}} >
                    
                                {
                                    Object.keys(this.deviceTableHeader).map((info) => {
                                        let content_td = [];
                                        switch (info)
                                        {
                                            default:
                                                content_td.push(
                                                    <td style={{'text-align':"left"}}>{entry[info]}</td>
                                                );
                                                break;
                                                };
                                        return content_td;
                                    })
                                }
                                
                            </tr>
                        );
                        return content_tr;
                    })
                }
                {
                    (0 == tableInfo.length)? (<tr><td colSpan={this.deviceTableParams['headerLength']} className='text-center'>{''}</td></tr>) : []
                }
            </tbody>
        );
        return content;
    };

    showDevicePaged () {
        const pagedOptions = new Array(
            {value: 10},
            {value: 25},
            {value: 50},
            {value: 100},
        );

        
        let content = [];
        let showStart = 0;
        if (0 < this.deviceTableParams.resultData.length)
        {
			showStart = (this.state.deviceActivePage-1) * this.deviceTableParams.dataPerPage + 1;
        }
        let showEnd = Math.min((this.state.deviceActivePage * this.deviceTableParams.dataPerPage) , this.deviceTableParams.resultData.length);
        content.push(
            <Col md={12} className='tables-paging'>
                <div className='pageinfo'>
                    <span>{MulitLangFile.showText("Showing %0-%1 of %2 records.", showStart, showEnd, this.deviceTableParams['resultData'].length)}</span>
                    <span>Items per page: </span>
                    <DropdownButton title={this.deviceTableParams.dataPerPage} onSelect={(eventKey) => this._perDevicePageHandler(eventKey)} dropup>
                        {
                            pagedOptions.map((entry) => (
                                <MenuItem eventKey={entry.value}>{entry.value}</MenuItem>
                            ))
                        }
                    </DropdownButton>
                    <span>Page(s): </span>
                    <Pagination
                        // prev
                        // next
                        first
                        last
                        ellipsis={false}
                        items={this.deviceTableParams.lastPage}
                        maxButtons={9}
                        activePage={this.state.deviceActivePage}
                        onSelect={(eventKey) => {this._devicePagedHandler(eventKey);}}
                    />
                </div>
            </Col>
        );
        return content;
    };
    
    _devicePagedHandler (eventKey) {
        this.deviceTableParams['lastPage'] = eventKey;
        this.setState({ deviceActivePage: eventKey });
    };
    
    _perDevicePageHandler (eventKey) {
        this.deviceTableParams['lastPage'] = 1;
        this.deviceTableParams['dataPerPage'] = eventKey;
        this.setState({ deviceActivePage: 1 });
    };

    _setDeviceIDorMAC (entry) {
        if (1 == ReactDOM.findDOMNode(this.refs[`dataSourceType`]).value)
            this.state.placeholder = 'Device ID';
        else
            this.state.placeholder = 'MAC';
        this.setState(this.state);
    }

    _redirectHandler (path) {
        let homeThis = StorageData.get('homeThis');
        if (homeThis)
        {
            homeThis.env.nextPath = path;
        }
        hashHistory.push(path);
    };

    _setThisDeviceID (data) {
        StorageData.set('DeviceID',data);
    };

    _sortDeviceName() {
        if (this.state.sortDeviceName=='sort')
        {
            this.deviceTableData =  this.deviceTableData.sort(function (a, b) {
            return a.devname > b.devname ? 1 : -1;
            });
            this.setState({
                sortDeviceName:'sort-down',
                sortStatus:'sort',
                sortModel:'sort',
                sortMAC:'sort',
                sortDeviceID:'sort',
                sortOwner:'sort',
                deviceActivePage: 1
            });            
        }

        if (this.state.sortDeviceName=='sort-down')
        {
            this.deviceTableData =  this.deviceTableData.reverse(function (a, b) {
                return a.devname > b.devname ? 1 : -1;
                });
            this.setState({
                sortDeviceName:'sort-up',
                sortStatus:'sort',
                sortModel:'sort',
                sortMAC:'sort',
                sortDeviceID:'sort',
                sortOwner:'sort'
            });            
        }

        if (this.state.sortDeviceName=='sort-up')
        {
            this.deviceTableData =  this.deviceTableData.sort(function (a, b) {
                return a.devname > b.devname ? 1 : -1;});

            this.setState({
                sortDeviceName:'sort-down',
                sortStatus:'sort',
                sortModel:'sort',
                sortMAC:'sort',
                sortDeviceID:'sort',
                sortOwner:'sort'
            });            
        }        
    };

    _sortStatus() {
        if (this.state.sortStatus=='sort')
        {
            this.deviceTableData =  this.deviceTableData.sort(function (a, b) {
                return a.status > b.status ? 1 : -1;
                });
            this.setState({
                sortDeviceName:'sort',
                sortStatus:'sort-down',
                sortModel:'sort',
                sortMAC:'sort',
                sortDeviceID:'sort',
                sortOwner:'sort'
            });            
        }

        if (this.state.sortStatus=='sort-down')
        {
            this.deviceTableData =  this.deviceTableData.reverse(function (a, b) {
                return a.status > b.status ? 1 : -1;
                });
            this.setState({
                sortDeviceName:'sort',
                sortStatus:'sort-up',
                sortModel:'sort',
                sortMAC:'sort',
                sortDeviceID:'sort',
                sortOwner:'sort'
            });            
        }

        if (this.state.sortStatus=='sort-up')
        {
            this.deviceTableData =  this.deviceTableData.sort(function (a, b) {
                return a.status > b.status ? 1 : -1;
                });
            this.setState({
                sortDeviceName:'sort',
                sortStatus:'sort-down',
                sortModel:'sort',
                sortMAC:'sort',
                sortDeviceID:'sort',
                sortOwner:'sort'
            });            
        }        
    };

    _sortModel() {
        if (this.state.sortModel=='sort')
        {
            this.deviceTableData =  this.deviceTableData.sort(function (a, b) {
                return a.model > b.model ? 1 : -1;
                });
            this.setState({
                sortDeviceName:'sort',
                sortStatus:'sort',
                sortModel:'sort-down',
                sortMAC:'sort',
                sortDeviceID:'sort',
                sortOwner:'sort'
            });            
        }

        if (this.state.sortModel=='sort-down')
        {
            this.deviceTableData =  this.deviceTableData.reverse(function (a, b) {
                return a.model > b.model ? 1 : -1;
                });
            this.setState({
                sortDeviceName:'sort',
                sortStatus:'sort',
                sortModel:'sort-up',
                sortMAC:'sort',
                sortDeviceID:'sort',
                sortOwner:'sort'
            });            
        }
        if (this.state.sortModel=='sort-up')
        {
            this.deviceTableData =  this.deviceTableData.sort(function (a, b) {
                return a.model > b.model ? 1 : -1;
                });
            this.setState({
                sortDeviceName:'sort',
                sortStatus:'sort',
                sortModel:'sort-down',
                sortMAC:'sort',
                sortDeviceID:'sort',
                sortOwner:'sort'
            });            
        }        
    };

    _sortMAC(){
        if (this.state.sortMAC=='sort')
        {
            this.deviceTableData =  this.deviceTableData.sort(function (a, b) {
                return a.mac > b.mac ? 1 : -1;
                });
            this.setState({
                sortDeviceName:'sort',
                sortStatus:'sort',
                sortModel:'sort',
                sortMAC:'sort-down',
                sortDeviceID:'sort',
                sortOwner:'sort'
            });            
        }

        if (this.state.sortMAC=='sort-down')
        {
            this.deviceTableData =  this.deviceTableData.reverse(function (a, b) {
                return a.mac > b.mac ? 1 : -1;
                });
            this.setState({
                sortDeviceName:'sort',
                sortStatus:'sort',
                sortModel:'sort',
                sortMAC:'sort-up',
                sortDeviceID:'sort',
                sortOwner:'sort'
            });            
        }

        if (this.state.sortMAC=='sort-up')
        {
            this.deviceTableData =  this.deviceTableData.sort(function (a, b) {
                return a.mac > b.mac ? 1 : -1;
                });
            this.setState({
                sortDeviceName:'sort',
                sortStatus:'sort',
                sortModel:'sort',
                sortMAC:'sort-down',
                sortDeviceID:'sort',
                sortOwner:'sort'
            });            
        }
    };

    _sortOwner(){
        if (this.state.sortOwner=='sort')
        {
            this.deviceTableData =  this.deviceTableData.sort(function (a, b) {
                return a.owner > b.owner ? 1 : -1;
                });
            this.setState({
                sortDeviceName:'sort',
                sortStatus:'sort',
                sortModel:'sort',
                sortMAC:'sort',
                sortDeviceID:'sort',
                sortOwner:'sort-down'
            });            
        }

        if (this.state.sortOwner=='sort-down')
        {
            this.deviceTableData =  this.deviceTableData.reverse(function (a, b) {
                return a.owner > b.owner ? 1 : -1;
                });
            this.setState({
                sortDeviceName:'sort',
                sortStatus:'sort',
                sortModel:'sort',
                sortMAC:'sort',
                sortDeviceID:'sort',
                sortOwner:'sort-up'
            });            
        }

        if (this.state.sortOwner=='sort-up')
        {
            this.deviceTableData =  this.deviceTableData.sort(function (a, b) {
                return a.owner > b.owner ? 1 : -1;
                });
            this.setState({
                sortDeviceName:'sort',
                sortStatus:'sort',
                sortModel:'sort',
                sortMAC:'sort',
                sortDeviceID:'sort',
                sortOwner:'sort-down'
            });            
        }
    };

    _setAllDeviceList()
    {
        if (this.allDeviceList == 0)
        {
            this.allDeviceList =1;

            let result;
            let res;
            this.setState({isLoading: true});

            result = DeviceAPI.all_device_list();
            result.then((res) => {
               if(res)
               {   
                    if(res.data==null)
                   {
                        confirm('no data.');
                        this.resolveFetchData_AllDeviceList(res.data);
                   }else
                   {
                       this.resolveFetchData_AllDeviceList(res.data);
                   }
                   this.setState({ isLoading: false });
               }
               else
               {
                    if (res && res.message)
                        alert(res.message);
                    else
                        alert('get Account List Fail.');
                        
                    this.setState({ isLoading: false });
               }
           });
        }
        else
        {
            this.allDeviceList =0;
            this.setState({isLoading: true});
            this.resolveFetchData_AllDeviceList();
            this.setState({ isLoading: false });
        }
    }
};

export default Device;