import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {
  Panel, Grid, Row, Col, FormControl, Table, DropdownButton, MenuItem, Pagination, Button, Form ,InputGroup,FormGroup,Image
} from 'react-bootstrap';

import FontAwesome from 'react-fontawesome';
import { Link, hashHistory } from 'react-router';
/* component */
import PageTitile from '../../component/pageTitle.js';
import ServerAPI from '../../backendAPI/server.js';
import GetAccounts from '../../backendAPI/getAccount.js';
import { homepageChangeAccountFn } from './home.js';
/* common */
// import Lang from '../../common/languages.js';
import StorageData from '../../common/storageData.js';
import MulitLangFile from '../../common/multiLang.js';
const styleRect={ "fill":"rgb(255,255,255,1)","stroke-width":1,"stroke":"rgb(0,0,0)"};
const styleText={"font-family": "Arial",fill:"#666666",stroke: "#999999","stroke-width":0.5,"font-size": "18px"}
const styleRectFocus={ "fill":"rgb(124,252,0,1)","stroke-width":1,"stroke":"rgb(0,0,0)"};
const styleTextFocus={"font-family": "Arial",fill:"rgb(255,255,255,1)","font-size": "18px"}

class Hierachy extends Component {
    constructor (props) {
        super (props);
        this.logindata=JSON.parse(ServerAPI.getLoginInfo());
        this.state = {
            currentLanguage:props.language,
            isLoading: false,
			placeholder: 'Device ID',
            rectWidth:180,
            rectHeight:50,
            currentUUID:this.logindata.currentuuid,
    
        };
        this.dataSource = '';
        this.marginWidth=90;
        this.marginHeight=20;
        this.Pre2ndHeight=0;
        this.topoData=[];
        
        /*if(this.logindata.role.indexOf('root') == -1)
        {
            this.topoData={
                "uuid": "b2b169bf-70ab-47ed-b0c9-ec368ea9bb0d",
                "logofilepath": "",
                "role": "admin",
                "name": this.logindata.alias,
                "treeNode":[{
                    name:"test1234",
                    "uuid": "956bf6c8-4463-451f-bd78-82a3a3278a75",
                    "logofilepath": "",
                    "role": "admin",
                },{
                    name:"adminqa1",
                    "uuid": "parent uuid",
                    "logofilepath": "",
                    "role": "admin",
                },{
                    name:"HerryTest"
                },{
                    name:"herrywang"
                }
                ]
            };
        }else*/
        {
            this.topoData={
                "name": this.logindata.alias,
                "uuid": "b2b169bf-70ab-47ed-b0c9-ec368ea9bb0d",
                "treeNode":[{
                    name:"test1234",
                    "uuid": "07b9e14d-d8c7-4898-ab46-4e31cd66f97f",
                    "logofilepath": "",
                    "role": "admin",
                    "treeNode":[{
                        "name":"sub gc1"
                        },{
                            "name":"sub gc2"
                            }
                    ]
                },{
                    name:"adminqa1",
                    "uuid": "956bf6c8-4463-451f-bd78-82a3a3278a75",
                    "logofilepath": "",
                    "role": "admin",
                    "treeNode":[{
                        "name":"sub weu"
                        }
                    ]
                },{
                    name:"HerryTest",
                    "uuid": "eca5249d-b3b8-40cb-980e-19cd3ab911be",
                    "logofilepath": "",
                    "role": "admin",
                },{
                    name:"herrywang",
                    "uuid": "433ef73f-63d1-4da6-ad11-e9882a32deb9",
                    "logofilepath": "",
                    "role": "admin",
                    "treeNode":[{
                        "name":"sub cee1"
                        },{
                        "name":"sub cee2"
                        },{
                        "name":"sub cee3"
                        }
                    ]
                }
                ]
            };
        }
        
 
        this.env = {
            project: ''
        };
        
        this.handleClick = this.handleClick.bind(this);
    };

    componentDidMount () {
        this.env.project = this.props.params.project;
        if(!this.state.currentUUID)
        {
            //this.setState({accountuuid:this.props.accountuuid});
            // this.doFetch(this.state.currentUUID);
        }
        // this.dataUpdate();
    };
    componentWillReceiveProps (nextProps) {
        //if (nextProps.accountuuid != this.state.accountuuid)
        {
            
            this.env.project = nextProps.params.project;
           // this.setState({accountuuid:nextProps.accountuuid});
            this.doFetch(this.state.currentUUID);
        }
    };

    

    render () {
        return (
            <Grid fluid>
                <Row>
                    {/* <Col md={12}>
                          <PageTitile text={`${this.logindata.root?`Edimax`:`Edimax/${this.logindata.alias}`}`} />
                    </Col> */}
                </Row>
                <Row>
                    <Col md={12}>
                        <div className='general-panel'>
                             <div style={{'background-color':'#f5f5f5',padding:'10px','border-top':'1px solid #ddd','border-right':'1px solid #ddd','border-left':'1px solid #ddd'}}>
                                <strong style={{'font-weight':'700','height':'16px', 'font-size': '15px',color:'inherit'}}>{`${MulitLangFile.MulitLang.accountHierachy[this.state.currentLanguage ]}`}
                                </strong>
                            </div>
                            <Panel>
                                <div className='general-panel-content'>
                                   {
                                    this.state.isLoading? <span className='accessingTag'><FontAwesome name='spinner' size='lg' pulse />Loading</span>
                                        :
                                       this.renderSVG()
                                       }
                                </div>
                            </Panel>
                        </div>
                    </Col>
                </Row>
            </Grid>
        );
    };

    renderSVG(){
        let result=[];
        let count1st=0;
        let count2nd=0;
        let Pre1stHeight=0;
        this.Pre2ndHeight=0
        if(this.topoData.treeNode){
            count1st=this.topoData.treeNode.length;
            let i=0;
            for (i=0; i<count1st ;i++) {
                let data=this.topoData.treeNode[i];
                if(data.treeNode){
                   // if(ServerAPI.isLog)console.log("data.treeNode length="+data.treeNode.length+",json="+JSON.stringify(data.treeNode));
                    count2nd=count2nd+data.treeNode.length;
                }else{
                    count2nd=count2nd+1;
                }
                   
            }
            console.log("count1st="+count1st+",count2nd="+count2nd+",data="+JSON.stringify(this.topoData));
        }
        let maxCount=count1st>count2nd?count1st:count2nd;
        let posY=this.marginHeight+(this.state.rectHeight*1.5*(maxCount-1)*0.5);//1.5 is factor rect high+margin
        result.push(
            <svg width="100%" height="100%" id="svg" >
            <rect width={this.state.rectWidth} height={this.state.rectHeight} x={this.marginWidth} y={posY} style={this.logindata.uuid==this.state.currentUUID?styleRectFocus:styleRect}  
            onClick={
                ()=>{
                    if(ServerAPI.isLog)console.log("click hierachy parent")
                    homepageChangeAccountFn(null,"self");
                    this.setState({currentUUID:this.logindata.uuid});
                    }
                }
            ></rect>
            <text  
            onClick={
                ()=>{
                    if(ServerAPI.isLog)console.log("click hierachy parent")
                    homepageChangeAccountFn(null,"self");
                     this.setState({currentUUID:this.logindata.uuid});
                    }
                }
            fill="black"   x={this.state.rectWidth*0.5+this.marginWidth} y={this.state.rectHeight*0.5+posY+5} textAnchor="middle" //style={{outline: "1px solid black"}} 
            style={this.logindata.uuid==this.state.currentUUID?styleTextFocus:styleText}>
                {this.topoData.name?this.topoData.name:""}</text>
                {count1st>0?this.render1stSVG(this.topoData.treeNode,(this.marginWidth+this.state.rectWidth),posY+(this.state.rectHeight*0.5),Pre1stHeight):[]}
        </svg>
        );
        return result;
    }

    render1stSVG(nodeData,startX,startY,Pre1stHeight){
        let result=[];
        let pos=0;
        
        //let Pre1stHeight=0;
        let xx=0;
        let yy=0;
            for(pos=0;pos<nodeData.length;pos++){
                let child=nodeData[pos];
                let childCount=0;
                if(child.treeNode){
                     childCount=child.treeNode.length;
                } else{
                      childCount=0;
                }   
                 xx=this.marginWidth+(this.state.rectWidth*1.5);
                 if(Pre1stHeight==0)
                    Pre1stHeight=this.marginHeight
                 //yy=this.marginHeight+(((childCount==0?1:childCount)-1)*this.state.rectHeight);
                    yy=Pre1stHeight+(((childCount==0?1:childCount)-1)*this.state.rectHeight*0.5);
               // if(ServerAPI.isLog)console.log("render1stSVG xx="+xx+",yy="+yy+",length ="+nodeData.length);
                result.push(
                    <rect 
                    onClick={()=>
                            {
                            //console.log("click hierachy child="+JSON.stringify(child))
                            homepageChangeAccountFn(child,"account");
                            this.setState({currentUUID:child.uuid});
                            }
                        }
                    width={this.state.rectWidth} height={this.state.rectHeight} x={xx} y={yy} style={child.uuid==this.state.currentUUID?styleRectFocus:styleRect}></rect>
                );   
            
                result.push(
                    <text  
                     onClick={()=>{
                            homepageChangeAccountFn(child,"account");
                            this.setState({currentUUID:child.uuid});
                            }
                        }
                    fill="black"   x={this.state.rectWidth*0.5+xx} y={(this.state.rectHeight*0.5)+yy+5} textAnchor="middle" //style={{outline: "1px solid black"}} 
                    style={child.uuid==this.state.currentUUID?styleTextFocus:styleText}>
                        {child.name?child.name:""}</text>
                );
                
                result.push(
                    <line x1={startX} x2={startX+(this.state.rectWidth*0.5)} y1={startY} y2={(this.state.rectHeight*0.5)+yy} style={{"stroke":"rgb(0,0,0)","stroke-width":"1"}}/>
                );
                if(child.treeNode){
                   
                    this.render2ndSVG(result,child.treeNode,(this.state.rectWidth+xx),((this.state.rectHeight*0.5)+yy));
                }else{
                    this.Pre2ndHeight=this.Pre2ndHeight+(this.state.rectHeight*1.5);
                }
                if(childCount==0)
                    Pre1stHeight=Pre1stHeight+(this.state.rectHeight*1.5);
                else{
                     Pre1stHeight=Pre1stHeight+(childCount*this.state.rectHeight*1.5);
                }
                   
               
            }
            
    
        return result;   
    }

    render2ndSVG(result,nodeData,startX,startY){
        //let result=[];
        let pos=0;
        
        if(ServerAPI.isLog)console.log("render2ndSVG nodeData.length="+nodeData.length);
        let xx=0;
        let yy=0;
        let childCount=0;
            for(pos=0;pos<nodeData.length;pos++){
                let child=nodeData[pos];
               
                if(child.treeNode){
                     childCount=child.treeNode.length;
                } else{
                      childCount=0;
                }   
                 xx=this.marginWidth+(this.state.rectWidth*3);
                 if(this.Pre2ndHeight==0){
                    this.Pre2ndHeight=this.marginHeight; 
                 } 
                   yy=this.Pre2ndHeight+((pos)*this.state.rectHeight*1.5); 
                  
               // if(ServerAPI.isLog)console.log("Pre2ndHeight="+this.Pre2ndHeight+",xx="+xx+",yy="+yy+",length ="+nodeData.length);
                result.push(
                    <rect width={this.state.rectWidth} height={this.state.rectHeight} x={xx} y={yy} style={styleRect}></rect>
                );   
            
                result.push(
                    <text  fill="black"   x={this.state.rectWidth*0.5+xx} y={(this.state.rectHeight*0.5)+yy+5} textAnchor="middle" //style={{outline: "1px solid black"}} 
                    style={styleText}>
                        {child.name?child.name:""}</text>
                );
                
                result.push(
                    <line x1={startX} x2={startX+(this.state.rectWidth*0.5)} y1={startY} y2={(this.state.rectHeight*0.5)+yy} style={{"stroke":"rgb(0,0,0)","stroke-width":"1"}}/>
                );
                 
            /*if(nodeData.length==0)
                this.Pre2ndHeight=this.Pre2ndHeight+(this.state.rectHeight*1);
            else*/
                
            }
            this.Pre2ndHeight=this.Pre2ndHeight+((nodeData.length)*this.state.rectHeight*1.5);
        //return result;   
    }

    // function countProperties (obj) {
    //     var count = 0;
    
    //     for (var property in obj) {
    //         if (Object.prototype.hasOwnProperty.call(obj, property)) {
    //             count++;
    //         }
    //     }
    
    //     return count;
    // }
 
    doFetch (accountuuid) {
        let result;
        let res;
        this.setState({isLoading: true});
        console.log("doFetch hierachy");
            if(accountuuid&&accountuuid!='')
            {
                result = GetAccounts.getAccountList(accountuuid);
                result.then((res) => {
                   if(res)
                   { 
                        if(ServerAPI.isLog)console.log("hierachy fetch res data="+JSON.stringify(res));
                        if(res.data==null)
                       {
                       }else
                       {
                            //confirm('Get Success ');
                            this.topoData=res;
                        //    this.resolveFetchData(res.data);
                       }
                       this.setState({ isLoading: false });
                   }
                   else
                   {
                       //alert('Current password invalid!');
                       if(res&&res.message)alert(res.message);
                       else
                       alert('get Account List Fail.');
                       this.setState({ isLoading: false });
                   }
               });
            }
        
    };
 
   



    handleClick(entry)
    {
        
        if(entry.role!='Operator')hashHistory.push({pathname:'/home/account/info',state:{alias:entry.alias,mail:entry.userid,role:'Admin'}});
    }

   
}
        
export default Hierachy;