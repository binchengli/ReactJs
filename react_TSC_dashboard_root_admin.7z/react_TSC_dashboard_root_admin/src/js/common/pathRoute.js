


    

    
   


    const pathRoute={
        login:'/login',
        login404:'/login/*',
        home:'/home',
        home404:'/home/*',
        account:'/home/account',
        hierachy:'/home/hierachy',
        accountCreate:'/home/create',
        accountInfo:'/home/account/info',
        device:'/home/device',
        deviceStatus:'/home/device/status',
        deviceDeviceinfo:'/home/device/deviceinfo',
        deviceTransfer:'/home/device/devicetransfer',
        statistic:'/home/statistic',
        statisticRegistrationdevices:'/home/statistic/registrationdevices',
        statisticStorageplan:'/home/statistic/storageplan',
        statisticActivateddevices:'/home/statistic/activateddevices',
        statisticDeactivateddevices:'/home/statistic/deactivateddevices',
        billing:'/home/billing',
        receivable:'/home/receivable',
        receivableDetail:'/home/receivable/detail',
        notification:'/home/notification',
        administrationPayable:'/home/administration/payable',
        administrationPayableDetail:'/home/administration/payable/detail',
        administrationStorage:'/home/administration/storage',
        administrationStorageSetup:'/home/administration/storage/setup',
        administrationStorageRoot:'/home/administration/storage/root',
        administrationSetting:'/home/setting',
        administrationChange:'/home/change',
        welcome:'/home/welcome',
    };



export default pathRoute;