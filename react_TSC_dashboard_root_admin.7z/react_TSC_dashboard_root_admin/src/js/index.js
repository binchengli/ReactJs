import React, { Component } from 'react';
import { render } from 'react-dom';
import { hashHistory, Router, Route, IndexRedirect } from 'react-router';

window.Promise = Promise;
import pathRoute from './common/pathRoute.js';
/* route */
import Login from './route/login/login.js';
import Home from './route/home/home.js';
import Blank from './route/other/blank.js';
import Account from './route/home/account.js';
import Hierachy from './route/home/hierachy.js';
import DeviceManage from './route/home/deviceManage.js';
import DeviceStatus from './route/home/deviceStatus.js';
import DeviceTransfer from './route/home/deviceTransfer.js';
import DeviceInfo from './route/home/deviceInfo.js';
import Receivable from './route/home/receivable.js';
import Statistic from './route/home/STAT.js';
import Create from './route/home/create.js';
import AdministrationPayable from './route/home/administrationpayable.js';
import AdministrationStorage from './route/home/administrationStorage.js';
import AdministrationStorageSetup from './route/home/administrationStorageSetup.js';
import AdministrationStorageRoot from './route/home/administrationStorageRoot.js';
import Setting from './route/home/setting.js';
import ChangePassword from './route/home/change.js';
import Welcome from './route/home/welecom.js';
import Billing from './route/home/Billing.js';
import Page_404 from './route/other/404.js';
import AccountInfo from './route/home/accountinfo.js';
import RegistrationDevice from './route/home/STAT_RegistrationDevices.js';
import StoragePlan from './route/home/STAT_StoragePlan.js';
import ActivateDevice from './route/home/STAT_ActivatedDevices.js';
import DeactivateDevice from './route/home/STAT_DeactivatedDevices.js';
import Notification from './route/home/Notification.js';

document.title = process.env['NAME'];

class Index extends Component {
    render () {
        return (
            <div>{this.props.children}</div>
        );
    };
};

class RouteMap extends Component {
    constructor (props) {
        super(props);
        // Lang.initLanguage();
    };
    render () {
        return (
            <Router history={hashHistory}>
                <Route path='/' component={Index}>
                    <IndexRedirect to={pathRoute.login}/>
                    <Route path={pathRoute.login} component={Login} />
                    <Route path={pathRoute.login404} component={Page_404} />
                    
                    <Route path={pathRoute.home} component={Home}>
                        <Route path={pathRoute.account} component={Account} />
                         <Route path={pathRoute.hierachy} component={Hierachy} />
                        <Route path={pathRoute.device} component={DeviceManage} />
                        <Route path={pathRoute.deviceStatus} component={DeviceStatus} />
                        <Route path={pathRoute.deviceDeviceinfo} component={DeviceInfo} />
                        <Route path={pathRoute.deviceTransfer} component={DeviceTransfer} />
                        <Route path={pathRoute.statistic} component={Statistic} />
                        <Route path={pathRoute.statisticRegistrationdevices} component={RegistrationDevice} />
                        <Route path={pathRoute.statisticStorageplan} component={StoragePlan} />
                        <Route path={pathRoute.statisticActivateddevices} component={ActivateDevice} />
                        <Route path={pathRoute.statisticDeactivateddevices} component={DeactivateDevice} />
                        <Route path={pathRoute.billing} component={Billing} />
                        <Route path={pathRoute.receivable} component={Receivable} />
                        <Route path={pathRoute.receivableDetail}  component={() => (<Receivable detail/>)}/>
                        <Route path={pathRoute.notification} component={Notification} />
                        <Route path={pathRoute.accountCreate} component={Create}  />
                        <Route path={pathRoute.administrationPayable} component={AdministrationPayable} />
                        <Route path={pathRoute.administrationPayableDetail}  component={() => (<AdministrationPayable detail/>)}/>
                        <Route path={pathRoute.administrationStorage} component={AdministrationStorage} />
                        <Route path={pathRoute.administrationStorageSetup} component={AdministrationStorageSetup} />
                         <Route path={pathRoute.administrationStorageRoot} component={AdministrationStorageRoot} />
                        <Route path={pathRoute.administrationSetting} component={Setting} />
                        <Route path={pathRoute.administrationChange}  component={ChangePassword} />
                        <Route path={pathRoute.welcome} component={Welcome} />
                        <Route path={pathRoute.accountInfo} component={AccountInfo} />
                        <Route path={pathRoute.home404} component={Page_404}/>
                    </Route>
                   
                    <Route path='/404' component={Page_404} />
                    <Route path='/*' component={Page_404} />     
                </Route>
            </Router>
        );
    };
};

render((<RouteMap />), document.getElementById('main'));
