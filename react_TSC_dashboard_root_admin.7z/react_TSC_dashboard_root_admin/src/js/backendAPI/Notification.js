import { hashHistory } from 'react-router';
import 'whatwg-fetch';

import ServerAPI from './server.js';

/* common */
import StorageData from '../common/storageData.js';
import FunctionJS from '../common/functionJS.js';

const Notification = (() => {
    const message = (obj) => {
        let URL = ServerAPI.URLlist['Notification'];
        return fetch(URL, {
            method: 'GET',
            headers: {
                'Authorization': ServerAPI.getJWT()
            }
        })
        .then((response) => {
            return ServerAPI.httpCheck(response);
        });
    };
    const newmessage = (obj) => {
        let URL = ServerAPI.URLlist['NewNotification'];
        return fetch(URL, {
            method: 'GET',
            headers: {
                'Authorization': ServerAPI.getJWT()
            }
        })
        .then((response) => {
            return ServerAPI.httpCheck(response);
        });
    };

    return {
        message: message,
        newmessage: newmessage
    };
})();

export default Notification;