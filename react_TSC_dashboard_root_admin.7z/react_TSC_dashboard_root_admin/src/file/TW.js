{"LANG": [
"Template Project version",
"Logout",
"Template",
"Project",
"Admin",
"User",
"Demo1",
"Demo2",
""
]}