import { color } from 'd3-color';
import { interpolateRgb } from 'd3-interpolate';
import React, { Component, PropTypes } from 'react';
import ReactDOM from 'react-dom';

class InfoCard extends Component {
    static propTypes = {
        Status: PropTypes.string.isRequired,
        SColor: PropTypes.string.isRequired,
        Note: PropTypes.string.isRequired
    };
    
    constructor(props) {
        super(props);
        this.state = {};
        this.note = '';
        this.status = '';
        this.scolor = '';
    };
    componentWillReceiveProps (nextProps) {
        this.dataUpdate(nextProps);
    };
    dataUpdate (source) {
        this.status = source['Status'];
        this.scolor = source['SColor'];
        this.note = source['Note'];
    };
    render() {
        const cardBody = {
            'margin-top': '10',
            'background-color': 'white',
            'border-style': 'solid',
            'border-width': 'thin',
            'border-color': 'lightgray'
        };
        const cardTitle = {
            'padding-left': '10',
            'color': this.scolor,
            'font-size': '32px',
            'font-weight': '600'
        };
        const cardInfo = {
            'padding-left': '10',
            'color': '#A9A9A9',
            'font-size': '16px'
        };

        return (
            <div style = {cardBody}>
                <p style = {cardTitle}>{this.status}</p>
                <p style = {cardInfo}>{this.note}</p>
            </div>
        );
    }
}
 
export default InfoCard;
