import React, { Component, PropTypes } from 'react';
import {
    Panel, Row, Col, Table
} from 'react-bootstrap';
import FontAwesome from 'react-fontawesome';
import classNames from 'classnames';
import {Doughnut} from 'react-chartjs-2';

/* component */
import Lang from '../common/languages.js';

const colorMap = ['#26B99A', '#3498DB', '#E74C3C', '#BDC3C7', '#9B59B6', '#FFCE56', '#FF6384', '#36A2EB'];

class StatDoughnut extends Component {
    static propTypes = {
        statData: PropTypes.array.isRequired,
        title: PropTypes.string.isRequired,
        isLoading: PropTypes.bool
    };
    constructor (props) {
        super (props);
        this.data = [];
        this.totalNumber = 0;
    };
    componentWillReceiveProps (nextProps) {
        if (nextProps.isLoading !== this.props.isLoading)
        {
            this.dataUpdate(nextProps);
        }
    };
    render () {
        return (
            <Panel
                className='statDoughnut-panel' 
                header={<h3>{this.props.title}</h3>}
            >
                <Table style={{'width':'100%', 'overflow':'auto'}}>
                    {this.showTableHeader()}
                    {this.showTableBody()}
                </Table>
            </Panel>
        );
    };

    dataUpdate (source) {
        this.data = source['statData'].slice(0);
    };

    showTableHeader () {
        let data = this.data.slice(0);
        this.totalNumber = 0;
        for (var i=0; i < data.length; i++)
        {
            this.totalNumber += parseInt(data[i].number);
        }
        let content = [];
        content.push(
            <tr>
                <th style={{'width':'40%'}}>
                    Total: {this.totalNumber}
                </th>
                <th>
                    <Row className='statDoughnut-table-row'>
                        <Col md={4}>
                            Model
                        </Col>
                        <Col md={4} style={{'text-align':'right'}}>
                            Number
                        </Col>
                        <Col md={4} style={{'text-align':'right'}}>
                            Percentage
                        </Col>
                    </Row>
                </th>
            </tr>
        );
        return content;
    };
    showTableBody () {
        let chartData = {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [],
                hoverBackgroundColor: []
            }]
        };
        this.data.map((entry, index)=>{
            chartData.labels.push(entry['model']);
            chartData.datasets[0].data.push(entry['number']);
            chartData.datasets[0].backgroundColor.push(colorMap[index]);
            chartData.datasets[0].hoverBackgroundColor.push(colorMap[index]);
        });
        let content = [];
        if (this.props.isLoading)
        {
            content.push(<tr style={{'text-align':'center'}}><td colspan='4'><span className="statDoughnut-accessingTag"><FontAwesome name='spinner' size='lg' pulse />{Lang.showText(48)}</span></td></tr>);
        }
        else
        {
            content.push(
                <tr>
                    <td>
                        <div>
                            <Doughnut 
                                data={chartData} 
                                options={{'legend':false}} 
                                height='130' 
                                width='130'
                            />
                        </div>
                    </td>
                    {this.showBodyContent()}
                </tr>
            );
        }
        return content;
    };
    showBodyContent () {
        let content = [];
        content.push(
            <td>
            {
                this.data.map((entry, index)=>{
                    let content_tr = [];
                    let percentage = (parseInt(entry['number'])/this.totalNumber)*100;
                    content_tr.push(
                        <Row className='statDoughnut-table-row'>
                            <Col md={6}>
                                <span className='square-icon' style={{'background-color': colorMap[index]}}></span><span>{entry['model']}</span>
                            </Col>
                            <Col md={3}>
                                {entry['number']}
                            </Col>
                            <Col md={3} style={{'text-align':'right'}}>
                                {percentage.toFixed(1)}%
                            </Col>
                        </Row>
                    );
                    return content_tr;
                })
            }
            </td>
        );
        return content;
    };
};

export default StatDoughnut;