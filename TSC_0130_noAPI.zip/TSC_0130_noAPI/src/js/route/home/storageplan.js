import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {
  Panel, Grid, Row, Col, FormControl
} from 'react-bootstrap';
import FontAwesome from 'react-fontawesome';

/* component */
import PageTitile from '../../component/pageTitle.js';
import LineChart from '../../component/lineChart.js';
import DetailTable from '../../component/detailTable.js';

/* common */
import Lang from '../../common/languages.js';
import StorageData from '../../common/storageData.js';
import DataObj from '../../common/dataObj.js';

class Storageplan extends Component {
    constructor (props) {
        super (props);
        this.state = {
            isLoading: false,
            linechartExpand: true,
            detailExpand: false
        };
        this.dataSource = {
            type: 'c0',
            date: {
                interval: 7,
                startDay: 0,
                endDay: 0
            },
            typeList: [
                {text: 'All', value: 'all'},
                {text: 'C0', value: 'c0'},
                {text: 'C1', value: 'c1'},
                {text: 'C2', value: 'c2'}
            ],
            dateList: [
                {text: '1 Day', value: 1},
                {text: '7 Days', value: 7},
                {text: '14 Days', value: 14},
                {text: '30 Days', value: 30},
                {text: '60 Days', value: 60},
                {text: '90 Days', value: 90}
            ]
        };
        this.timeSlot = [];
//         this.timeSlot = [
//             {label: '2018/12/06', startTime: 0, endTime: 0},
//             {label: '2018/12/07', startTime: 0, endTime: 0},
//             {label: '2018/12/08', startTime: 0, endTime: 0},
//             {label: '2018/12/09', startTime: 0, endTime: 0},
//             {label: '2018/12/10', startTime: 0, endTime: 0},
//             {label: '2018/12/11', startTime: 0, endTime: 0},
//             {label: '2018/12/12', startTime: 0, endTime: 0}
//         ];
        this.lineData = {
            rowlabels: [],
            dataUnits: []
        };
//         this.lineData = {
//             rowlabels: ['2018/12/06', '2018/12/07', '2018/12/08', '2018/12/09', '2018/12/10', '2018/12/11', '2018/12/12'],
//             dataUnits: [
//                 {name: 'C0', data:[Math.floor(Math.random() * 200) + 1, Math.floor(Math.random() * 200) + 1, Math.floor(Math.random() * 200) + 1, Math.floor(Math.random() * 200) + 1, Math.floor(Math.random() * 200) + 1, Math.floor(Math.random() * 200) + 1, Math.floor(Math.random() * 200) + 1]},
//                 {name: 'C1', data:[Math.floor(Math.random() * 200) + 1, Math.floor(Math.random() * 200) + 1, Math.floor(Math.random() * 200) + 1, Math.floor(Math.random() * 200) + 1, Math.floor(Math.random() * 200) + 1, Math.floor(Math.random() * 200) + 1, Math.floor(Math.random() * 200) + 1]},
//                 {name: 'C2', data:[Math.floor(Math.random() * 200) + 1, Math.floor(Math.random() * 200) + 1, Math.floor(Math.random() * 200) + 1, Math.floor(Math.random() * 200) + 1, Math.floor(Math.random() * 200) + 1, Math.floor(Math.random() * 200) + 1, Math.floor(Math.random() * 200) + 1]}
//             ]
//         };
        this.columnLabels = {
            name: {text: 26},
            number: {text: 27}
        };
        this.tableData = [];
//         this.tableData = [
//             {
//                 title: '2018/12/06',
//                 dataUnits: [
//                     {name: 'C0', number: Math.floor(Math.random() * 200) + 1},
//                     {name: 'C1', number: Math.floor(Math.random() * 200) + 1},
//                     {name: 'C2', number: Math.floor(Math.random() * 200) + 1}
//                 ]
//             },
//             {
//                 title: '2018/12/07',
//                 dataUnits: [
//                     {name: 'C0', number: Math.floor(Math.random() * 200) + 1},
//                     {name: 'C1', number: Math.floor(Math.random() * 200) + 1},
//                     {name: 'C2', number: Math.floor(Math.random() * 200) + 1}
//                 ]
//             },
//             {
//                 title: '2018/12/08',
//                 dataUnits: [
//                     {name: 'C0', number: Math.floor(Math.random() * 200) + 1},
//                     {name: 'C1', number: Math.floor(Math.random() * 200) + 1},
//                     {name: 'C2', number: Math.floor(Math.random() * 200) + 1}
//                 ]
//             },
//             {
//                 title: '2018/12/09',
//                 dataUnits: [
//                     {name: 'C0', number: Math.floor(Math.random() * 200) + 1},
//                     {name: 'C1', number: Math.floor(Math.random() * 200) + 1},
//                     {name: 'C2', number: Math.floor(Math.random() * 200) + 1}
//                 ]
//             },
//             {
//                 title: '2018/12/10',
//                 dataUnits: [
//                     {name: 'C0', number: Math.floor(Math.random() * 200) + 1},
//                     {name: 'C1', number: Math.floor(Math.random() * 200) + 1},
//                     {name: 'C2', number: Math.floor(Math.random() * 200) + 1}
//                 ]
//             },
//             {
//                 title: '2018/12/11',
//                 dataUnits: [
//                     {name: 'C0', number: Math.floor(Math.random() * 200) + 1},
//                     {name: 'C1', number: Math.floor(Math.random() * 200) + 1},
//                     {name: 'C2', number: Math.floor(Math.random() * 200) + 1}
//                 ]
//             },
//             {
//                 title: '2018/12/12',
//                 dataUnits: [
//                     {name: 'C0', number: Math.floor(Math.random() * 200) + 1},
//                     {name: 'C1', number: Math.floor(Math.random() * 200) + 1},
//                     {name: 'C2', number: Math.floor(Math.random() * 200) + 1}
//                 ]
//             }
//         ];
        this.env = {
            project: ''
        };
    };
    componentDidMount () {
        console.log('stotageplan componentDidMount', 'this.props.params.project =', this.props.params.project);
        this.env.project = this.props.params.project;
        this.dataUpdate();
    };
    componentWillReceiveProps (nextProps) {
        if (nextProps.params.project != this.env.project)
        {
            this.env.project = nextProps.params.project;
            console.log('stotageplan componentWillReceiveProps', this.env.project);
            this.dataUpdate();
        }
    };
    render () {
        return (
            <Grid fluid>
                <Row>
                    <Col md={12}>
                        <PageTitile text={`${this.env.project}/${Lang.showText(9)}/${Lang.showText(13)}`} />
                    </Col>
                </Row>
                <Row>
                    <Col md={2} className='data-source-selector'>
                        <FormControl 
                            componentClass='select' 
                            onChange={() => {this._setDataSourceInterval();}} 
                            ref='dataSourceInterval' 
                            disabled={this.state.isLoading}
                        >
                            {
                                this.dataSource.dateList.map((entry) => (
                                    <option value={entry['value']} selected={(this.dataSource.date.interval == entry.value)?true:false}>{entry['text']}</option>
                                ))
                            }
                        </FormControl>
                    </Col>
                    <Col md={2} className='data-source-selector'>
                        <FormControl 
                            componentClass='select' 
                            onChange={() => {this._setDataSourceType();}} 
                            ref='dataSourceType' 
                            disabled={this.state.isLoading}
                        >
                            {
                                this.dataSource.typeList.map((entry) => (
                                    <option value={entry['value']} selected={(this.dataSource.type == entry.value)?true:false}>{entry['text']}</option>
                                ))
                            }
                        </FormControl>
                    </Col>
                </Row>
                <Row>
                    <Col md={12}>
                        <Panel collapsible expanded={this.state.linechartExpand} 
                            header={
                                <span className="clickable" onClick={() => {this._expandHandler('linechart');}}>
                                    {(this.state.linechartExpand)? <FontAwesome name="minus-square"/> : <FontAwesome name="plus-square"/>}
                                    {Lang.showText(13)}
                                </span>
                            } 
                            className='general-expand-panel'
                        >
                            <div className='linegraphTitle'>Line Graph</div>
                            <LineChart
                                Rowlabels={this.lineData.rowlabels}
                                DataUnits={this.lineData.dataUnits}
                                isLoading={this.state.isLoading}
                            />
                        </Panel>
                    </Col>
                </Row>
                <Row>
                    <Col md={12}>
                        <Panel collapsible expanded={this.state.detailExpand} 
                            header={
                                <span className="clickable" onClick={() => {this._expandHandler('detail');}}>
                                    {(this.state.detailExpand)? <FontAwesome name="minus-square"/> : <FontAwesome name="plus-square"/>}
                                    {Lang.showText(30)}
                                </span>
                            } 
                            className='general-expand-panel'
                        >
                            {this.showTable()}
                        </Panel>
                    </Col>
                </Row>
            </Grid>
        );
    };

    dataUpdate () {
        this.setupConfig();
        this.doFetch();
    };
    setupConfig () {
        // 2018-12-10T01:29:30.201L, toISOString()
        let today = new Date().toISOString().split(".")[0];
        // 2018-12-10T01:29:30-06:00
        let dateOBJ = new DataObj.dateTimeObj(today+'+00:00');
        console.log(dateOBJ.epochTime);
        console.log(dateOBJ.epochTime+86400-1);
        let epochTodate = new Date(dateOBJ.epochTime*1000);
        console.log(epochTodate.toLocaleDateString('ja-JP'));

        let interval = this.dataSource.date.interval;
        this.dataSource.date.startDay = dateOBJ.epochTime - ((interval-1)*86400);
        this.dataSource.date.endDay = dateOBJ.epochTime + 86400 - 1;

        this.timeSlot = [];
        let startTime = this.dataSource.date.startDay;
        let endTime = 0;

        if (interval == 1)
        {
            // hour basis
            endTime = this.dataSource.date.startDay + 3600 - 1;

            for (let i=0; i<24; i++)
            {
                let obj = {};
                obj['label'] = ('0' + i).slice(-2) + ':00';
                obj['startTime'] = startTime + (i*3600);
                obj['endTime'] = endTime + (i*3600);
                this.timeSlot.push(obj);
            }
        }
        else if (interval == 7 || interval == 14 || interval == 30 || interval == 60 || interval == 90)
        {
            // daily basis
            endTime = this.dataSource.date.startDay + 86400 - 1;

            for (let i=0; i<interval; i++)
            {
                let obj = {};
                let dateObj = new Date((startTime + (i*86400))*1000);
                obj['label'] = dateObj.getFullYear() + '/' + ('0' + (dateObj.getMonth()+1)).slice(-2) + '/' + ('0' + dateObj.getDate()).slice(-2);
                obj['startTime'] = startTime + (i*86400);
                obj['endTime'] = endTime + (i*86400);;
                this.timeSlot.push(obj);
            }
        }
        console.log('this.timeSlot =', this.timeSlot);
    };
    doFetch () {
        let result;
        let res;
        this.setState({isLoading: true});
//         result = SiteDashboard.getWidget(this.env['siteUuid']);
        res = {
            data: [
                {
                    name: 'DAY',
                    list: [
                        {timestamp:'00:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'00:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'01:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'02:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'03:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'04:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'05:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'06:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'07:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'08:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'09:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'10:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'11:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'12:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'13:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'14:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'15:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'16:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'17:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'18:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'19:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'20:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'21:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'22:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'23:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/11/29', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/11/30', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/01', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/02', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/03', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/04', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/05', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/05', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/06', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/07', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/08', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/08', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/09', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/10', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/10', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/11', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/12', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/13', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/14', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/15', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/16', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/17', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/18', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/19', val: Math.floor(Math.random() * 200) + 1}
                    ]
                },
                {
                    name: 'WEEK',
                    list: [
                        {timestamp:'00:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'01:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'02:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'03:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'04:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'05:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'06:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'07:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'08:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'09:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'10:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'11:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'12:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'13:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'14:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'14:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'15:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'16:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'17:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'18:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'19:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'20:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'21:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'22:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'23:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/11/29', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/11/30', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/01', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/02', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/03', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/04', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/05', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/06', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/06', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/07', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/08', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/08', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/09', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/10', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/10', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/11', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/12', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/13', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/14', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/15', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/16', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/17', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/18', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/19', val: Math.floor(Math.random() * 200) + 1}
                    ]
                },
                {
                    name: 'MONTH',
                    list: [
                        {timestamp:'00:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'01:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'02:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'03:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'04:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'05:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'06:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'07:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'08:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'09:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'10:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'11:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'12:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'13:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'14:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'15:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'16:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'17:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'18:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'18:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'19:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'20:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'21:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'22:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'23:00', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/11/29', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/11/30', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/01', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/02', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/03', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/04', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/05', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/05', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/06', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/07', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/08', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/08', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/09', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/10', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/10', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/11', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/12', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/13', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/14', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/15', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/16', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/17', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/18', val: Math.floor(Math.random() * 200) + 1},
                        {timestamp:'2018/12/19', val: Math.floor(Math.random() * 200) + 1}
                    ]
                }
            ]
        };
//         result.then((res) => {
        setTimeout(() => {
            this.resolveFetchData(res.data);
            this.setState({ isLoading: false });
        }, 1000);
//         });
    };
    resolveFetchData (source) {
        let tableDataBucket = {};
        this.lineData.rowlabels = [];
        this.timeSlot.map((slot) => {
            this.lineData.rowlabels.push(slot.label);
            tableDataBucket[slot.label] = {};
            source.map((entry) => {
                tableDataBucket[slot.label][entry.name] = 0;
            });
        });
        this.lineData.dataUnits = [];
        source.map((entry) => {
            let lineDataBucket = {};
            this.timeSlot.map((slot) => {
                lineDataBucket[slot.label] = 0;
            });
            let lineObj = {};
            lineObj['name'] = entry.name;
            lineObj['data'] = [];
            entry.list.map((list) => {
                if (!isNaN(list.timestamp))
                {
                    let time = parseInt(list.timestamp);
                    for (let i=0; i<this.timeSlot.length; i++)
                    {
                        if (this.timeSlot[i].startTime && this.timeSlot[i].endTime)
                        {
                            if (this.timeSlot[i].startTime <= time && time <= this.timeSlot[i].endTime)
                            {
                                if (lineDataBucket.hasOwnProperty(this.timeSlot[i].label)) lineDataBucket[this.timeSlot[i].label] += parseInt(list.val);
                                if (tableDataBucket.hasOwnProperty(this.timeSlot[i].label)) tableDataBucket[this.timeSlot[i].label][entry.name] += parseInt(list.val);
                                break;
                            }
                        }
                    }
                }
                else
                {
                    if (lineDataBucket.hasOwnProperty(list.timestamp))
                    {
                        lineDataBucket[list.timestamp] += parseInt(list.val);
                    }
                    if (tableDataBucket.hasOwnProperty(list.timestamp))
                    {
                        tableDataBucket[list.timestamp][entry.name] += parseInt(list.val);
                    }
                }
            });
//             console.log('lineDataBucket =', lineDataBucket);
            Object.keys(lineDataBucket).map((label) => {
                lineObj['data'].push(lineDataBucket[label]);
            });
            this.lineData.dataUnits.push(lineObj);
        });
//         console.log('this.lineData.rowlabels =', this.lineData.rowlabels);
//         console.log('this.lineData.dataUnits =', this.lineData.dataUnits);

//         console.log('tableDataBucket =', tableDataBucket);
        this.tableData = [];
        Object.keys(tableDataBucket).map((time) => {
            let obj = {};
            obj['title'] = time;
            obj['dataUnits'] = [];
            Object.keys(tableDataBucket[time]).map((name) => {
                let tableObj = {};
                tableObj['name'] = name;
                tableObj['number'] = tableDataBucket[time][name];
                obj['dataUnits'].push(tableObj);
            });
            this.tableData.push(obj);
        });
//         console.log('this.tableData =', this.tableData);
    };

    showTable () {
        let content = [];
        let data = this.tableData.slice(0);
        let rowLabels = JSON.parse(JSON.stringify(this.columnLabels));
        if (data.length)
        {
            data.map((entry) => {
                content.push(
                    <DetailTable 
                        Title={entry['title']} 
                        ColumnLabels={rowLabels} 
                        DataUnits={entry['dataUnits']} 
                        isLoading={this.state.isLoading}
                    />
                );
            });
        }
        return content;
    };

    _expandHandler (panelType) {
        switch (panelType)
        {
            case 'linechart':
                this.setState({ linechartExpand: !this.state.linechartExpand });
                break;
            case 'detail':
                this.setState({ detailExpand: !this.state.detailExpand});
                break;
        };
    };
    _setDataSourceType () {
        let type = ReactDOM.findDOMNode(this.refs['dataSourceType']).value;
        this.dataSource.type = type;
    };
    _setDataSourceInterval () {
        let interval = parseInt(ReactDOM.findDOMNode(this.refs['dataSourceInterval']).value);
        this.dataSource.date.interval = interval;
        this.dataUpdate();
    };
};
export default Storageplan;