import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {
    Grid, Row, Col, FormGroup, FormControl, ControlLabel, Button, Form, Table
} from 'react-bootstrap';
import { hashHistory } from 'react-router';
import FontAwesome from 'react-fontawesome';
import { Checkbox } from 'react-icheck';

/* component */
import PageTitile from '../../component/pageTitle.js';
/* route */


/* common */
import Lang from '../../common/languages.js';
import StorageData from '../../common/storageData.js';

class SettingsMonitor extends Component {
    constructor (props) {
        super (props);
        this.state = {
            isLoading: false
        };
        this.tableHeader = {
            checkall: {show: true, text: 241},
            deviceId: {show: true, text: 24}
        };
        this.deviceList = [];
        this.selectedDevice = {
            all: 0,
            list: new Set()
        };
        this.addDevice = '';
        this.env = {
            
        };
    };
    componentDidMount () {
        this.dataUpdate();
    };
    render () {
        return (
            <Grid fluid>
                <Row>
                    <Col md={12}>
                        <PageTitile text={`${Lang.showText(54)}/${Lang.showText(40)}`} />
                    </Col>
                </Row>
                <Row>
                    <Col md={12}>
                        <div className='general-panel'>
                            <div className='general-panel-title'>
                                <h3>{Lang.showText(58)}</h3>
                            </div>
                            <div className='general-panel-content'>
                                {this.showTable()}
                            </div>
                            <div className='general-panel-footer'>
                                <Col md={3}>
                                    {this.showButton()}
                                </Col>
                            </div>
                        </div>
                    </Col>
                </Row>
            </Grid>
        );
    };

    dataUpdate () {
        this.doFetch('get');
    };
    doFetch (fetchType) {
        let result;
        let res;
        this.setState({isLoading: true});
        switch (fetchType) 
        {
            case 'get':
//                 result = SiteDashboard.getWidget(this.env['siteUuid']);
//                 result.then((res) => {
//                 });
                res = {
                    data: [
                        {deviceId: this.genUuid()},
                        {deviceId: this.genUuid()},
                        {deviceId: this.genUuid()},
                        {deviceId: this.genUuid()},
                        {deviceId: this.genUuid()}
                    ]
                };
                setTimeout(() => {
                    this.resolveFetchData(res.data);
                    this.setState({ isLoading: false });
                }, 1000);
            break;
            case 'edit':
                this.setState({ isLoading: false });
            break;
        }
    };
    resolveFetchData (data) {
        this.deviceList = data.slice(0);
    };
    genUuid () {
        let d = Date.now();
        if (typeof performance !== 'undefined' && typeof performance.now === 'function')
        {
            d += performance.now();
        }
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
            let r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
    };

    showTable () {
        let content = [];
        content.push(
            <Table striped hover className='settings-table'>
                <thead>
                    <tr>
                        {
                            (() => {
                                let content_th = [];
                                Object.keys(this.tableHeader).map((entry) => {
                                    if (this.tableHeader[entry].show)
                                    {
                                        switch (entry)
                                        {
                                            case 'checkall':
                                                // content_th.push(
                                                //     <th style={{'width': '50px'}}>
                                                //         <Checkbox
                                                //             checkboxClass='icheckbox_square-grey'
                                                //             increaseArea="20%"
                                                //             checked={(1 == this.selectedDevice['all'])? true:false}
                                                //             onChange={() => {this._checkHandler('all')}}
                                                //         />
                                                //     </th>
                                                // );
                                            break;
                                            default:
                                                content_th.push(
                                                    <th>{Lang.showText(this.tableHeader[entry].text)}</th>
                                                );
                                            break;
                                        }
                                    }
                                });
                                return content_th;
                            })()
                        }
                    </tr>
                </thead>
                {this.showTableBody()}
            </Table>
        );
        return content;
    };
    showTableBody () {
        let content = [];
        let data = this.deviceList.slice(0);
        content.push(
            <tbody>
            {
                data.map((entry) => {
                    let content_tr = [];
                    content_tr.push(
                        <tr>
                        {
                            Object.keys(this.tableHeader).map((item) => {
                                let content_td = [];
                                if (this.tableHeader[item].show)
                                {
                                    switch (item)
                                    {
                                        case 'checkall':
                                            // content_td.push(
                                            //     <td>
                                            //         <Checkbox
                                            //             checkboxClass='icheckbox_square-grey'
                                            //             increaseArea="20%"
                                            //             checked={this.selectedDevice.list.has(entry['deviceId'])}
                                            //             onChange={()=>this._checkHandler(entry['deviceId'])}
                                            //         />
                                            //     </td>
                                            // );
                                        break;
                                        default:
                                            content_td.push(
                                                <td>{entry[item]}</td>
                                            );
                                        break;
                                    }
                                }
                                return content_td;
                            })
                        }
                        </tr>
                    );
                    return content_tr;
                })
            }
            </tbody>
                // <tr>
                // {
                //     Object.keys(this.tableHeader).map((item) => {
                //         let content_td = [];
                //         if (this.tableHeader[item].show)
                //         {
                //             switch (item)
                //             {
                //                 case 'checkall':
                //                     content_td.push(
                //                         <td>
                //                             <Button onClick={()=>{this._actionHandler('delete');}} disabled={(this.selectedDevice.list.size)?false:true}>{Lang.showText(458)}</Button>
                //                         </td>
                //                     );
                //                 break;
                //                 default:
                //                     content_td.push(
                //                         <td>
                //                             <div style={{'width': '500px', 'margin-right':'5px', 'display': 'inline-flex'}}>
                //                                 <FormControl 
                //                                     type='text' 
                //                                     placeholder={Lang.showText(25)}
                //                                     onChange={()=>{this._changeHandler('addDevice');}} 
                //                                     ref='addDevice'
                //                                     maxLength='32'
                //                                     style={{height:'34px'}}
                //                                 />
                //                             </div>
                //                             <div style={{'width': '300px', 'display': 'inline-flex'}}>
                //                                 <Button onClick={()=>{this._actionHandler('add');}} disabled={(this.addDevice == '')?true:false}>{Lang.showText(76)}</Button>
                //                             </div>
                //                         </td>
                //                     );
                //                 break;
                //             }
                //         }
                //         return content_td;
                //     })
                // }
                // </tr>
            //</tbody>
        );
        return content;
    };
    showButton () {
        let content = [];
        // if (this.state['isLoading'])
        // {
        //     content.push(
        //         <div>
        //             <Button disabled>{Lang.showText(65)}</Button>
        //             <Button disabled>{Lang.showText(61)}</Button>
        //             <span className="accessingTag"><FontAwesome name='spinner' size='lg' pulse/>{Lang.showText(48)}</span> 
        //         </div>
        //     );
        // }
        // else
        // {
        //     content.push(
        //         <div>
        //             <Button onClick={()=>{this._submitHandler('save');}} bsStyle="success">{Lang.showText(65)}</Button>
        //             <Button onClick={()=>{this._redirectHandler('/home/settings/general');}} bsStyle="primary">{Lang.showText(61)}</Button>
        //         </div>
        //     );
        // };
        return content;
    };

    _checkHandler (deviceId) {
        if (deviceId == 'all')
        {
            this.selectedDevice.list.clear();
            this.selectedDevice['all'] = !this.selectedDevice['all'];
            if (1 == this.selectedDevice['all'])
            {
                this.deviceList.map((entry) => {
                    this.selectedDevice.list.add(entry['deviceId']);
                });
            }
        }
        else
        {
            if (this.selectedDevice.list.has(deviceId))
            {
                this.selectedDevice.list.delete(deviceId);
                this.selectedDevice['all'] = 0;
            }
            else
            {
                this.selectedDevice.list.add(deviceId);
            }
        }
        this.forceUpdate();
    };
    _actionHandler (type) {
        switch (type)
        {
            case 'add':
                // TODO, validation check for Device ID
                this.deviceList.push({deviceId: this.addDevice});
                ReactDOM.findDOMNode(this.refs['addDevice']).value = '';
                this.addDevice = '';
            break;
            case 'delete':
                let deleteList = Array.from(this.selectedDevice.list);
                for (let i=0; i<deleteList.length; i++)
                {
                    for (let j=0; j<this.deviceList.length; j++)
                    {
                        if (this.deviceList[j].deviceId == deleteList[i])
                        {
                            this.deviceList.splice(j, 1);
                            break;
                        }
                    }  
                }
                this.selectedDevice.list.clear();
            break;
        }
        this.forceUpdate();
    };
    _changeHandler (name) {
        let value = ReactDOM.findDOMNode(this.refs[`${name}`]).value;
        this.addDevice = value;
        this.forceUpdate();
    };
    _redirectHandler (path) {
        let homeThis = StorageData.get('homeThis');
        if (homeThis)
        {
            homeThis.env.nextPath = path;
        }
        hashHistory.push(path);
    };
    _submitHandler (type) {
        switch (type)
        {
            case 'save':
                
            break;
        }
    };
};

export default SettingsMonitor;