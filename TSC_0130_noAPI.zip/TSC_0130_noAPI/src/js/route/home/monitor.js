import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { Grid, Row, Col, FormControl } from 'react-bootstrap';

/* component */
import Lang from '../../common/languages.js';
import PageTitile from '../../component/pageTitle.js';

class Monitor extends Component {
    constructor (props) {
        super (props);
        this.state = {
            isLoading: false
        };
        this.dataSource = {
            deviceId: '',
            deviceIdList: []
        };
        this.env = {
            project: ''
        };
    };
    genUuid () {
        let d = Date.now();
        if (typeof performance !== 'undefined' && typeof performance.now === 'function')
        {
            d += performance.now();
        }
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
            let r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
    };
    componentDidMount () {
        console.log('monitor componentDidMount', 'this.props.params.project =', this.props.params.project);
        this.env.project = this.props.params.project;

        var svg = document.getElementsByClassName("monitorsvg");
        var div = document.getElementsByClassName("card__body")[0];
        
        for (let i=0; i<svg.length; i++)
            svg[i].setAttribute("height", div.offsetHeight);

        this.dataUpdate();
    };
    componentWillReceiveProps (nextProps) {
        if (nextProps.params.project != this.env.project)
        {
            this.env.project = nextProps.params.project;
            console.log('monitor componentWillReceiveProps', this.env.project);
            this.dataUpdate();
        }
    };
    render () {
        return (
            <Grid fluid>
                <Row>
                    <Col md={12}>
                        <PageTitile text={`${this.env.project}/${Lang.showText(3)}/${Lang.showText(8)}`} />
                    </Col>
                </Row>
                <Row>
                    <Col md={4} className='data-source-selector'>
                        <FormControl 
                            componentClass='select' 
                            onChange={() => {this._setDataSourceDeviceId();}} 
                            ref='dataSourceDeviceId' 
                            disabled={this.state.isLoading}
                        >
                            {this.showDeviceList()}
                        </FormControl>
                    </Col>
                </Row>
                <Row>
                    <Col md={12}>
                        <div className='general-panel'>
                            <div className='general-panel-title'>
                                <h3>{Lang.showText(38)}</h3>
                            </div>
                            <div className='general-panel-content'>
                                {this.showList()}
                            </div>
                        </div>
                    </Col>
                </Row>
            </Grid>
        );
    };
    dataUpdate () {
        this.doFetch();
    };
    doFetch () {
        this.setState({isLoading: true});
        let res;
        res = {
            data: [
                {
                    deviceId: '12/11/2018 18:01:12',
                    eventList:[
                        {event: 'upload clip', info: '{"api":"upload_clip","date":1543284663,"devid":"913E6052E3B17F277E92FAC7A8D6F158724A458B869A1D636D871D785D646AE8","from":"108.53.36.205","request":{"clipid":"d8d2d569-c42a-4da1-9df7-be5ef87e3d57","duration":"30","event_type":"Sound/Others","eventid":"d8d2d569-c42a-4da1-9df7-be5ef87e3d57","resolution":"1920x1080","time":"2018-11-27 00:05:53"},"response":"Unable to obtain user public key.ok. (0sec)","stage":"LyricDev","type":"api"}'},
                        {event: 'upload clip', info: '{"api":"upload_clip","date":1543284663,"devid":"913E6052E3B17F277E92FAC7A8D6F158724A458B869A1D636D871D785D646AE8","from":"108.53.36.205","request":{"clipid":"d8d2d569-c42a-4da1-9df7-be5ef87e3d57","duration":"30","event_type":"Sound/Others","eventid":"d8d2d569-c42a-4da1-9df7-be5ef87e3d57","resolution":"1920x1080","time":"2018-11-27 00:05:53"},"response":"Unable to obtain user public key.ok. (0sec)","stage":"LyricDev","type":"api"}'},
                        {event: 'upload clip', info: '{"api":"upload_clip","date":1543284663,"devid":"913E6052E3B17F277E92FAC7A8D6F158724A458B869A1D636D871D785D646AE8","from":"108.53.36.205","request":{"clipid":"d8d2d569-c42a-4da1-9df7-be5ef87e3d57","duration":"30","event_type":"Sound/Others","eventid":"d8d2d569-c42a-4da1-9df7-be5ef87e3d57","resolution":"1920x1080","time":"2018-11-27 00:05:53"},"response":"Unable to obtain user public key.ok. (0sec)","stage":"LyricDev","type":"api"}'},
                        {event: 'upload clip', info: '{"api":"upload_clip","date":1543284663,"devid":"913E6052E3B17F277E92FAC7A8D6F158724A458B869A1D636D871D785D646AE8","from":"108.53.36.205","request":{"clipid":"d8d2d569-c42a-4da1-9df7-be5ef87e3d57","duration":"30","event_type":"Sound/Others","eventid":"d8d2d569-c42a-4da1-9df7-be5ef87e3d57","resolution":"1920x1080","time":"2018-11-27 00:05:53"},"response":"Unable to obtain user public key.ok. (0sec)","stage":"LyricDev","type":"api"}'}
                    ]
                },
                {
                    deviceId: this.genUuid(),
                    eventList:[
                        {timestamp: '2018/12/13', event: Math.floor(Math.random() * 200)},
                        {timestamp: '2018/12/13', event: Math.floor(Math.random() * 200)},
                        {timestamp: '2018/12/13', event: Math.floor(Math.random() * 200)},
                        {timestamp: '2018/12/13', event: Math.floor(Math.random() * 200)}
                    ]
                },
                {
                    deviceId: this.genUuid(),
                    eventList:[
                        {timestamp: '2018/12/13', event: Math.floor(Math.random() * 200)},
                        {timestamp: '2018/12/13', event: Math.floor(Math.random() * 200)},
                        {timestamp: '2018/12/13', event: Math.floor(Math.random() * 200)},
                        {timestamp: '2018/12/13', event: Math.floor(Math.random() * 200)}
                    ]
                }
            ]
        };
        setTimeout(() => {
            this.resolveFetchData(res.data);
            this.setState({isLoading: false});
        }, 1000);
    };
    resolveFetchData (source) {
        this.dataSource.deviceIdList = source.slice(0);
        this.dataSource.deviceId = this.dataSource.deviceIdList[0].deviceId;
    };

    showDeviceList () {
        let content = [];
        if (this.dataSource.deviceIdList.length)
        {
            this.dataSource.deviceIdList.map((entry, index) => {
                content.push(<option value={entry['deviceId']} selected={(this.dataSource.deviceId == entry.deviceId)?true:false}>{`Device ID ${index+1}: ${entry['deviceId']}`}</option>);
            });
        }
        else
        {
            content.push(<option disabled>Loading...</option>);
        }
        return content;
    };
    showList () {
        const cardBody = {
            'background': 'white'
        };
        let content = [];
        console.log(this.dataSource.deviceIdList);
        if (this.dataSource.deviceIdList.length)
        {
            let destID = this.dataSource.deviceIdList.find(d => d.deviceId == this.dataSource.deviceId);
            destID.eventList.map((entry) => {
                content.push(
                    <div className="card__body" style={cardBody}>
                        {this.showlistUnit(entry)}
                    </div>
                );
            });
        }
        else
        {
            content.push('Loading...');
        }
        return content;
    };
    showlistUnit (source) {
        let content = [];
        const DeviceID = {
            'padding-top': '10',
            'color': 'darkslategray',
            'font-size': '16px'
        };
        const Time = {
            'color': 'gray',
            'font-size': '12px'
        };
        const Event = {
            'padding-bottom': '5',
            'color': 'darkslategray',
            'font-size': '12px'
        };
        content.push(
            <div className="monitorUnit">
                <svg className="monitorsvg">
                    <line x1="10" y1="0" x2="10" y2='100%' />
                    <circle cx="10" cy="20" r="5" fill="white" />
                </svg>
                <p style={DeviceID}>{this.dataSource.deviceId}</p>
                <p style={Time}>{source['event']}</p>
                <p style={Event}>{source['info']}</p>
            </div>
        );
        return content;
    };

    _setDataSourceDeviceId () {
        let devId = ReactDOM.findDOMNode(this.refs['dataSourceDeviceId']).value;
        this.dataSource.deviceId = devId;
        this.setState(this.state);
    };
};

export default Monitor;