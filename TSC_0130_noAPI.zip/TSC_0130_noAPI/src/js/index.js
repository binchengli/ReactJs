import React, { Component } from 'react';
import { render } from 'react-dom';
import { hashHistory, Router, Route, IndexRedirect } from 'react-router';
// import {defaults} from 'react-chartjs-2';
// defaults.global.animation.duration= 0;
window.Promise = Promise;

import Lang from './common/languages.js';

/* route */
import Login from './route/login/login.js';
import Home from './route/home/home.js';

import Devices from './route/home/devices.js';
import Server from './route/home/server.js';
import Audiences from './route/home/audiences.js';
import SytemLogs from './route/home/systemlogs.js';
import Monitor from './route/home/monitor.js';
// 
import Clip from './route/home/clip.js';
import LiveStream from './route/home/livestream.js';
import FirmwareVersion from './route/home/firmwareversion.js';
import StoragePlan from './route/home/storageplan.js';
import OnlineStatus from './route/home/onlinestatus.js';

import SettingsGeneral from './route/home/settingsGeneral.js';
import SettingsPassword from './route/home/settingsPassword.js';
import SettingsMonitor from './route/home/settingsMonitor.js';

import Blank from './route/other/blank.js';
import Page_404 from './route/other/404.js';

document.title = process.env['NAME'];

class Index extends Component {
    render () {
        return (
            <div>{this.props.children}</div>
        );
    };
};

class RouteMap extends Component {
    constructor (props) {
        super(props);
        Lang.initLanguage();
    };
    render () {
        return (
            <Router history={hashHistory}>
                <Route path='/' component={Index}>
                    <IndexRedirect to='/login' />
                    <Route path='/login' component={Login} />
                    <Route path='/login/*' component={Page_404} />
                    <Route path='/home' component={Home}>
                        <Route path='/home/realtime/devices/:project' component={Devices}/>
                        <Route path='/home/realtime/server/:project' component={Server}/>
                        <Route path='/home/realtime/audiences/:project' component={Audiences}/>
                        <Route path='/home/realtime/logs/:project' component={SytemLogs}/>
                        <Route path='/home/realtime/monitor/:project' component={Monitor}/>

                        <Route path='/home/statistic/clip/:project' component={Clip}/>
                        <Route path='/home/statistic/livestream/:project' component={LiveStream}/>
                        <Route path='/home/statistic/firmwareversion/:project' component={FirmwareVersion}/>
                        <Route path='/home/statistic/storageplan/:project' component={StoragePlan}/>
                        <Route path='/home/statistic/onlinestatus/:project' component={OnlineStatus}/>

                        <Route path='/home/settings/general' component={SettingsGeneral}/>
                        <Route path='/home/settings/password' component={SettingsPassword}/>
                        <Route path='/home/settings/monitor' component={SettingsMonitor}/>
                        
                        <Route path='/home/*' component={Page_404}/>
                    </Route>
                    <Route path='/blank' component={Blank} />
                    <Route path='/404' component={Page_404} />
                    <Route path='/*' component={Page_404} />
                </Route>
            </Router>
        );
    };
};

render((<RouteMap />), document.getElementById('main'));
