import { hashHistory } from 'react-router';
import 'whatwg-fetch';

import ServerAPI from './server.js';

const LYRIC_Device = (() => {
    const onlinecamera = (obj) => {
        let URL = ServerAPI.URLlist['lyric_rt_CamOnline'];
        return fetch(URL, {
            method: 'GET',
            headers: {
                'Authorization': ServerAPI.getJWT()
            }
        })
        .then((response) => {
            return ServerAPI.httpCheck(response);
        });
    };

    return {
        onlinecamera: onlinecamera
    };
})();

export default LYRIC_Device;