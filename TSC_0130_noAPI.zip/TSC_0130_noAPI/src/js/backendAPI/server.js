import 'whatwg-fetch';

import AccountAPI from './account.js';
import ConstDef from '../common/constDef.js';
import FunctionJS from '../common/functionJS.js';
import { hashHistory } from 'react-router';
import Lang from '../common/languages.js';

const ServerAPI = (() => {
    let domain = `http://localhost:8680/`;
    let storageDomain = 'http://localhost:8680/';
    //let domain = ('' != process.env['APIDOMAIN'])? process.env['APIDOMAIN'] : `http://${location.hostname}:${process.env['APIPORT']}/`;
    //let storageDomain = ('' != process.env['STORAGEDOMAIN'])? process.env['STORAGEDOMAIN'] : `http://${location.hostname}:${process.env['STORAGEPORT']}/`;
    let LS_JWT = `${process.env['LSNAME']}_JWT`;
    let LS_userUuid = `${process.env['LSNAME']}_uuid`;

    const options = {
        title: 'Title',
        message: 'Message',
        buttons: [
          {
            label: 'Yes',
            onClick: () => alert('Click Yes')
          },
          {
            label: 'No',
            onClick: () => alert('Click No')
          }
        ],
        childrenElement: () => <div />,
        customUI: ({ title, message, onClose }) => <div>Custom UI</div>,
        willUnmount: () => {}
    }
    
    const httpCheck = (response) => {
        if (response) 
        {
            switch(response.status)
            {
                case 200:
                    if(response.headers.get('authorization'))
                    {
                        ServerAPI.saveJWT(response.headers.get('authorization'));
                    };
                    return response.json();
                    break;
                case 401:
                    console.log(`ERROR (401), Unauthorized.`);
                    AccountAPI.logout();
                    break;
                default:
                    return response.json();
                    break;
            };
        };
    };
    const errorCodeCheck = (response) => {
        let consoleMessage = '';
        let alertMessage = '';

        if(response)
            return response;
    };
    const saveJWT = (token) => {
        if(token)
        {
            localStorage.setItem(LS_JWT, token);
        };
    };
    const getJWT = () => {
        return localStorage.getItem(LS_JWT);
    };
    const cleanJWT = () => {
        localStorage.removeItem(LS_JWT);
    };
    const saveUserInfo = (user) => {
        localStorage.setItem(LS_userUuid, user.uuid);
    };
    const getUserInfo = () => {
        let returnInfo = {
            uuid: localStorage.getItem(LS_userUuid),
        };
        return returnInfo;
    };
    const cleanUserInfo = () => {
        localStorage.removeItem(LS_userUuid);
    };

    /* API URL List */ 
    const URLlist = {
        refresh                         : domain + 'v1/refresh',

        /* account */
        acc_Auth                        : domain + 'auth',
        
        /* lyric */
        /* Device */
        lyric_rt_CamOnline              : domain + 'lyric/realtime/camonline',
        lyric_rt_CamOffline             : domain + 'lyric/realtime/camoffline',
        lyric_rt_ClipNum                : domain + 'lyric/realtime/clipnum',
        lyric_rt_LiveNum                : domain + 'lyric/realtime/livenum',
        lyric_rt_DevActive              : domain + 'lyric/realtime/devactive',
        lyric_rt_DevOnline              : domain + 'lyric/realtime/devonline',
        lyric_rt_DevOffine              : domain + 'lyric/realtime/devoffline',
        lyric_rt_ModePriv               : domain + 'lyric/realtime/privacymode',
        lyric_rt_ModeNight              : domain + 'lyric/realtime/nightmode',
        lyric_rt_Motion                 : domain + 'lyric/realtime/motion',
        lyric_rt_Audio                  : domain + 'lyric/realtime/audio',
        lyric_rt_Storage                : domain + 'lyric/realtime/storageplan',
        lyric_rt_FWVer                  : domain + 'lyric/realtime/fwversion',
        /* Server */
        lyric_rt_Health                 : domain + 'lyric/realtime/serverhealth',
        lyric_rt_ClipTotal              : domain + 'lyric/realtime/cliptotal',
        lyric_rt_Capacity               : domain + 'lyric/realtime/capacity',
        lyric_rt_ReqCount               : domain + 'lyric/realtime/reqcount',
        lyric_rt_ResPing                : domain + 'lyric/realtime/resping',
        lyric_rt_ResSuccessRate         : domain + 'lyric/realtime/ressuccessrate',
        lyric_rt_APItoCHIL              : domain + 'lyric/realtime/apitochil',
        lyric_rt_APItoDev               : domain + 'lyric/realtime/apitodev',
        lyric_rt_DDNStoCHIL             : domain + 'lyric/realtime/ddnstochil',
        lyric_rt_DDNStoDev              : domain + 'lyric/realtime/ddnstodev',
        lyric_rt_RelaytoDev             : domain + 'lyric/realtime/relaytodev',
        lyric_rt_CliptoDev              : domain + 'lyric/realtime/cliptodev',
        lyric_rt_APICPU                 : domain + 'lyric/realtime/apicpuusage',
        lyric_rt_RDSCPU                 : domain + 'lyric/realtime/rdscpuusage',
        /* Audiences */
        lyric_rt_Audiences              : domain + 'lyric/realtime/audiences',

        lyric_rt_Server                 : domain + 'lyric/realtime/server',
        lyric_rt_Audiences              : domain + 'lyric/realtime/audiences',
        lyric_rt_Serverlog              : domain + 'lyric/realtime/serverlog',
        lyric_rt_LRMonitor              : domain + 'lyric/realtime/lrmonitor',

        lyric_stat_Clip                 : domain + 'lyric/statistic/clip',
        lyric_stat_Streaming            : domain + 'lyric/statistic/streaming',
        lyric_stat_FWVersion            : domain + 'lyric/statistic/fwversion',
        lyric_stat_Storage              : domain + 'lyric/statistic/storage',
        lyric_stat_Status               : domain + 'lyric/statistic/status',

        /* tc */
        /*
        tc_rt_Device                    : domain + 'tc/realtime/device',
        tc_rt_Server                    : domain + 'tc/realtime/server',
        tc_rt_Audiences                 : domain + 'tc/realtime/audiences',
        tc_rt_Serverlog                 : domain + 'tc/realtime/serverlog',
        tc_rt_LRMonitor                 : domain + 'tc/realtime/lrmonitor',

        tc_stat_Clip                    : domain + 'tc/statistic/clip',
        tc_stat_Streaming               : domain + 'tc/statistic/streaming',
        tc_stat_FWVersion               : domain + 'tc/statistic/fwversion',
        tc_stat_Storage                 : domain + 'tc/statistic/storage',
        tc_stat_Status                  : domain + 'tc/statistic/status',
        */
    };
    return {
        domain: domain,
        storageDomain: storageDomain,
        httpCheck: httpCheck,
        errorCodeCheck: errorCodeCheck,
        saveJWT: saveJWT,
        getJWT: getJWT,
        cleanJWT: cleanJWT,
        saveUserInfo: saveUserInfo,
        getUserInfo: getUserInfo,
        cleanUserInfo: cleanUserInfo,
        URLlist: URLlist
    };
})();

export default ServerAPI;