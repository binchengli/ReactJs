import { hashHistory } from 'react-router';
import 'whatwg-fetch';

import ServerAPI from './server.js';
import AccountAPI from './Account.js';
const GetLogo = (() => {
   

    const getLogo = (path) => {
         let URL = ServerAPI.domain;//'https://dashboard.editsc.com/';
         
         let mpath='files/'+path;
        if (location.hostname.indexOf('http://localhost') != -1)
        {
            URL=URL+mpath;
        }
        else
            URL=ServerAPI.domain.split('#')[0]+mpath;

        return fetch(URL, {
            method: 'GET',
            headers: {
                'Authorization': ServerAPI.getJWT()
            },
        })
        .then((response) => {
            let blob=httpCheck(response);
          
            return blob;
        });
    };

    const check = (path) => {
        return (ServerAPI.getJWT())? true : false;
    };
    
    const httpCheck = (response) => {
        if (response) 
        {
            switch(response.status)
            {
                case 200:
                    
                    return response.blob();
                    break;
                case 401:
                    AccountAPI.logout();
                    break;
                default:
                    return response;
                    break;
            };
        };
    };

    return {
        check: check,
        getLogo:getLogo
    };
})();

export default GetLogo;