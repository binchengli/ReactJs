import { hashHistory } from 'react-router';
import 'whatwg-fetch';

import ServerAPI from './server.js';

var refreshTimer;
const AccountAPI = (() => {
    const login = (obj) => {
        let URL = ServerAPI.URLlist['acc_Auth'];
        return fetch(URL, {
            method: 'POST',
            headers: {
                //'Authorization': ServerAPI.getJWT(),
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                mail: obj['username'],
                security: obj['security']
            })
        }).catch(error => {
        })
        .then((response) => {
            return ServerAPI.httpCheck(response);
        });
    };
   
    const refreshtoken = () => {
        let URL = ServerAPI.URLlist['refresh'];
        return fetch(URL, {
            method: 'GET',
            headers: {
                'Authorization': ServerAPI.getJWT(),
                'Content-Type': 'application/json'
            },
        }).catch(error => {
        })
        .then((response) => {
            return ServerAPI.httpCheck(response);
        });
    };

    var refresh=()=>{
        refreshTimer = setInterval(refreshtoken, 50*60*1000);
    }

    const getAccountList = (uuid) => {
        let URL = ServerAPI.URLlist['accountlist'];
    
        return fetch(URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': ServerAPI.getJWT()
            },
            body: JSON.stringify({
                uuid: uuid,
            })
        })
        .then((response) => {
            return ServerAPI.httpCheck(response);
        });
    };

    const logout = () => {
        ServerAPI.cleanJWT();
        ServerAPI.cleanUserInfo();
        ServerAPI.cleanLoginInfo();
        ServerAPI.cleanUserPermission();
        if(refreshTimer){
            clearInterval(refreshTimer);
            refreshTimer=null;
        }
        hashHistory.push('/login');
    };
    const check = (path) => {
        return (ServerAPI.getJWT())? true : false;
    };
    const passwordRequest = (obj) => {
        let URL = ServerAPI.URLlist['acc_PasswordRequest'];
        return fetch(URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: obj['username']
            })
        })
        .then((response) => {
            return ServerAPI.httpCheck(response);
        });
    };
    const passwordReset = (obj) => {
        let URL = ServerAPI.URLlist['acc_PasswordReset'];
        return fetch(URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: obj['username'],
                security: obj['security'],
                code: obj['code']
            })
        })
        .then((response) => {
            return ServerAPI.httpCheck(response);
        });
    };

    const forget = (obj) => {
        let URL = ServerAPI.URLlist['acc_forget'];
        return fetch(URL, {
            method: 'POST',
            headers: {
                'Authorization': ServerAPI.getJWT(),
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                mail: obj['mail']
            })
        })
        .then((response) => {
            return ServerAPI.httpCheck(response);
        });
    };

    const verify = (obj) => {
        let URL = ServerAPI.URLlist['acc_verify'];
        return fetch(URL, {
            method: 'POST',
            headers: {
                'Authorization': ServerAPI.getJWT(),
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                mail: obj['mail'],
                pincode: obj['pincode']
            })
        })
        .then((response) => {
            return ServerAPI.httpCheck(response);
        });
    };

    const reset = (obj) => {
        let URL = ServerAPI.URLlist['acc_reset'];
        return fetch(URL, {
            method: 'POST',
            headers: {
                'Authorization': ServerAPI.getJWT(),
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                mail: obj['mail'],
                newpwd: obj['newpwd']
            })
        })
        .then((response) => {
            return ServerAPI.httpCheck(response);
        });
    };

    return {
        login: login,
        logout: logout,
        check: check,
        passwordRequest: passwordRequest,
        passwordReset: passwordReset,
        getAccountList:getAccountList,
        forget: forget,
        verify: verify,
        reset: reset,
        refresh:refresh
    };
})();

export default AccountAPI;