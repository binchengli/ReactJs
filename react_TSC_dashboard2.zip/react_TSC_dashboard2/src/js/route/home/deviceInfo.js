import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {
    Grid, Row, Col, FormGroup, FormControl, ControlLabel, Button, Form,Panel,Label
} from 'react-bootstrap';
import { hashHistory } from 'react-router';
import FontAwesome from 'react-fontawesome';
import Switch from 'react-bootstrap-switch';

import DeviceAPI from '../../backendAPI/DeviceAPI.js';

/* component */
import PageTitile from '../../component/pageTitle.js';
/* route */


/* common */
import Lang from '../../common/languages.js';
import StorageData from '../../common/storageData.js';

class DeviceInfo extends Component {
    constructor (props) {
        super (props);
        this.state = {
            isLoading: false,
            isDataLoading: false,
            devname: '',
            status: '',
            model: '',
            mac: '',
            devid: '',
            owner:'',
            checked: false
        };
        this.handleChange = this.handleChange.bind(this);
        this.formData = {
            refreshTime: 5
        };
        this.deviceInfoData = [];
        this.env = {
            
        };
        
        this.options = [
            {
                index: 0,
                text: 'Suspend',
                isSelect: true
            },
            {
                index: 1,
                text: 'Resume',
                isSelect: false
            }
        ];
    };
    componentDidMount () {
        let deviceID = StorageData.get('DeviceID');
        
        
        this.doFetch(deviceID);
    };
    componentWillReceiveProps (nextProps) {
        
    };

    dataUpdate () {
        
    };

    doFetch (deviceID) {
        let result;
        this.setState({isLoading: true});

        result = DeviceAPI.device_info(deviceID);
        result.then((res) => 
            {
                if(res)
                { 
                    if(res.data==null)
                    {
                    }else
                    {
                        this.setState({
                            devname:res.data[0].devname,
                            status:res.data[0].status,
                            model:res.data[0].model,
                            mac:res.data[0].mac,
                            devid:res.data[0].devid,
                            owner:res.data[0].owner,
                            isLoading:false
                        });
                    }
                }
                else
                {
                    this.setState({ isLoading: false });
                }
           });
    };


    render () {
        return (
            <Grid fluid>
                 
                <Row >
                    <Col md={12}>
                        {/* <PageTitile text={`${Lang.showText(54)}/${Lang.showText(40)}`} /> */}
                        <PageTitile text={`${'Device Manage'}/${'Device infomation'}`} />
                    </Col>
                </Row>
                <Row  className='general-panel'  >
                    <Panel >
                <Row>
                    <Col md={12}>
                        <div className='general-panel'>   
                        <Col md={1} style={{'padding-left':'0%'}}>
                            {/* <FontAwesome name='times-circle' size='2x' onClick={() => {this._redirectHandler('/home/device');}} className='settings-icon' style={{'padding-right':'3%'}}/> */}
                            <Button onClick={()=>{this._redirectHandler('/home/device');}} bsStyle="success">
                                            <FontAwesome name = "reply" className='clickable' size='lg' onClick={() => {this._redirectHandler('/home/device');}}/>                          
                                        </Button>
                            
                           
                                        </Col>
                            {/* <div className='general-panel-title'>
                                <h3>{Lang.showText(40)}</h3>
                            </div> */}
                            <div className='general-panel-content'>
                                <Form horizontal>
                                <FormGroup>
                                        <Col componentClass={ControlLabel} md={3}>{`Name:`}</Col>
                                        <Col style={{'text-align':'left','font-fontweight':'10', 'display':'table-cell','vertical-align': 'middle','padding-top':'7px'}}  md={3}>{this.state.devname}
                                         </Col>
                                    </FormGroup>
                                    <FormGroup>
                                        <Col componentClass={ControlLabel} md={3}>{`Account:`}</Col>
                                        <Col style={{'text-align':'left','font-fontweight':'10', 'display':'table-cell','vertical-align': 'middle','padding-top':'7px'}}  md={3}>{this.state.owner}</Col>
                                        
                                    </FormGroup>
                                    <FormGroup>
                                        <Col componentClass={ControlLabel} md={3}>{`Status:`}</Col>
                                        <Col style={{'text-align':'left','font-fontweight':'10', 'display':'table-cell','vertical-align': 'middle','padding-top':'7px'}}  md={3}>{this.state.status}</Col>
                                        
                                    </FormGroup>
                                    <FormGroup>
                                        <Col componentClass={ControlLabel} md={3}>{`Model:`}</Col>
                                        <Col style={{'text-align':'left','font-fontweight':'10', 'display':'table-cell','vertical-align': 'middle','padding-top':'7px'}}  md={3}>{this.state.model}</Col>
                                    </FormGroup>
                                    <FormGroup>
                                        <Col componentClass={ControlLabel} md={3}>{`Mac:`}</Col>
                                        <Col style={{'text-align':'left','font-fontweight':'10', 'display':'table-cell','vertical-align': 'middle','padding-top':'7px'}}  md={3}>{this.state.mac}</Col>
                                    </FormGroup>
                                    <FormGroup>
                                        <Col componentClass={ControlLabel} md={3}>{`Device ID:`}</Col>
                                        <Col style={{'text-align':'left','font-fontweight':'10', 'display':'table-cell','vertical-align': 'middle','padding-top':'7px'}}  md={3}>{this.state.devid}</Col>
                                        
                                    </FormGroup>
                                    <FormGroup>
                                        <Col componentClass={ControlLabel} md={3}>{`Suspend:`}</Col>
                                        <Col  md={3}>
                                        <label htmlFor="normal-switch">
                                    {/* <span>Suspend</span> */}
                                    <Switch
                                        onChange={this.handleChange}
                                        value={this.state.checked}
                                        id="normal-switch"
                                    />
                                </label>
                                        </Col>
                                       
                                    </FormGroup>
                                </Form>
                            </div>
                            {/* <div className="btn-group" role="group" style={{'padding-left': "0px", 'margin-top':'18px'}}> */}
                                {/* {
                                    this.options.map((option) => {
                                        return (
                                            <Button 
                                                title = {option.text}
                                                onClick = {() => this.onSelectTypeChange(option.index)}
                                                bsStyle={this.options[option.index].isSelect ? "success" : "default"}
                                            >
                                                <option>{option.text}</option>
                                            </Button >
                                        );
                                    })
                                } */}
                                
                                {/* </div> */}
                                <div className='general-panel-footer'>
                                <Col  mdOffset={8}>
                                    {this.showButton()}
                                </Col>
                                </div> 
                        </div>
                        
                    </Col>
                </Row>
                </Panel>
                </Row>
            </Grid>
        );
    };
    handleChange(checked) {
        this.setState({ checked });
      }
    
    onSelectTypeChange(index) {
        this.options.map((option) => {
            option.isSelect = index == option.index ? true : false;
        });

        this.setState({isRefresh: false});
    }
    showButton () {
        let content = [];
        content.push(
            <div>
                {/* <Button onClick={()=>{this._submitHandler('save');}} bsStyle="success">{Lang.showText(57)}</Button> */}
                <ControlLabel htmlFor="btnsubmit" >  <h3><Label  bsStyle="success" style={{'cursor': 'pointer'}} >Submit</Label></h3>
                    <Button  id='btnsubmit' bsStyle="success" style={{'display':'none'}}>Submit</Button> 
                </ControlLabel>
                {/* <Button onClick={()=>{this._redirectHandler('/home/settings/general');}} bsStyle="primary">{Lang.showText(61)}</Button> */}
            </div>
        );
    return content;
};

    _redirectHandler (path) {
        let homeThis = StorageData.get('homeThis');
        if (homeThis)
        {
            homeThis.env.nextPath = path;
        }
        hashHistory.push(path);
    };

};

export default DeviceInfo;