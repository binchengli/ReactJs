import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { Grid, Row, Col, FormControl } from 'react-bootstrap';

/* server API */
import ServerAPI from '../../backendAPI/server.js';
import NotificationAPI from '../../backendAPI/Notification.js';

/* component */
import Lang from '../../common/languages.js';
import PageTitile from '../../component/pageTitle.js';

class Notification extends Component {
    constructor (props) {
        super (props);
        this.state = {
            isLoading: false,
            liststate: 'Loading...',
            refreshTimer: 10
        };
        this.dataSource = [];
        this.env = {
            project: ''
        };
        this.updateDimensions = this.updateDimensions.bind(this);
        this._setDataSourceDeviceId = this._setDataSourceDeviceId.bind(this);
    };

    componentWillReceiveProps (nextProps) {
        if (nextProps.params.project != this.env.project)
        {
            this.env.project = nextProps.params.project;
            this.dataUpdate();
        }
    };

    componentDidMount () {
        this.env.project = this.props.params.project;
        this.dataUpdate();
        this.state.refreshTimer = 60 * 1;
        window.addEventListener("resize", this.updateDimensions);
    };

    componentWillUnmount () {
        window.removeEventListener("resize", this.updateDimensions);
    };

    async updateDimensions() {
        var svg = [];
        var div = [];
        for(let i=0; i<10; i++)
        {
            await this._sleep(1000);
            if(svg.length && div.length)
            {
                for(let i=0; i<div.length; i++)
                    svg[i].setAttribute("height", div[i].offsetHeight);
                break;
            }
            else
            {
                var svg = document.getElementsByClassName("monitorsvg");
                var div = document.getElementsByClassName("card__body");
            }
        }
    };

    render () {
        return (
            <Grid fluid>
                <Row>
                    <Col md={12}>
                        <PageTitile text={`${'Notifications'}`}  />
                    </Col>
                </Row>
                <Row>
                    <Col md={12}>
                        <div className='general-panel'>
                            <div className='general-panel-title'>
                                <h3>Notifications</h3>
                            </div>
                            <div className='general-panel-content'>
                                {this.showList()}
                            </div>
                        </div>
                    </Col>
                </Row>
            </Grid>
        );
    };

    dataUpdate () {
        this.setState({liststate: 'Loading...'});
        this.doFetch();
        this.updateDimensions();
    };

    doFetch () {
        let result;
        let res;
        this.dataSource = [];
        this.setState({isLoading: true});
        /*result = NotificationAPI.message();
        result.then((res) => {
            this.dataSource = res.data;
            this.setState({ isLoading: false });
        });*/

        this.dataSource = [
            {type: 'Alert', timestamp: '3 mins ago', message: 'Reason: Massive Camera Disconnected', readed: false},
            {type: 'Alert', timestamp: '4 mins ago', message: 'Reason: Massive Camera Disconnected', readed: true},
            {type: 'Alert', timestamp: '5 mins ago', message: 'Reason: Massive Camera Disconnected', readed: true}
        ];
    };

    showList () {
        const cardBody = {
            'background': 'white'
        };
        let content = [];

        if (this.dataSource.length)
        {
            this.dataSource.map((entry) => {
                content.push(
                    <div className="card__body" style={cardBody}>
                        {this.showlistUnit(entry)}
                    </div>
                );
            });
        }
        else
        {
            content.push(this.state.liststate);
        }
        return content;
    };

    showlistUnit (source) {
        let content = [];
        const Time = {
            'padding-top': '10',
            'color': 'darkslategray',
            'font-size': '16px'
        };
        const Event = {
            'color': 'gray',
            'font-size': '12px'
        };
        const Info = {
            'padding-bottom': '5',
            'color': 'darkslategray',
            'font-size': '16px'
        };
        content.push(
            <div className="monitorUnit">
                <svg className="monitorsvg">
                    <line x1="10" y1="0" x2="10" y2='100%' />
                    <circle cx="10" cy="20" r="5" fill="white" />
                </svg>
                <p style={Time}>{source['timestamp']}</p>
                <p style={Event}>{source['level']}</p>
                <p style={Info}>{source['message']}</p>
            </div>
        );
        return content;
    };

    _setDataSourceDeviceId () {
        let devId = ReactDOM.findDOMNode(this.refs['dataSourceDeviceId']).value.split('ID:')[1];
        this.dataUpdate();
    };
    
    _sleep (ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
};

export default Notification;
