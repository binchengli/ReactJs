import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {
    Grid, Row, Col, FormGroup, FormControl, ControlLabel,Label, Button,HelpBlock,Panel
} from 'react-bootstrap';
import PageTitile from '../../component/pageTitle.js';

import MulitLangFile from '../../common/multiLang.js';
import ServerAPI from '../../backendAPI/server.js';
import CreateAccount from '../../backendAPI/CreateAPI.js';

const Length={name:{min:1,max:98},password:{min:6,max:98}};
const styleLabel={'text-align':'right','vertical-align': 'middle','line-height':'30px','height':'30px'};
const stylecontrol={width:'70%','padding-left':'10px','padding-right':'10px' ,'vertical-align': 'middle'};
const timeformat={yearbefore:{format:'YYYY/MM/DD hh:mm:ss',value:'0'},yearafter:{format:'MM/DD/YYYY hh:mm:ss',value:'1'}};
const rolevlaue={admin:'admin'};

class Create extends Component {
    constructor(props, context) {
        super(props, context);
    
        this.handleChange = this.handleChange.bind(this);
        this.addFile=this.addFile.bind(this);
        this.getImageSize=this.getImageSize.bind(this);
        this.state = {
            currentLanguage:props.language,
            name: '',
            createEmail:'',
            role:rolevlaue.admin,
            language:'US',
            format:timeformat.yearbefore.value,
            file: '',
            imagePreviewUrl: './img/logo.png',
            zone:'0'
        };
    }

    componentWillReceiveProps (nextProps) {
        if (this.currentLanguage != nextProps.language)
        {
            this.setState({ currentLanguage: nextProps.language });
        }
    };
    
    handleChange(change,e) {
        switch(change)
        {
            case 'name':
            this.setState({ name: e.target.value });
            break;
            case 'createEmail':
            this.setState({ createEmail: e.target.value });
            break;
            case 'language':
            this.setState({ language: e.target.value });
            break; 
            case 'format':
            this.setState({ format: e.target.value });
            break;
            case 'zone':
            this.setState({ zone: e.target.value });
            break;
        }
    }

    validateEmail(email) {
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    }

    addFile(e){
        let currentComponent = this;
        let reader = new FileReader();
        let file = e.target.files[0];
    
        reader.onloadend = () => {
            this.getImageSize(reader.result, function(imageWidth, imageHeight) {
                 currentComponent.setState({
                file: file,
                imagePreviewUrl: reader.result
                });
            });    
        }

        if (file)
            reader.readAsDataURL(file)
    }

    getImageSize(imageURL, callback) {      
        // Create image object to ascertain dimensions.
        var image = new Image();
     
        // Get image data when loaded.
        image.onload = function() {      
            // No callback? Show error.
            if (!callback) {
            } else {
                callback(this.naturalWidth, this.naturalHeight);
            }
        }
     
        // Load image.
        image.src = imageURL;
    }
    
    render() {
        return (
            <div>
                <Grid fluid>
                    <Row>
                        <Col md={12}>
                            <PageTitile text={ `${'administration'}/${'create account'}`} />
                        </Col>
                    </Row>
                   
                    <Row  className='general-panel'  >
                    <div style={{'background-color':'#f5f5f5',padding:'10px','border-top':'1px solid #ddd','border-right':'1px solid #ddd','border-left':'1px solid #ddd'}}><strong style={{'font-weight':'700','height':'16px', 'font-size': '15px',color:'inherit'}}>Create Account</strong></div>
                    <Panel >
                    <Col  md={ 7 } mdOffset={2}>
                    <div className='general-panel-content'>
                    <form horizontal className='maccountform' style={{'margin-top':'10px'}}>  
                        <FormGroup >  
                            <Col componentClass={ControlLabel} md={3} style={styleLabel}>{MulitLangFile.MulitLang.aliasName[this.state.currentLanguage]}</Col>
                                 <FormControl 
                                ref="aliasname"
                                size='2x'
                                style={stylecontrol}
                                type="text"
                                value={this.state.name}
                                placeholder={MulitLangFile.MulitLang.aliasName[this.state.currentLanguage]}
                                onChange={this.handleChange.bind(this, 'name')}
                                />
                        </FormGroup>

                        <FormGroup>  
                            <Col componentClass={ControlLabel} md={3}  style={styleLabel}>{MulitLangFile.MulitLang.emailAccount[this.state.currentLanguage]}</Col>
                             {this.showEmail()}
                        </FormGroup>
                        
                         <FormGroup controlId="role_select"  className="form-inline">
                            <Col componentClass={ControlLabel} md={3}  style={styleLabel}>Role</Col>
                            <FormControl   style={stylecontrol} componentClass="select" placeholder="Role" 
                            ref="role"
                            value={this.state.role}
                            onChange={this.handleChange.bind(this,'role')}
                            >
                             <option value={rolevlaue.admin} >{MulitLangFile.MulitLang.admin[this.state.currentLanguage]}</option>
                            </FormControl>
                        </FormGroup>
                            
                        <FormGroup controlId="language_select"   className="form-inline">
                           <Col componentClass={ControlLabel} md={3}  style={styleLabel}>Language</Col>
                            <FormControl style={stylecontrol} componentClass="select" placeholder="language"
                            ref="language"
                            value={this.state.language}
                            onChange={this.handleChange.bind(this,'language')}
                            >
                                <option value="US">English</option>
                            </FormControl>
                         </FormGroup>
                        
                        <FormGroup controlId="format_select"   className="form-inline">
                            <Col componentClass={ControlLabel} md={3}  style={styleLabel}>Time Format</Col>
                            <FormControl style={stylecontrol} componentClass="select" placeholder="format"
                            ref="format"
                            value={this.state.format}
                            onChange={this.handleChange.bind(this,'format')}
                            >
                                <option value={timeformat.yearbefore.value}>{timeformat.yearbefore.format}</option>
                                <option value={timeformat.yearafter.value}>{timeformat.yearafter.format}</option>
                            </FormControl>
                        </FormGroup>

                        <FormGroup controlId="zone_select" className="form-inline">
                            <Col componentClass={ControlLabel} md={3}  style={styleLabel}>Time Zone</Col>
                            <FormControl style={stylecontrol} componentClass="select" placeholder="zone" value={this.state.zone}
                                onChange={this.handleChange.bind(this,'zone')}
                            >
                                <option value='-12'>GMT-12:00</option>
                                <option value='-11'>GMT-11:00</option>
                                <option value='-10'>GMT-10:00</option>
                                <option value='-9'>GMT-09:00</option>
                                <option value='-8'>GMT-08:00</option>
                                <option value='-7'>GMT-07:00</option>
                                <option value='-6'>GMT-06:00</option>
                                <option value='-5'>GMT-05:00</option>
                                <option value='-4'>GMT-04:00</option>
                                <option value='-3'>GMT-03:00</option>
                                <option value='-2'>GMT-02:00</option>
                                <option value='-1'>GMT-01:00</option>
                                <option value='0'>GMT</option>
                                <option value='+1'>GMT+01:00</option>
                                <option value='+2'>GMT+02:00</option>
                                <option value='+3'>GMT+03:00</option>
                                <option value='+4'>GMT+04:00</option>
                                <option value='+5'>GMT+05:00</option>
                                <option value='+6'>GMT+06:00</option>
                                <option value='+7'>GMT+07:00</option>
                                <option value='+8'>GMT+08:00</option>
                                <option value='+9'>GMT+09:00</option>
                                <option value='+10'>GMT+10:00</option>
                                <option value='+11'>GMT+11:00</option>
                                <option value='+12'>GMT+12:00</option>
                            </FormControl>
                        </FormGroup>
                           
                        <FormGroup controlId="image_select" bsSize="large" className="form-inline">
                            <Col componentClass={ControlLabel} md={3}  style={{'text-align':'right','padding-top':'5px'}}>Select Logo</Col>
                            <Col componentClass={ControlLabel}>
                                <div style={{'text-align':'left'}}>
                                    <ControlLabel htmlFor="fileUpload">
                                            <h3>
                                            <Label  bsStyle="success" style={{'cursor': 'pointer'}} >Browse...</Label>
                                            </h3>
                                        
                                            <FormControl
                                                ref="upload"
                                                id="fileUpload"
                                                type="file"
                                                accept="image/*"
                                                onChange={this.addFile}
                                                style={{ display: "none" }}
                                            />             
                                    </ControlLabel>
                                    {this.showImage()}
                                </div>
                            </Col>
                        </FormGroup>

                        <FormGroup  bsSize="large">
                            <div className='general-panel-footer'>
                            <Col mdOffset={8}>
                                {this.showButton()}
                            </Col>
                            </div> 
                        </FormGroup>
                    </form>
                    </div>
                    </Col>
                    </Panel>
                </Row>
                </Grid>
           </div>
        );
    }

    showEmail(){
        let content = [];
            content.push (
                    <FormControl 
                    ref="email"
                    type="text"
                    style={stylecontrol}
                    value={this.state.createEmail}
                    placeholder={MulitLangFile.MulitLang.emailAccount[this.state.currentLanguage]}
                    onChange={this.handleChange.bind(this,'createEmail')}
                    >
                    </FormControl>
            );

        return content;
    }

    showImage() {
        let content = [];
      
        let {imagePreviewUrl} = this.state;
        content.push (<div className="col-notice">(Suggested size: 120*120.)</div>);
        if (imagePreviewUrl) {
            content.push (<div><img circle style={{height:'120px',width:'120px'}} src={imagePreviewUrl}/></div>);
        } else {
            content.push(<div className="previewText">Please select an Image for Preview</div>);
        }
        return content;
    }

    showButton () {
        let content = [];
        content.push(
            <div>
                <ControlLabel htmlFor="btnsubmit" >  <h3><Label  bsStyle="success" style={{'cursor': 'pointer'}} >Submit</Label></h3>
                    <Button onClick={()=>{this._submitHandler('submit');}} id='btnsubmit' bsStyle="success" style={{'display':'none'}}>Submit</Button> 
                </ControlLabel>
            </div>
        );
        return content;
    };

    _submitHandler (type) {
        switch (type)
        {
            case 'submit':
                if(this._nameValidator())
                {
                    let login=JSON.parse(ServerAPI.getLoginInfo());
                    let data={
                        "uuid": login.uuid,
                        "alias": this.state.name,
                        "mail": this.state.createEmail,
                        "role": this.state.role,
                        "language": this.state.language,
                        "timeformat": this.state.format,
                        "timezone": this.state.zone
                    };
                    let result = CreateAccount.create(data);
                    result.then((res) => {
                        if(res&&res.status)
                        { 
                            if(res.status=='ok'||res.status=='success')
                            {
                                 confirm('Create Success.');
                                 confirm('Default Passwird is 12345678.');
                               this._submitlogo(login.uuid);
                            }else
                            {
                                confirm('Create '+res.result);
                            }
                            
                        }
                        else
                        {
                            if(res&&res.message)alert(res.message);
                            else
                            alert('Create Fail.');
                        }
                    });
                }
                break;
            default:
                break;
        }
    };
    
    _submitlogo(uuid)
    {  
        if(this.state.imagePreviewUrl.startsWith("data:image/"))
        {
               
            let blob=this.dataURItoBlob(this.state.imagePreviewUrl);
                let result = CreateAccount.putlogo(blob,uuid);
                result.then((res) => {
                if(res&&res.logofilepath)
                { 
                    if(res.logofilepath&&res.logofilepath.indexOf('upload') != -1)
                    {
                    }else
                    {
                        confirm('Create Logo Fail');
                    }  
                }
                else
                {
                    if(res&&res.message)alert(res.message);
                    else
                    alert('Create Logo Fail.');
                }
            });
        }
    }

    dataURItoBlob(dataURI) {
        // convert base64 to raw binary data held in a string
        // doesn't handle URLEncoded DataURIs - see SO answer #6850276 for code that does this
        var byteString = atob(dataURI.split(',')[1]);
      
        // separate out the mime component
        var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0]
      
        // write the bytes of the string to an ArrayBuffer
        var ab = new ArrayBuffer(byteString.length);
      
        // create a view into the buffer
        var ia = new Uint8Array(ab);
      
        // set the bytes of the buffer to the correct values
        for (var i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }
      
        // write the ArrayBuffer to a blob, and you're done
        var blob = new Blob([ab], {type: mimeString});
        return blob;
    }  

    _nameValidator () {
        let aliasname = ReactDOM.findDOMNode(this.refs[`aliasname`]).value;
        if (!aliasname)
        {
            alert('Please enter Alias Name.');
            return false;
        }
                
        if (!this.state.createEmail)
        {
            alert('Please enter E-mail address.');
            return false;
        }

        if(this.state.role=='')
        {
            alert('Please select Role.');
            return false;
        }

        if(!this.validateEmail(this.state.createEmail))
        {
            alert('E-Mail format Error.');
            return false;
        } 

        if(Length.name > aliasname.length)
        {
            alert(`Alias Name Minimum : ${Length.name.min} characters.`);
            return false;
        }

        if(aliasname.length>Length.name.max)
        {
            alert(`Alias Name Maximum : ${Length.name.max} characters.`);
            return false;
        }
        
        return true;
    }
};

export default Create;