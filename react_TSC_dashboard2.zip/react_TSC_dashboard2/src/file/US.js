{"LANG": ["TSC Manager version", 
"Logout", 
"TSC",
"Manager",
"Hi",
"RootAdmin",
"Demo1",
"Demo2",
"Account Manage",
"Device Manage",
"Sales Statistic",
"Create Account",
"Setting"
	]
}