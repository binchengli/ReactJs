import 'whatwg-fetch';

import ServerAPI from './server.js';

const ControllerAdministrationAPI = (() => {
    const getController = (ctrlUuid) => {
        let URL = ServerAPI.URLlist['ctrl_AdminControllerGet'].replace('{ctrlUuid}',ctrlUuid);
        return fetch(URL, {
            method: 'GET',
            headers: {
                'Authorization': ServerAPI.getJWT()
            }
        })
        .then((response) => {
            return ServerAPI.httpCheck(response);
        });
    };
    const editController = (ctrlUuid, obj) => {
        let URL = ServerAPI.URLlist['ctrl_AdminControllerEdit'].replace('{ctrlUuid}',ctrlUuid);
        let formData  = new FormData();
        if ('' != obj['profilePathFile'])
        {
            formData.append('header', obj['profilePathFile']);
        }
        formData.append('config', 
            new Blob([JSON.stringify({
                name: obj['name'],
                description: obj['description'],
                countryCode: obj['countryCode'],
                timeZone: obj['timeZone']
            })], {
                type: 'application/json'
            })
        );
        return fetch(URL, {
            method: 'PUT',
            headers: {
                'Authorization': ServerAPI.getJWT()
            },
            body: formData
        })
        .then((response) => {
            return ServerAPI.httpCheck(response);
        });
    };
    const getSecurity = (ctrlUuid)=> {
        let URL = ServerAPI.URLlist['ctrl_AdminSecurityGet'].replace('{ctrlUuid}', ctrlUuid);
        return fetch(URL, {
            method: 'GET',
            headers: {
                'Authorization': ServerAPI.getJWT()
            }
        })
        .then((response) => {
            return ServerAPI.httpCheck(response);
        });
    };
    const setSecurity = (ctrlUuid, obj)=> {
        let URL = ServerAPI.URLlist['ctrl_AdminSecurityEdit'].replace('{ctrlUuid}', ctrlUuid);
        return fetch(URL, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': ServerAPI.getJWT()
            },
            body: JSON.stringify({
                authLogin: obj['authLogin'],
                authSecurity: obj['authSecurity']
            })
        })
        .then((response) => {
            return ServerAPI.httpCheck(response);
        });
    };
    const getDatetime = (ctrlUuid) => {
        let URL = ServerAPI.URLlist['ctrl_Datetime'].replace('{ctrlUuid}',ctrlUuid);
        return fetch(URL, {
            method: 'GET',
            headers: {
                'Authorization': ServerAPI.getJWT()
            }
        })
        .then((response) => {
            return ServerAPI.httpCheck(response);
        });
    };
    return ({
        getController: getController,
        editController: editController,
        getSecurity: getSecurity,
        setSecurity: setSecurity,
        getDatetime: getDatetime
    });
})();

export default ControllerAdministrationAPI;
