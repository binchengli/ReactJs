import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {
    Col, Form, FormGroup, FormControl, ControlLabel, Button, Panel, Image
} from 'react-bootstrap';
import FontAwesome from 'react-fontawesome';

/* server API */
import ServerAPI from '../../../backendAPI/server.js';
import CtrlAdministrationAPI from '../../../backendAPI/controllerAdministration.js';
/* component */
import Lang from '../../../component/languages.js';
/* common */
import ConstDef, { tzOptions, countryOptions } from '../../../common/constDef.js';
import DataObj from '../../../common/dataObj.js';
import FunctionJS from '../../../common/functionJS.js';
/* backdoor function */
import { homepageUpdateFn } from '../home.js';

class AdministrationCtrl extends Component {
    constructor (props) {
        super(props);
        this.state = {
            isLoading: false
        };
        this.formData = {
            name: '',
            description: '',
            countryCode: 'US',
            timeZone: 9,
            isAutoApproved: 0,
            profilePathFile: '',
            profilePath: ''
        };
        this.env = {
            userInfo:{},
            ctrlUuid: ''
        };
    };
    componentWillReceiveProps (nextProps) {
        this.dataUpdate(nextProps);
    };
    componentDidUpdate () {
        this.formRefresh();
    };
    render () {
        return (
            <Form id='administrationCtrl' horizontal>
                {this.showConfig()}
                {this.showButton()}
            </Form>
        );
    };

    dataUpdate (source) {
        this.env['userInfo'] = ServerAPI.getUserInfo();
        if((this.env['ctrlUuid'] != source['ctrlUuid'])
            || (source['forceReload']))
        {
            this.env['ctrlUuid'] = source['ctrlUuid'];
            this.doFetch('get');
        };
    };
    doFetch (fetchType) {
        let result;
        if ('' == this.env['ctrlUuid']) return false;
        this.setState({ isLoading: true });
        switch (fetchType) 
        {
            case 'get':
                result = CtrlAdministrationAPI.getController(this.env['ctrlUuid']);
                result.then((res) => {
                    if (ServerAPI.errorCodeCheck(res)) 
                    {
                        this.resolveFetchData(res.data);
                    }
                    this.setState({ isLoading: false });
                });
                break;
            case 'edit':
                result = CtrlAdministrationAPI.editController(this.env['ctrlUuid'], this.formData);
                result.then((res) => {
                    if (ServerAPI.errorCodeCheck(res)) 
                    {
                        this.resolveFetchData(res.data);
                        // clear file input
                        this.formData['profilePathFile'] = '';
                        if (ReactDOM.findDOMNode(this.refs['profilePath']))
                        {
                            ReactDOM.findDOMNode(this.refs['profilePath']).value = '';
                        };
                        // forceupdate
                        homepageUpdateFn('menuList');
                    }
                    this.setState({ isLoading: false });
                });
                break;
        }
    };
    resolveFetchData (source) {
        this.formData = new DataObj.generalFetchObj(source);
        if('' != this.formData['profilePath'])
        {
            this.formData['profilePath'] = `${ServerAPI.storageDomain}${this.formData['profilePath']}?${Date.now()}`;
        };
        // for temp
        this.formData['smtpAuth'] = 0;
    };
    formRefresh () {
        Object.keys(this.formData).map((entry) => {
            if (ReactDOM.findDOMNode(this.refs[entry]))
            {
                if ('profilePath' != entry)
                {
                    ReactDOM.findDOMNode(this.refs[entry]).value = this.formData[entry];
                }
            }
        });
    };

    showConfig () {
        let content = [];
        content.push(
            <Panel header={<h3>{Lang.showText(145)}</h3>}>
                <FormGroup>
                    <Col componentClass={ControlLabel} md={3}>{Lang.showText(143)}</Col>
                    <Col md={3}>
                        <FormControl 
                            type='text' 
                            placeholder={Lang.showText(143)}
                            onChange={()=>{this._changeHandler('name');}} 
                            ref='name'
                            maxLength='32'
                        />
                    </Col>
                </FormGroup>
                <FormGroup>
                    <Col componentClass={ControlLabel} md={3}>{Lang.showText(81)}</Col>
                    <Col md={3}>
                        <FormControl 
                            type='text' 
                            placeholder={Lang.showText(81)}
                            onChange={()=>{this._changeHandler('description');}} 
                            ref='description'
                            maxLength='32'
                        />
                    </Col>
                </FormGroup>
                <FormGroup>
                    <Col componentClass={ControlLabel} md={3}>{Lang.showText(69)}</Col>
                    <Col md={3}>
                        <FormControl 
                            componentClass='select' 
                            onChange={()=>{this._changeHandler('countryCode');}} 
                            ref='countryCode'
                        >
                            {
                                countryOptions.map((entry) => (
                                    <option value={entry.A2}>{Lang.showText(entry.textIndex)}</option>
                                ))
                            }
                        </FormControl>
                    </Col>
                </FormGroup>
                <FormGroup>
                    <Col componentClass={ControlLabel} md={3}>{Lang.showText(70)}</Col>
                    <Col md={3}>
                        <FormControl 
                            componentClass='select' 
                            onChange={()=>{this._changeHandler('timeZone');}} 
                            ref='timeZone'
                        >
                            {
                                tzOptions.map((entry) => (
                                    <option value={entry.value}>{Lang.showText(entry.textIndex)}</option>
                                ))
                            }
                        </FormControl>
                    </Col>
                </FormGroup>
                <FormGroup>
                    <Col componentClass={ControlLabel} md={3}>{Lang.showText(144)}</Col>
                    <Col md={3} className="control-fileInput">
                        <FormControl 
                            type='file' 
                            onChange={(e)=>{this._imgHandler(e, 'profilePath');}} 
                            ref='profilePath'
                        />
                        <div className='col-notice'>({Lang.showText(844)})</div>
                        <Image className='imagePreview' src={this.formData['profilePath']} responsive />
                    </Col>
                </FormGroup>
            </Panel>
        );
        return content;
    };
    showButton () {
        let content = [];
        if (this.state['isLoading'])
        {
            content.push(
                <div>
                    <Button disabled>{Lang.showText(20)}</Button>
                    <span className='accessingTag'><FontAwesome name='spinner' size='lg' pulse/>{Lang.showText(48)}</span> 
                </div>
            );
        }
        else
        {
            if(3 == this.env.userInfo['role'])
            {
                content.push(
                    <div>
                        <Button disabled>{Lang.showText(20)}</Button>
                    </div>
                );
            }
            else
            {
                content.push(
                    <div>
                        <Button onClick={()=>{this._submitHandler('save');}}>{Lang.showText(20)}</Button>
                    </div>
                );
            };
        };
        return content;
    };

    _changeHandler (name) {
        this.formData[name] = ReactDOM.findDOMNode(this.refs[name]).value;
        this.forceUpdate();
    };
    _imgHandler (event, name) {
        event.preventDefault();
        let file = event.target.files[0];
        let fileNameLength = file.name.length;
        let fileNameExt = file.name.substring(fileNameLength-4, fileNameLength);
        if (('.png' != fileNameExt) 
            && ('.gif' != fileNameExt) 
            && ('.jpg' != fileNameExt)
            && ('.bmp' != fileNameExt)
            && ('.PNG' != fileNameExt) 
            && ('.GIF' != fileNameExt)
            && ('.JPG' != fileNameExt)
            && ('.BMP' != fileNameExt)
        )
        {
            alert(Lang.showText(359));
            ReactDOM.findDOMNode(this.refs[name]).value = '';
            return false;
        };
        if (file.size > ConstDef.IMAGE_MAX_SIZE)
        {
            alert(Lang.showText(360, ConstDef.IMAGE_MAX_SIZE));
            ReactDOM.findDOMNode(this.refs[name]).value = '';
            return false;
        };
        this.formData['profilePathFile'] = file;
        let reader = new FileReader();
        reader.onload = () => {
            this.formData['profilePath'] = reader.result;
            this.forceUpdate();
        };
        reader.readAsDataURL(file);
    };
    _submitHandler (actionType) {
        let formData = this.formData;
        switch (actionType) 
        {
            case 'save':
                if (!FunctionJS.checkValue(formData['name'], 'name'))
                {
                    alert(`${Lang.showText(146)} (${Lang.showText(87)}: 1-32)`);
                    return false;
                };
                if (!FunctionJS.checkValue(formData['description'], 'description'))
                {
                    alert(`${Lang.showText(88)} (${Lang.showText(89)}: 32)`);
                    return false;
                };
                if(!process.env['IS_DEMOMODE'])
                {
                    this.doFetch('edit');
                };
                break;
        };
    };
};

export default AdministrationCtrl;
