import PropTypes from 'prop-types';
import ReactDOM from 'react-dom';
import {
    Panel, Grid, Row, Col, FormControl, Button
} from 'react-bootstrap';

let onChange = null

export default class SendValue {
    static propTypes = {
        onChange: PropTypes.func.isRequired
    }

    onChange

    static setListener = (handler) => {
        onChange = handler
    }

    static handleAdd = (text) => {
        this.onChange(text);
        //this.props.onChange(text);
    }
}