import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {
    Grid, Row, Col, Form, FormGroup, FormControl, ControlLabel,Label, Button,HelpBlock,Panel
} from 'react-bootstrap';
import PageTitile from '../../component/pageTitle.js';
import { homepageUpdateFn } from './home.js';
/* common */
// import Lang from '../../common/languages.js';
import FontAwesome from 'react-fontawesome';
import MulitLangFile from '../../common/multiLang.js';
import StorageData from '../../common/storageData.js';
import ServerAPI from '../../backendAPI/server.js';
import CreateAccount from '../../backendAPI/CreateAPI.js';
const Length={name:{min:1,max:98},password:{min:6,max:98}};
 const styleLabel={'text-align':'right','vertical-align': 'middle','line-height':'30px','height':'30px'};
const stylecontrol={width:'70%','padding-left':'10px','padding-right':'10px' ,'vertical-align': 'middle'};
const stylemail={ color: "#555" ,width:'70%','margin-left':'10px','padding-left':'10px','padding-right':'10px' ,'vertical-align': 'middle',display:' table-cell','line-height':'30px','height':'30px'};

const timeformat={yearbefore:{format:'YYYY/MM/DD hh:mm:ss',value:'0'},yearafter:{format:'MM/DD/YYYY hh:mm:ss',value:'1'}};

class Setting extends Component {
    

    constructor(props, context) {
        super(props, context);
    
        this.handleChange = this.handleChange.bind(this);
        this.addFile=this.addFile.bind(this);
        this.getImageSize=this.getImageSize.bind(this);
         let login=JSON.parse(ServerAPI.getLoginInfo());
        this.state = {
          name: '',
          settingEmail: login.mail,
          language:'US',
          format:timeformat.yearbefore.value,//0:YYYY/MM/DD hh:mm:ss           1:MM/DD/YYYY hh:mm:ss
          file: '',
          imagePreviewUrl: '',
          zone:'0',
          isLoading:true
        };
        this.getSettings(login);
      }


      getSettings (login) 
    {
        let result=CreateAccount.getSetting(login.uuid);
        result.then((res) => {
            if(res&&res.alias)
            { 
                  this.setState({settingEmail:res.mail,name:res.alias,language:res.language,format:res.timeformat,zone:res.timezone,isLoading:false});
            }
            else
            {
                alert('get Setting Fail.');
                this.setState({isLoading:false});
            }
        });
    }

      componentWillReceiveProps (nextProps) {
          if(this.language!=nextProps.language)
          {
            this.setState({ language: nextProps.language });
          }

     };
    
    
      handleChange(change,e) {
         switch(change){
             case 'name':
              this.setState({ name: e.target.value });
              break;
              case 'createEmail':
              this.setState({ createEmail: e.target.value });
              break;
              case 'language':
              this.setState({ language: e.target.value });
              break; 
              case 'format':
              this.setState({ format: e.target.value });
              break;
              case 'zone':
              this.setState({ zone: e.target.value });
              break;
          }
       
      }

      validateEmail(email) {
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
      }

      addFile(e){
        let currentComponent = this;
        let reader = new FileReader();
        let file = e.target.files[0];
    
        reader.onloadend = () => {
            this.getImageSize(reader.result, function(imageWidth, imageHeight) {
                 currentComponent.setState({
                file: file,
                imagePreviewUrl: reader.result
                });
            });
          
           
        }
        if(file)reader.readAsDataURL(file)
    }

    getImageSize(imageURL, callback) {      
        var image = new Image();
        image.onload = function() {      
           if (!callback) {
              console.log("Error getting image size: no callback. Image URL: " + imageURL);
           } else {
              callback(this.naturalWidth, this.naturalHeight);
           }
        }
     
        // Load image.
        image.src = imageURL;
     }
    
      render() {
        console.log(`Render setting language=${this.state.language},isLoading=${this.state.isLoading}`);
        return (
        
          <div >
                <Grid  fluid>
                    <Row>
                        <Col md={12}>
                            <PageTitile text={ `${'administration'}/${'setting'}`} />
                        </Col>
                    </Row>
                    
                    <Row className=' general-panel'>
                    <div style={{'background-color':'#f5f5f5',padding:'10px','border-top':'1px solid #ddd','border-right':'1px solid #ddd','border-left':'1px solid #ddd'}}><strong style={{'font-weight':'700','height':'16px', 'font-size': '15px',color:'inherit'}}>Setting</strong></div>
                    <Panel>        
                      
                    <Col  md={ 7 } mdOffset={2} >
                    <div className='general-panel-content'>
                    {this.state.isLoading? <span className='accessingTag'><FontAwesome name='spinner' size='lg' pulse />Loading</span>
                        :<form horizontal className='maccountform'  style={{'margin-top':'10px'}}>  
                        <FormGroup >  
                            <Col componentClass={ControlLabel} md={3} style={styleLabel}>{MulitLangFile.MulitLang.aliasName[this.state.language]}</Col> 
                            <FormControl
                            ref="aliasname"
                            type="text"
                            style={stylecontrol}
                            value={this.state.name}
                            placeholder={MulitLangFile.MulitLang.aliasName[this.state.language]}
                            onChange={this.handleChange.bind(this, 'name')}
                            />
                        </FormGroup>

                        <FormGroup  >  
                            <Col componentClass={ControlLabel} md={3}  style={styleLabel}>{MulitLangFile.MulitLang.emailAccount[this.state.language]}</Col>
                            <div style={stylemail}>{this.state.settingEmail}</div>
                        </FormGroup>

                         <FormGroup controlId="language_select"   className="form-inline">
                            <Col componentClass={ControlLabel} md={3}  style={styleLabel}>Language</Col>
                            <FormControl  style={stylecontrol} componentClass="select" placeholder="language"
                            ref="language"
                            style={stylecontrol}
                            value={this.state.language}
                            onChange={this.handleChange.bind(this,'language')}
                            >
                                <option value="US">English</option>
                            </FormControl>
                        </FormGroup>

                            <FormGroup controlId="format_select"   className="form-inline">
							<Col componentClass={ControlLabel} md={3}  style={styleLabel}>Time Format</Col>
                            <FormControl  componentClass="select" placeholder="format"
                            ref="format"
                            style={stylecontrol}
                            value={this.state.format}
                            onChange={this.handleChange.bind(this,'format')}
                            >
                                <option value={timeformat.yearbefore.value}>{timeformat.yearbefore.format}</option>
                                <option value={timeformat.yearafter.value}>{timeformat.yearafter.format}</option>
                            </FormControl>
                            </FormGroup>

                            
                            <FormGroup controlId="zone_select"   className="form-inline">
                            <Col componentClass={ControlLabel} md={3}  style={styleLabel}>Time Zone</Col>
                            <FormControl componentClass="select" placeholder="zone" value={this.state.zone}
                             style={stylecontrol}
                                onChange={this.handleChange.bind(this,'zone')}
                                >
                                  <option value='-12'>GMT-12:00</option>
                                  <option value='-11'>GMT-11:00</option>
                                  <option value='-10'>GMT-10:00</option>
                                  <option value='-9'>GMT-09:00</option>
                                 <option value='-8'>GMT-08:00</option>
                                <option value='-7'>GMT-07:00</option>
                                <option value='-6'>GMT-06:00</option>
                                <option value='-5'>GMT-05:00</option>
                                <option value='-4'>GMT-04:00</option>
                                <option value='-3'>GMT-03:00</option>
                                <option value='-2'>GMT-02:00</option>
                                <option value='-1'>GMT-01:00</option>
                                <option value='0'>GMT</option>
                                <option value='+1'>GMT+01:00</option>
                                <option value='+2'>GMT+02:00</option>
                                <option value='+3'>GMT+03:00</option>
                                <option value='+4'>GMT+04:00</option>
                                <option value='+5'>GMT+05:00</option>
                                <option value='+6'>GMT+06:00</option>
                                <option value='+7'>GMT+07:00</option>
                                <option value='+8'>GMT+08:00</option>
                                <option value='+9'>GMT+09:00</option>
                                <option value='+10'>GMT+10:00</option>
                                <option value='+11'>GMT+11:00</option>
                                <option value='+12'>GMT+12:00</option>
                                
                               
                            </FormControl>
                            </FormGroup>
                            
                            <FormGroup controlId="image_select" bsSize="large"  >
                            <Col componentClass={ControlLabel} md={3}  style={{'text-align':'right','padding-top':'5px'}}>Select Logo</Col>
                            <Col componentClass={ControlLabel} >
                                <div style={{'text-align':'left'}}>
                               
                                <ControlLabel htmlFor="fileUpload" >
                                        <h3 >
                                        <Label  bsStyle="success"  style={{'cursor': 'pointer'}} >Browse...</Label>
                                        </h3>

                                        <FormControl
                                            ref="upload"
                                            id="fileUpload"
                                            type="file"
                                            accept="image/*"
                                            onChange={this.addFile}
                                            style={{ display: "none" }}
                                        />
                               
                             
                                     </ControlLabel>
                                    
                                {this.showImage()}
                                </div>
                                </Col>
                             </FormGroup>
                             <FormGroup className="form-inline" bsSize='large'>
                                <div className='general-panel-footer'>
                                <Col  mdOffset={8}>
                                    {this.showButton()}
                                </Col>
                                </div> 
                             </FormGroup>
                    </form>
                    }
                    
                    </div>
                    </Col>
                    </Panel> 
                </Row>
               
                <Row>
                    <Col md={ 5 } mdOffset={2}>
                        
                    </Col>
                </Row>
                <Row >      
                    
                        <Col md={3} mdOffset={2}>
                           
                          
                        </Col>
                 
                </Row>             
             
              </Grid>
           </div>
            


         
        );
      }

      showImage()
      {
        let content = [];
        let {imagePreviewUrl} = this.state;
        content.push (<div className="col-notice">(Suggested size: 120*120.)</div>);
        if (imagePreviewUrl) {
            content.push (<div><img circle style={{height:'120px',width:'120px'}} src={imagePreviewUrl}/></div>);
        } 
        return content;
      }

      showButton () {
            let content = [];
            content.push(
                <div>
                    <ControlLabel htmlFor="btnsubmit" >  <h3><Label  bsStyle="success" style={{'cursor': 'pointer'}} >Submit</Label></h3>
                        <Button onClick={()=>{this._submitHandler('submit');}} id='btnsubmit' bsStyle="success" style={{'display':'none'}}>Submit</Button> 
                    </ControlLabel>
                </div>
            );
        return content;
    };


    _submitHandler (type) {
        switch (type)
        {
            case 'submit':
                if(this._nameValidator())
                {
                    let login=JSON.parse(ServerAPI.getLoginInfo());
                    let data={
                        "uuid": login.uuid,
                        "alias": this.state.name,
                        "mail": this.state.createEmail,
                        "language": this.state.language,
                        "timeformat": this.state.format,
                        "timezone": this.state.zone
                    };
                    let result = CreateAccount.setting(data);
                    result.then((res) => {
                        if(res)
                        { 
                            if(res.alias&&res.language)
                            {
                                confirm('Setting Success.');
                                let login=JSON.parse(ServerAPI.getLoginInfo());
                              
                                login.timeformat=res.timeformat;
                                login.timezone=res.timezone;
                                login.alias=res.alias;
                                ServerAPI.saveLoginInfo(JSON.stringify(login));
                                homepageUpdateFn('setting');
                                this._submitlogo(login.uuid);
                            }else
                            {
                                confirm('Setting '+res.result);
                            }
                            
                        }
                        else
                        {
                            if(res&&res.message)alert(res.message);
                            else
                            alert('Setting Fail.');
                        }
                    });
                }
                break;
            default:
                break;
        }
    };

    _submitlogo(uuid)
    {  
        
        if(this.state.imagePreviewUrl.startsWith("data:image/"))
        {
                let blob=this.dataURItoBlob(this.state.imagePreviewUrl);
                    let result = CreateAccount.putlogo(blob,uuid);
                    result.then((res) => {
                    if(res&&res.logofilepath)
                    { 
                        if(res.logofilepath&&res.logofilepath.includes('upload'))
                        {
                            confirm('Setting Logo Success.');
                            if(res.logofilepath&&res.logofilepath.includes('upload')){
                                let login=JSON.parse(ServerAPI.getLoginInfo());
                              
                                login.logofilepath=res.logofilepath;
                                ServerAPI.saveLoginInfo(JSON.stringify(login));
                                homepageUpdateFn('logo');
                            }
                        }else
                        {
                            confirm('Setting Logo Fail');
                        }
                        
                    }
                    else
                    {
                        if(res&&res.message)alert(res.message);
                        else
                        alert('Setting logo Fail.');
                    }
                       
                     });
                
                
            
        }
        
    }


    dataURItoBlob(dataURI) {
        var byteString = atob(dataURI.split(',')[1]);
        var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0]
        var ab = new ArrayBuffer(byteString.length);
        var ia = new Uint8Array(ab);
        for (var i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }
        var blob = new Blob([ab], {type: mimeString});
        return blob;
    }  

    _nameValidator () {
        let aliasname = ReactDOM.findDOMNode(this.refs[`aliasname`]).value;
       
            if(!aliasname)
            {
                alert('Please enter Alias Name.');
                return false;
            }
 
            if(Length.name > aliasname.length)
            {
                alert(`Alias Name Minimum : ${Length.name.min} characters.`);
                return false;
            }

            if(aliasname.length>Length.name.max)
            {
                alert(`Alias Name Maximum : ${Length.name.max} characters.`);
                return false;
            }

            if(this.state.zone==''||this.state.format==''||this.state.language=='')
            {
                alert('Please select full parameter.');
                return false;
            }
        
        else
            return true;

    }
};



export default Setting;